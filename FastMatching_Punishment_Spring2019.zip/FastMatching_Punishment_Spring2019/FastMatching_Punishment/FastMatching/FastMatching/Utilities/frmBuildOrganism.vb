﻿Option Explicit On
Imports Utilities
Public Class frmBuildOrganism

    Private m_objOrganism As New AnOrganism
    Private m_intPopulationIndex As Integer

    Private m_objSampler As New SampleWoutReplace
    Private m_objStopwatch As New System.Diagnostics.Stopwatch

    Private m_picID As Integer ' For organism pic.  1 = cartman, 2 = Pigeon, 3 = rat

    Public ReadOnly Property Creature() As AnOrganism

        'Envisioned usage:  This form will be part of an MDI application and will be used only to build an
        'organism.  The laboratory part of the form will not be used (although it could be used for testing,
        'etc., or it could be removed altogether).  The user will set all the organism properties on the right 
        'hand side of the form by clicking the "Create this population" button for each population (and discriminative
        'stimulus).  This will load up m_objOrganism with the desired populations of potential behaviors.

        'Actual experiments will be run by other code.  For example, there might be a schedule form (single,
        'concurrent, chained schedules, with parameters), and an experiment layout and data storage form, and perhaps
        'a data analysis form.  This additional code will access the built organism through the Creature property
        '(this property) of the frmBuildOrganism class (form).  The syntax might be something like this:
        '       Dim myOrganism as New AnOrganism
        '       myOrganism = frmBuildOrganism.Creature
        'The additional code that actually runs the experiments will have no other contact with this form.

        'In normal operation, the experiment-running code will have only three points of contact with the built organism, 
        'let's say, myOrganism.  (The following three points are applicable to Version 3.0.  Version 3.1 implements a simpler method
        'of interacting with the built organism.  See the Guide for an explanation.  The Version 3.0 functionality described below is
        'fully retained in Version 3.1.)
        '1. The correct population in myOrganism is accessed by "turning on the discriminative stimulus" with
        '   syntax like myOrganism.Item(indexOfDiscriminativeStimulus).  The Item returned by this statement is the 
        '   population of potential behaviors associated with that discriminative stimulus.
        '2. Each time tick the population must be queried for a behavioral emssion (as in DoARun below):
        '         emittedBehaviorAsInteger = myOrganism.Item(indexOfDiscriminativeStimulus).EmitBehavior.IntegerValue
        '3. After the emitted behavior is obtained, the experiment-running code will communicate to myOrganism whether
        '   the behavior is reinforced by setting its Selection property (as in DoARun below).  There are two syntax versions 
        '   for doing this:
        '         myOrganism.Item(indexOfDiscriminativeStimulus).Selection(selectionParameter, intMidpoint) = True (if reinforced)/False (if not reinforced).
        '         myOrganism.Item(indexOfDiscriminativeStimulus).Selection(selectionParameter) = True/False
        '   The first syntax is required if midpoint fitness is being used, in which case intMidpoint is the midpoint of
        '   the target class to which the emitted behavior belongs (which, as the code is currently written, must be an integer).
        '   The second syntax can be used for all other fitness methods.  If the first syntax is used for the other fitness
        '   methods, then the passed value of intMidpoint is ignored.  In both cases, the selectionParameter must be passed to the
        '   Selection property.  This is the mean of the parental choosing function for the continuous selection method, the proportion 
        '   of the population to be discarded for the truncation selection method, and the number of competitors for the tournament
        '   selection method.

        'That's it.  Each generation, the organism must be queried for an emitted behavior, and then told whether or not that
        'behavior is reinforced.  The organism code does all the rest.

        'A different approach is to load the populations in myOrganism into separate Behaviors classes:
        '       Dim whitePopulation as New Behaviors
        '       Dim redPopulation as New Behaviors
        '       Dim greenPopulation as New Behaviors
        '
        '       whitePopulation = myOrganism.Item(indexOfWhiteSD)
        '       redPopulation = myOrganism.Item(indexOfRedSD)
        '       greenPopulation = myOrganism.Item(indexOfGreenSD)
        'Then the emission and reinforcement statements are executed for whichever discriminative stimulus is in effect, say the
        'white one:
        '       emittedBehaviorAsInteger = whitePopulation.EmitBehavior.IntegerValue
        '       whitePopulation.Selection(selectionParameter, intMidpoint) = True or False

        'Although in normal operation these are the only points of contact between the laboratory code and myOrganism, in fact 
        'all the properties of all populations are available to the laboratory code from the myOrganism object via the read-only 
        'BehaviorsInfo property of each Behaviors class.

        'Finally, note how kickout is handled in the Try...Catch block in DoARun (see "Defunct procedures no longer used" region).  
        'Some form of this must be implemented in the laboratory code.  Kickout occurs if there is a problem getting enough distinct 
        'fit behaviors to reproduce.  The code in DoARun shows how the population is restarted from a random state, but the laboratory 
        'code must also discard all the data collected up to that point and start over again.  This is the way the old code works, 
        'although we can discuss ways of handling this differently by, for example, permitting cloning or "next best" parents in the event
        'of insufficient numbers of fit parents.

        Get
            Return m_objOrganism
        End Get

    End Property

    Private Sub CreateAPopulation(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDifferent.Click

        'An organism object is instantiated when this form is loaded.

        Dim stuBehaviorsInfo As New BehaviorsInfo
        Dim objPopulation As Behaviors
        Dim objStringBuilder As New System.Text.StringBuilder

        'Read form--------------------------------------------------
        'Get discriminative stimulus
        stuBehaviorsInfo.SDID = LoadDiscriminativeStimulus()
        If stuBehaviorsInfo.SDID = -1 Then Exit Sub '  This SD as already been used.
        'Gray codes
        If chkGrayCodes.Checked Then
            stuBehaviorsInfo.UseGrayCodes = True
        Else
            stuBehaviorsInfo.UseGrayCodes = False
        End If
        'Properties
        stuBehaviorsInfo.DecayOfTransfer = CDbl(txtDecayOfTransfer.Text.Trim)
        '-----Viscosity
        If chkAddViscosity.Checked Then
            stuBehaviorsInfo.ViscosityTicks = CInt(txtViscosityTicks.Text.Trim)
            If cboViscosity.SelectedIndex = 0 Then
                '"original"
                stuBehaviorsInfo.CreateFromSynthetic = False
            Else
                '"amalgamated"
                stuBehaviorsInfo.CreateFromSynthetic = True
            End If
        Else
            'If populations are to have no viscosity, then ViscosityTicks = 0
            'Note that when ViscosityTicks = 1 there is also no viscosity.
            'When ViscosityTicks = 0, the standard method of emitting a behavior
            '(random selection among phenotypes) is used; when ViscosityTicks = 1 
            'the method based on relative frequencies is used.
            'Both methods should give the same results.
            stuBehaviorsInfo.ViscosityTicks = 0
        End If
        stuBehaviorsInfo.NumBehaviors = CInt(txtNumBehaviors.Text.Trim)
        stuBehaviorsInfo.LowPhenotype = CInt(txtFromInteger.Text.Trim)
        stuBehaviorsInfo.HighPhenotype = CInt(txtToInteger.Text.Trim)
        stuBehaviorsInfo.PercentToReplace = CInt(txtPercentToReplace.Text.Trim)
        stuBehaviorsInfo.FitnessMethod = LoadFitnessMethod()
        stuBehaviorsInfo.FitnessLandscape = LoadFitnessLandscape()
        'Data structures
        stuBehaviorsInfo.RWInfo = LoadRWInfo()
        stuBehaviorsInfo.SelectionInfo = LoadSelectionInfo()
        stuBehaviorsInfo.RecombinationInfo = LoadRecombinationInfo()
        stuBehaviorsInfo.MutationInfo = LoadMutationInfo()

        'Create and populate population of potential behaviors
        objPopulation = New Behaviors(stuBehaviorsInfo)

        'Add population to organism
        m_objOrganism.Add(objPopulation)

        'Initialize form, load discriminative stimulus into list box, write to list view, prepare
        'frequency distribution, and draw chart
        lstSD.Items.Add(stuBehaviorsInfo.SDID.ToString)
        lstSD.SelectedIndex = lstSD.Items.Count - 1
        'InitializeForm()
        'WriteToListView(objPopulation)
        'PrepareDistributionAndDrawChart(objPopulation)

        'Select the next discriminative stimulus
        If cboSD.SelectedIndex < cboSD.Items.Count - 1 Then
            cboSD.SelectedIndex = cboSD.SelectedIndex + 1
        End If

    End Sub

    Private Sub ClearPopulation(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearPopulation.Click

        Dim strItem As String

        If lstSD.Items.Count <= 1 Then
            btnClearOrganism.PerformClick()
        Else
            'Remove the population from the organism
            m_objOrganism.RemoveAt(lstSD.SelectedIndex)
            'Remove the SDID from m_objSampler
            strItem = lstSD.SelectedItem.ToString
            Select Case strItem
                Case SDColor.Red.ToString
                    m_objSampler.Remove(0)
                Case SDColor.Orange.ToString
                    m_objSampler.Remove(1)
                Case SDColor.Yellow.ToString
                    m_objSampler.Remove(2)
                Case SDColor.Green.ToString
                    m_objSampler.Remove(3)
                Case SDColor.Blue.ToString
                    m_objSampler.Remove(4)
                Case SDColor.Indigo.ToString
                    m_objSampler.Remove(5)
                Case SDColor.Violet.ToString
                    m_objSampler.Remove(6)
            End Select
            'Remove SD from list box
            lstSD.Items.RemoveAt(lstSD.SelectedIndex)
            lstSD.SelectedIndex = 0
        End If

    End Sub

    Private Sub ClearOrganism(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearOrganism.Click
        m_objOrganism.ClearOrganism()
        lstSD.Items.Clear()
        pbxSD.BackColor = Color.FromKnownColor(KnownColor.Control)
        lstConditions.Items.Clear()
        m_objSampler.Clear()
        cboSD.SelectedIndex = 0
    End Sub


#Region " Loaders"

    Public Sub LoadCreature(ByVal Organism As AnOrganism)

        'This is Nick's procedure.
        'An organism object is instantiated when this form is loaded.

        'Loops through all of the organisms behavior populations and loads them onto the form
        If Organism.Count > 0 Then
            For x = 0 To Organism.Count - 1
                Dim objPopulation As Behaviors
                Dim stuBehaviorsInfo As New BehaviorsInfo

                stuBehaviorsInfo = Organism.Item(x).BehaviorsInfo

                'Create and populate population of potential behaviors
                objPopulation = New Behaviors(stuBehaviorsInfo)

                'Add population to organism
                m_objOrganism.Add(objPopulation)

                'Initialize form, load discriminative stimulus into list box, write to list view, prepare
                'frequency distribution, and draw chart
                lstSD.Items.Add(stuBehaviorsInfo.SDID.ToString)
                lstSD.SelectedIndex = lstSD.Items.Count - 1
            Next
        End If
    End Sub

    Private Function LoadFitnessMethod() As FitnessMethod

        Select Case cboFitnessMethod.SelectedIndex
            Case 0
                'Midpoint
                'MsgBox("Midpoint fitness")
                Return FitnessMethod.Midpoint
            Case 1
                'Individual
                'MsgBox("Individual fitness")
                Return FitnessMethod.Individual
            Case 2
                'Class
                'MsgBox("Class fitness")
                Return FitnessMethod.EntireClass
            Case Else
                'Trouble
                MsgBox("Trouble in LoadFitnessMethod in frmBuildOrganism.vb")
        End Select

    End Function

    Private Function LoadFitnessLandscape() As FitnessLandscape

        Select Case cboFitnessLandscape.SelectedIndex
            Case 0
                'MsgBox("Flat landscape")
                Return FitnessLandscape.Flat
            Case 1
                'MsgBox("Circular landscape")
                Return FitnessLandscape.Circular
            Case Else
                'Trouble
                MsgBox("Trouble in LoadFitnessLandscape in frmBuildOrganism.vb")
        End Select

    End Function

    Private Function LoadRWInfo() As RescorlaWagnerParameters

        Dim stuRWInfo As RescorlaWagnerParameters

        stuRWInfo.Alpha = CDbl(Trim(txtAlpha.Text))
        stuRWInfo.Beta0 = CDbl(Trim(txtBeta0.Text))
        stuRWInfo.Beta1 = CDbl(Trim(txtBeta1.Text))
        stuRWInfo.BergA = 1 'Hard coded to 1 for now.
        stuRWInfo.Lambda = 1 ' Hard coded to 1 for now.

        Return stuRWInfo

    End Function

    Private Function LoadSelectionInfo() As SelectionInfo

        Dim stuSelectionInfo As SelectionInfo

        'Selection Method----------------------------------------------------
        Select Case cboSelectionMethod.SelectedIndex
            Case 0
                'Truncation
                'MsgBox("Truncation selection")
                stuSelectionInfo.SelectionMethod = SelectionMethod.Truncation
            Case 1
                'Tournament
                'MsgBox("Tournament selection")
                stuSelectionInfo.SelectionMethod = SelectionMethod.Tournament
            Case 2
                'Continuous
                'MsgBox("Continuous selection")
                stuSelectionInfo.SelectionMethod = SelectionMethod.Continuous
            Case Else
                'Trouble
                MsgBox("Trouble in LoadSelectionInfo in frmBuildOrganism.vb")
        End Select

        'Continuous Function Form--------------------------------------------
        Select Case cboContinuousFunctionForm.SelectedIndex
            Case 0
                'Nada
                'MsgBox("Function form not applicable.")
                stuSelectionInfo.ContinuousFunctionForm = ContinuousFunctionForm.NotApplicable 'This is new ...so watch out for (unlikely) problems
            Case 1
                'Linear
                'MsgBox("Linear function form.")
                stuSelectionInfo.ContinuousFunctionForm = ContinuousFunctionForm.Linear
            Case 2
                'Uniform
                'MsgBox("Uniform function form.")
                stuSelectionInfo.ContinuousFunctionForm = ContinuousFunctionForm.Uniform
            Case 3
                'Exponential
                'MsgBox("Exponential function form.")
                stuSelectionInfo.ContinuousFunctionForm = ContinuousFunctionForm.Exponential
            Case Else
                'Trouble
                MsgBox("Trouble in LoadSelectionInfo in frmBuildOrganism.vb.")
        End Select

        'Matchmaking Method--------------------------------------------------
        Select Case cboMatchMakingMethod.SelectedIndex
            Case 0
                'Search
                'MsgBox("Search matchmaking.")
                stuSelectionInfo.MatchmakingMethod = MatchmakingMethod.Search
            Case 1
                'Mating pool
                'MsgBox("Matching pool matchmaking.")
                stuSelectionInfo.MatchmakingMethod = MatchmakingMethod.MatingPool
            Case Else
                'Trouble
                'MsgBox("Trouble in LoadSelectionInfo in frmBuildOrganism.vb")
        End Select

        Return stuSelectionInfo

    End Function

    Private Function LoadDiscriminativeStimulus() As SDColor

        If m_objSampler.OK(cboSD.SelectedIndex) Then
            'This SD has not been used yet
            Return cboSD.SelectedIndex
        Else
            'This SD is already in use
            MessageBox.Show("This Discriminative Stimulus has been used already.", "Build Organism", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return -1
        End If

    End Function

    Private Function LoadRecombinationInfo() As RecombinationInfo

        Dim stuRecombinationInfo As RecombinationInfo

        Select Case cboRecombination.SelectedIndex
            Case 0
                'Bitwise
                'MsgBox("Bitwise recombination")
                stuRecombinationInfo.Method = RecombinationMethod.Bitwise
            Case 1
                'Crossover
                'MsgBox(CInt(cboCrossover.SelectedItem).ToString & "-point Crossover recombination")
                stuRecombinationInfo.Method = RecombinationMethod.Crossover
                stuRecombinationInfo.Points = CInt(cboCrossover.SelectedItem)
            Case 2
                'Clone
                'MsgBox("Clone recombination")
                stuRecombinationInfo.Method = RecombinationMethod.Clone
            Case Else
                'Trouble
                MsgBox("Trouble in LoadRecombinationInfo in frmBuildOrganism.")
        End Select

        Return stuRecombinationInfo

    End Function

    Private Function LoadMutationInfo() As MutationInfo

        Dim stuMutationInfo As MutationInfo

        Select Case cboMutation.SelectedIndex
            Case 0
                'Bitflip by individual
                'MsgBox("Bitflip by individual mutation.")
                stuMutationInfo.Method = MutationMethod.BitFlipByIndividual
            Case 1
                'Bitflip by bit
                'MsgBox("Bitflip by bit mutation.")
                stuMutationInfo.Method = MutationMethod.BitFlipByBit
            Case 2
                'Random individual
                'MsgBox("Random individual mutation.")
                stuMutationInfo.Method = MutationMethod.RandomIndividual
            Case 3
                'Gaussian
                'MsgBox("Gaussian mutation.")
                stuMutationInfo.Method = MutationMethod.Gaussian
                stuMutationInfo.SD = CDbl(txtGaussianSD.Text.Trim)
                Select Case cboBoundary.SelectedIndex
                    Case 0
                        'Blank
                    Case 1
                        'Discard
                        'MsgBox("Boundary discard.")
                        stuMutationInfo.Boundary = MutationBoundary.Discard
                    Case 2
                        'Wrap
                        'MsgBox("Boundary wrap.")
                        stuMutationInfo.Boundary = MutationBoundary.Wrap
                    Case Else
                        'Trouble
                        MsgBox("Trouble in LoadMutationInfo in frmBuildOrganism.")
                End Select
            Case Else
                'Trouble
                MsgBox("Trouble in LoadMutationInfo in frmBuildOrganism.")
        End Select

        stuMutationInfo.Rate = CDbl(txtMutationRate.Text.Trim)

        'Redundant info needed by the Mutator object
        If chkGrayCodes.Checked Then stuMutationInfo.GrayCodes = True Else stuMutationInfo.GrayCodes = False
        stuMutationInfo.HighPhenotype = CInt(txtToInteger.Text.Trim)
        stuMutationInfo.LowPhenotype = CInt(txtFromInteger.Text.Trim)

        Return stuMutationInfo

        'Dim rdbMutationMethod(4) As RadioButton
        'Dim i As Integer

        'rdbMutationMethod(1) = rdbBitFlipByIndividual
        'rdbMutationMethod(2) = rdbBitFlipByBit
        'rdbMutationMethod(3) = rdbRandomIndividual
        'rdbMutationMethod(4) = rdbGaussian

        'For i = 1 To 4
        '    If rdbMutationMethod(i).Checked Then
        '        Exit For
        '    End If
        'Next
        'Select Case i
        '    Case 1
        '        stuMutationInfo.Method = MutationMethod.BitFlipByIndividual
        '    Case 2
        '        stuMutationInfo.Method = MutationMethod.BitFlipByBit
        '    Case 3
        '        stuMutationInfo.Method = MutationMethod.RandomIndividual
        '    Case 4
        '        stuMutationInfo.Method = MutationMethod.Gaussian
        'End Select

        'stuMutationInfo.Rate = CDbl(txtMutationRate.Text.Trim)

        'If i = 4 Then
        '    'Gaussian mutation method.
        '    If rdbGaussianDiscard.Checked Then
        '        stuMutationInfo.Boundary = MutationBoundary.Discard
        '    Else
        '        stuMutationInfo.Boundary = MutationBoundary.Wrap
        '    End If
        '    stuMutationInfo.SD = CDbl(txtGaussianSD.Text.Trim)
        'End If

        'If chkGrayCodes.Checked Then stuMutationInfo.GrayCodes = True Else stuMutationInfo.GrayCodes = False

        'stuMutationInfo.HighPhenotype = CInt(txtToInteger.Text.Trim)
        'stuMutationInfo.LowPhenotype = CInt(txtFromInteger.Text.Trim)

        'Return stuMutationInfo

    End Function

#End Region

#Region " Form utilities"

    Private Sub LoadForm(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim randomPic As New Random

        'Select organism pic
        Select Case randomPic.Next(1, 5)
            Case 1
                PictureBox5.Image = My.Resources.cartman
                pbxSpeaker.Visible = True
                m_picID = 1
            Case 2
                PictureBox5.Image = My.Resources.Pigeon
                pbxSpeaker.Visible = False
                m_picID = 2
            Case 3
                PictureBox5.Image = My.Resources.rat
                pbxSpeaker.Visible = False
                m_picID = 3
            Case 4
                PictureBox5.Image = My.Resources.Frankenstein1
                pbxSpeaker.Visible = True
                m_picID = 4
            Case Else
                MsgBox("Trouble in form load procedure.")
        End Select

        'Set Selection ComboBox defaults
        cboFitnessMethod.SelectedIndex = 1 ' Individual
        cboFitnessLandscape.SelectedIndex = 1 ' Circular
        cboSelectionMethod.SelectedIndex = 2 ' Continuous
        cboContinuousFunctionForm.SelectedIndex = 1 ' Linear
        cboMatchMakingMethod.SelectedIndex = 0 ' Search

        'Set Recombination ComboBox default
        cboRecombination.SelectedIndex = 0 'Bitwise

        'Set Mutation ComboBox default
        cboMutation.SelectedIndex = 0 'Bitflip by individual

        'Set SD ComboBox default
        cboSD.SelectedIndex = SDColor.Red

        'Set Viscosity ComboBox default
        cboViscosity.SelectedIndex = 0 'existing

    End Sub

    Private Sub lstSD_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstSD.SelectedIndexChanged

        Dim strItem As String, intPopulationIndex As Integer
        Dim stuLocalBehaviorsInfo As New BehaviorsInfo

        Try
            strItem = lstSD.SelectedItem.ToString
        Catch ex As Exception
            'This will execute when a population is being removed.
            Exit Sub
        End Try

        Select Case strItem
            Case SDColor.Red.ToString
                pbxSD.BackColor = Color.Red
            Case SDColor.Orange.ToString
                pbxSD.BackColor = Color.Orange
            Case SDColor.Yellow.ToString
                pbxSD.BackColor = Color.Yellow
            Case SDColor.Green.ToString
                pbxSD.BackColor = Color.Green
            Case SDColor.Blue.ToString
                pbxSD.BackColor = Color.Blue
            Case SDColor.Indigo.ToString
                pbxSD.BackColor = Color.Indigo
            Case SDColor.Violet.ToString
                pbxSD.BackColor = Color.Violet
        End Select

        For intPopulationIndex = 0 To m_objOrganism.Count - 1
            If m_objOrganism.Item(intPopulationIndex).SDID.ToString = strItem Then
                Exit For
            End If
        Next
        'intPopulationIndex now identifies which population in the organism to use.
        'Set the population index to this value
        m_intPopulationIndex = intPopulationIndex
        'Draw the current frequency distribution for this population
        'chtDistribution.Series("Series1").Points.Clear()
        'PrepareDistributionAndDrawChart(m_objOrganism.Item(m_intPopulationIndex))

        'Fill the Conditions listbox---------------------------------------------------------------------------------------
        stuLocalBehaviorsInfo = m_objOrganism.Item(m_intPopulationIndex).BehaviorsInfo
        lstConditions.Items.Clear()
        lstConditions.Items.Add("Discriminative Stimulus.......................")
        lstConditions.Items.Add("     " & "alpha  = " & Format(stuLocalBehaviorsInfo.RWInfo.alpha, "0.000"))
        lstConditions.Items.Add("     " & "beta 0 = " & Format(stuLocalBehaviorsInfo.RWInfo.beta0, "0.000"))
        lstConditions.Items.Add("     " & "beta 1 = " & Format(stuLocalBehaviorsInfo.RWInfo.Beta1, "0.000"))
        lstConditions.Items.Add("     " & "decay of transfer = " & Format(stuLocalBehaviorsInfo.DecayOfTransfer, "0.00"))
        lstConditions.Items.Add("Population........................................")
        lstConditions.Items.Add("     " & stuLocalBehaviorsInfo.NumBehaviors.ToString & " behaviors")
        lstConditions.Items.Add("     " & stuLocalBehaviorsInfo.LowPhenotype.ToString & " to " & stuLocalBehaviorsInfo.HighPhenotype.ToString)
        If stuLocalBehaviorsInfo.UseGrayCodes Then
            lstConditions.Items.Add("     Gray bits")
        Else
            lstConditions.Items.Add("     Binary bits")
        End If
        If stuLocalBehaviorsInfo.ViscosityTicks > 0 Then
            If stuLocalBehaviorsInfo.CreateFromSynthetic Then
                lstConditions.Items.Add("     " & "Viscosity = " & stuLocalBehaviorsInfo.ViscosityTicks.ToString & "  amalgamated")
            Else
                lstConditions.Items.Add("     " & "Viscosity = " & stuLocalBehaviorsInfo.ViscosityTicks.ToString & "  original")
            End If
        Else
            lstConditions.Items.Add("     " & "Viscosity = N/A")
        End If
        lstConditions.Items.Add("Selection..........................................")
        lstConditions.Items.Add("     " & stuLocalBehaviorsInfo.FitnessMethod.ToString & " fitness")
        lstConditions.Items.Add("     " & stuLocalBehaviorsInfo.FitnessLandscape.ToString & " landscape")
        Select Case stuLocalBehaviorsInfo.SelectionInfo.SelectionMethod
            Case SelectionMethod.Continuous
                lstConditions.Items.Add("     Continuous " & stuLocalBehaviorsInfo.SelectionInfo.ContinuousFunctionForm.ToString & " selection")
            Case Else
                lstConditions.Items.Add("     " & stuLocalBehaviorsInfo.SelectionInfo.SelectionMethod.ToString & " selection")
        End Select
        lstConditions.Items.Add("Recombination.................................")
        If stuLocalBehaviorsInfo.RecombinationInfo.Method = RecombinationMethod.Crossover Then
            lstConditions.Items.Add("     " & stuLocalBehaviorsInfo.RecombinationInfo.Points.ToString & "-Point Crossover")
        Else
            lstConditions.Items.Add("     " & stuLocalBehaviorsInfo.RecombinationInfo.Method.ToString)
        End If
        lstConditions.Items.Add("     " & stuLocalBehaviorsInfo.PercentToReplace.ToString & "% replacement")
        lstConditions.Items.Add("Mutation...........................................")
        If stuLocalBehaviorsInfo.MutationInfo.Method = MutationMethod.Gaussian Then
            lstConditions.Items.Add("     Gaussian " & stuLocalBehaviorsInfo.MutationInfo.SD.ToString & " " & stuLocalBehaviorsInfo.MutationInfo.Boundary.ToString)
        Else
            lstConditions.Items.Add("     " & stuLocalBehaviorsInfo.MutationInfo.Method.ToString)
        End If
        lstConditions.Items.Add("     " & stuLocalBehaviorsInfo.MutationInfo.Rate.ToString & "%")

    End Sub

    Private Sub PictureBoxes_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles PictureBox5.MouseEnter, pbxSpeaker.MouseEnter
        Cursor = Cursors.Hand
    End Sub

    Private Sub PictureBoxes_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles PictureBox5.MouseLeave, pbxSpeaker.MouseLeave
        Cursor = Cursors.Default
    End Sub

    Private Sub pbxSpeaker_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pbxSpeaker.Click
        If m_picID = 1 Then My.Computer.Audio.Play(My.Resources.wantcheezyp, AudioPlayMode.Background)
        If m_picID = 4 Then My.Computer.Audio.Play(My.Resources.alonebad, AudioPlayMode.Background)
    End Sub

    Private Sub PictureBoxOrganism_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox5.Click

        Dim picID As Integer

        If m_picID = 4 Then picID = 1 Else picID = m_picID + 1
        m_picID = picID

        Select Case picID
            Case 1
                'cartman
                PictureBox5.Image = My.Resources.cartman
                pbxSpeaker.Visible = True
            Case 2
                'pigeon
                PictureBox5.Image = My.Resources.Pigeon
                pbxSpeaker.Visible = False
            Case 3
                'rat
                PictureBox5.Image = My.Resources.rat
                pbxSpeaker.Visible = False
            Case 4
                'Frankenstein
                PictureBox5.Image = My.Resources.Frankenstein1
                pbxSpeaker.Visible = True
            Case Else
                MsgBox("5")
        End Select

    End Sub

    Private Sub cboSelectionMethod_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboSelectionMethod.SelectedIndexChanged
        'Enables/Disables ContinuousFunctionForm label and combobox
        If cboSelectionMethod.SelectedIndex = 2 Then
            'Continuous Selection chosen
            cboContinuousFunctionForm.SelectedIndex = 1
            Label28.Enabled = True
            cboContinuousFunctionForm.Enabled = True
        Else
            'Truncation or Tournament Selection chosen
            cboContinuousFunctionForm.SelectedIndex = 0
            Label28.Enabled = False
            cboContinuousFunctionForm.Enabled = False
        End If
    End Sub

    Private Sub cboFitnessMethod_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboFitnessMethod.SelectedIndexChanged
        If cboFitnessMethod.SelectedIndex = 2 Then
            MessageBox.Show("The Class fitness method has not been implemeted.", "Build Organism", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1)
            cboFitnessMethod.SelectedIndex = 1
        End If
    End Sub

    Private Sub cboMatchMakingMethod_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboMatchMakingMethod.SelectedIndexChanged
        If cboMatchMakingMethod.SelectedIndex = 1 Then
            MessageBox.Show("The Mating pool matchmaking method has not been implemented.", "Build Organism", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1)
            cboMatchMakingMethod.SelectedIndex = 0
        End If
    End Sub

    Private Sub cboContinuousFunctionForm_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboContinuousFunctionForm.SelectedIndexChanged
        If cboContinuousFunctionForm.SelectedIndex = 0 And cboSelectionMethod.SelectedIndex = 2 Then
            MessageBox.Show("You must select a Continuous Function Form when using the Continuous selection method.", "Build Organism", MessageBoxButtons.OK, MessageBoxIcon.Error)
            cboContinuousFunctionForm.SelectedIndex = 1
        End If
    End Sub

    Private Sub cboBoundary_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboBoundary.SelectedIndexChanged
        If cboMutation.SelectedIndex = 3 And cboBoundary.SelectedIndex = 0 Then
            'Gaussian mutation but Null boundary method
            MessageBox.Show("You must select a Boundary method when using Gaussian mutation.", "Build Organism", MessageBoxButtons.OK, MessageBoxIcon.Error)
            cboBoundary.SelectedIndex = 2
        End If
    End Sub

    Private Sub cboRecombination_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboRecombination.SelectedIndexChanged
        If cboRecombination.SelectedIndex = 1 Then
            'Crossover recombination selected
            '---Load cboCrossover with legitimate values
            If txtToInteger.Text = "" Then
                MessageBox.Show("High phenotype must be set first.", "Build Organism", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                'Disable crossover points controls
                cboRecombination.SelectedIndex = 0 'Reset to bitwise recombination.
                cboCrossover.Enabled = False
                Label12.Enabled = False
                Exit Sub
            Else
                'Load crossover combo box with valid values
                For i As Integer = 1 To BinaryConvertBoolean.ConvertFromBase10(CInt(txtToInteger.Text.Trim)).GetUpperBound(0) - 1
                    cboCrossover.Items.Add(i.ToString)
                Next
                cboCrossover.SelectedIndex = 0 ' Items collection (array?) is zero based.
            End If
            '---Enable crossover points cbo and label
            cboCrossover.Enabled = True
            Label12.Enabled = True
        Else
            'Bitwise or clone recombination
            '---Clear cboCrossover
            cboCrossover.Items.Clear()
            cboCrossover.Text = ""
            '---Disable crossover points cbo and label
            cboCrossover.Enabled = False
            Label12.Enabled = False
        End If
    End Sub

    Private Sub cboMutation_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboMutation.SelectedIndexChanged
        If cboMutation.SelectedIndex = 3 Then
            'Gaussian mutation selection
            '----Enable and set defaults
            Label6.Enabled = True
            txtGaussianSD.Enabled = True
            Label10.Enabled = True
            cboBoundary.Enabled = True
            txtGaussianSD.Text = "5"
            cboBoundary.SelectedIndex = 2
        Else
            'A bitflip or random individual mutation select
            '----Disable and remove defaults
            Label6.Enabled = False
            txtGaussianSD.Enabled = False
            Label10.Enabled = False
            cboBoundary.Enabled = False
            txtGaussianSD.Text = ""
            cboBoundary.SelectedIndex = 0
        End If
    End Sub

    Private Sub chkAddViscosity_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkAddViscosity.CheckedChanged
        If chkAddViscosity.Checked Then
            txtViscosityTicks.Enabled = True
            txtViscosityTicks.Text = "150"
        Else
            txtViscosityTicks.Enabled = False
            txtViscosityTicks.Text = ""
        End If
    End Sub

#End Region

#Region " Defunct procedures no longer used."

    'Private Sub PictureBoxSkinner_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox3.Click
    '    My.Computer.Audio.Play(Application.StartupPath & "\skinnerShorter.wav")
    'End Sub

    'Private Sub Giddyup(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSelect.Click

    '    'This and DoARun are designed only to run the mini-laboratory on the frmBuildOrganism form.
    '    'Real experiments should be run from separate code that accesses the Creature property of this form,
    '    'as explained in the comments accompanying that property.

    '    'Once a population is created, this procedure starts an experimental run

    '    Dim dblSelectionParameter As Double
    '    Dim lowerTarget, upperTarget, intMidpoint As Integer

    '    If ProblemEntries Then Exit Sub

    '    dblSelectionParameter = CDbl(txtContinuousMean.Text)
    '    lowerTarget = CInt(txtFromPhenotype.Text)
    '    upperTarget = CInt(txtToPhenotype.Text)

    '    'Get the midpoint of the target class if necessary
    '    'The following code block ensures that when midpoint fitness is used there is an odd number of behaviors in the 
    '    'target class and hence that its midpoint is an integer.  When midpoint fintess is used, there must be an odd 
    '    'number of behaviors in all target classes.  See comments in the DrawRandomFitness function in the Selector to see 
    '    'why this is necessary at this time.  
    '    'Also, I believe this restriction is necessary to avoid the infinite loop problem when searching for a mother index.  
    '    'See comments about this in the AtLeastTwoFitPhenotypes function in the Behaviors class.
    '    'This restriction could be changed, but it is this way for now, which is the way it works in the old code.
    '    If m_objOrganism.Item(m_intPopulationIndex).BehaviorsInfo.FitnessMethod = FitnessMethod.Midpoint Then
    '        If (upperTarget - lowerTarget + 1) Mod 2 = 0 Then
    '            'Even number of behaviors in the target class.
    '            MsgBox("When using midpoint fitness there must be an odd number of behaviors in the target class(es).")
    '            Exit Sub
    '        Else
    '            intMidpoint = (upperTarget - lowerTarget) / 2 + lowerTarget
    '        End If
    '    End If

    '    Cursor = Cursors.WaitCursor
    '    Do
    '        txtSelections.Text = ""
    '    Loop Until DoARun(lowerTarget, upperTarget, dblSelectionParameter, intMidpoint)
    '    pbxSelection.BackColor = Color.White
    '    Cursor = Cursors.Default

    '    'MsgBox(Format(m_objStopwatch.ElapsedMilliseconds / 1000, "0.00") & " seconds; " & Format(m_objStopwatch.ElapsedMilliseconds / 60000, "0.00") & " minutes")

    'End Sub

    'Private Function DoARun(ByVal lowerTarget As Integer, ByVal upperTarget As Integer, ByVal dblSelectionParameter As Double, ByVal intMidpoint As Integer) As Boolean

    '    'This procedure conducts an experimental run.  Called by Giddyup.

    '    'This and Giddyup are designed only to run the mini-laboratory on the frmBuildOrganism form.
    '    'Real experiments should be run from separate code that accesses the Creature property of this form,
    '    'as explained in the comments accompanying that property.

    '    Dim emittedBehavior, targetBehaviorCount, selectionCount, numGenerations As Integer
    '    Dim objProbEmitter As New CProbEmitter

    '    numGenerations = CInt(txtGenerations.Text)
    '    objProbEmitter.ProbOfEmission = CDbl(Trim(txtSelectionProb.Text))
    '    m_objStopwatch.Reset()
    '    m_objStopwatch.Start()

    '    For i As Integer = 1 To numGenerations
    '        'Test for readiness to emit
    '        If Not m_objOrganism.Item(m_intPopulationIndex).ReadyToEmit Then
    '            MsgBox("Uh oh.  Not ready to emit.")
    '        End If
    '        'Query for emitted behavior
    '        emittedBehavior = m_objOrganism.Item(m_intPopulationIndex).EmitBehavior.IntegerValue
    '        txtEmittedBehavior.Text = emittedBehavior.ToString
    '        If emittedBehavior >= lowerTarget And emittedBehavior <= upperTarget Then targetBehaviorCount += 1
    '        'Supply selection info and set Selection property of the population
    '        If emittedBehavior >= lowerTarget And emittedBehavior <= upperTarget And objProbEmitter.Emission Then
    '            selectionCount += 1
    '            Try
    '                m_objOrganism.Item(m_intPopulationIndex).Selection(dblSelectionParameter, intMidpoint) = True
    '                'The Selection property is overloaded, so it can be passed only the selection parameter if desired, i.e.,
    '                'when midpoint fitness is not being used.
    '                'My.Computer.Audio.Stop()
    '                'My.Computer.Audio.Play(Application.StartupPath & "\SOUND16.wav", AudioPlayMode.WaitToComplete)
    '                'For j As Integer = 1 To 1000 : Application.DoEvents() : Next j
    '                pbxSelection.BackColor = Color.FromKnownColor(KnownColor.HotTrack)
    '            Catch ex As FitParentException
    '                'Looks like I could catch other exceptions with
    '                'Catch ex as Exception, and then determine which exception has been thrown.
    '                'Once it is clear that this is all working correctly, the next line can be omitted.
    '                MsgBox(ex.Message.ToString())
    '                'Start the population over.
    '                m_objOrganism.Item(m_intPopulationIndex).ResetPopulation() 'Clears the population, repopulates with random
    '                '                                                           behaviors, and resets the random number generator
    '                '                                                           to produce the Item indeces required for the 
    '                '                                                           correct operation of the Behaviors class.
    '                'Draw random population on form
    '                chtDistribution.Series("Series1").Points.Clear()
    '                PrepareDistributionAndDrawChart(m_objOrganism.Item(m_intPopulationIndex))
    '                'N.B.:  At this point, the calling program must discard saved data from this run.
    '                Return False
    '            End Try
    '        Else
    '            m_objOrganism.Item(m_intPopulationIndex).Selection(dblSelectionParameter, intMidpoint) = False
    '            pbxSelection.BackColor = Color.White
    '        End If

    '        'Write targets, selections, and ticks to form
    '        txtTargets.Text = targetBehaviorCount.ToString
    '        txtSelections.Text = selectionCount.ToString
    '        txtTicks.Text = i.ToString

    '        'Draw chart
    '        chtDistribution.Series("Series1").Points.Clear()
    '        PrepareDistributionAndDrawChart(m_objOrganism.Item(m_intPopulationIndex))
    '        For j As Integer = 1 To 10000 : Application.DoEvents() : Next

    '    Next

    '    m_objStopwatch.Stop()

    '    Return True

    'End Function

    'Private Function ProblemEntries() As Boolean
    '    If txtContinuousMean.Text = "" Or txtFromPhenotype.Text = "" Or txtToPhenotype.Text = "" Then
    '        MsgBox("You must enter boundary phenotypes and a selection parameter.")
    '        Return True
    '    Else
    '        Return False
    '    End If
    'End Function

    'Private Sub WriteToListView(ByVal objPopulation As Behaviors)
    '    Dim intCounter As Integer = -1
    '    For Each objItem As Behavior In objPopulation
    '        intCounter += 1
    '        lvwPopulation.Items.Add(objItem.IntegerValue.ToString)
    '        lvwPopulation.Items(intCounter).SubItems.Add(objItem.NumBits)
    '        lvwPopulation.Items(intCounter).SubItems.Add(objItem.BinaryBitString)
    '        lvwPopulation.Items(intCounter).SubItems.Add(objItem.GrayBitString)
    '    Next
    'End Sub

    'Private Sub PrepareDistributionAndDrawChart(ByVal objPopulation As Behaviors)

    '    Dim dblData(objPopulation.NumBehaviors) As Double
    '    Dim dblBin(objPopulation.HighPhenotype - objPopulation.LowPhenotype + 1) As Double
    '    Dim structDistribution(objPopulation.HighPhenotype - objPopulation.LowPhenotype + 1) As DistributionStorage
    '    Dim i As Integer

    '    'Get integer info for frequency distribution
    '    For Each objBehavior As Behavior In objPopulation
    '        i += 1
    '        dblData(i) = objBehavior.IntegerValue
    '    Next
    '    'Prepare bin array for frequency distribution
    '    For i = objPopulation.LowPhenotype To objPopulation.HighPhenotype
    '        dblBin(i) = i
    '    Next i
    '    '-----Get frequency distribution
    '    structDistribution = CFrequencyDist.FrequencyDistribution(dblBin, dblData)

    '    'Draw chart
    '    For i = 1 To dblBin.GetUpperBound(0)
    '        chtDistribution.Series("Series1").Points.AddY(structDistribution(i).p)
    '    Next i

    'End Sub

    'Private Sub InitializeForm()
    '    lvwPopulation.Items.Clear()
    '    chtDistribution.Series("Series1").Points.Clear()
    '    'txtReportNumMutants.Text = ""
    '    Application.DoEvents()
    'End Sub

#End Region

    Private Sub cboViscosity_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboViscosity.SelectedIndexChanged
        If cboViscosity.SelectedIndex = 1 Then
            MsgBox("This option does not work correctly.  Proceed at your own risk.")
        End If
    End Sub
End Class
