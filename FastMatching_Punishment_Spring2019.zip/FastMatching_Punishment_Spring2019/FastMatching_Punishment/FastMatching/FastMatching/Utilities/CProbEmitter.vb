'Option Strict On
'Public Class CProbEmitter

'    'This class emits events with a probability specified by the user.

'    'Usage-------------------------------------------------------------
'    'User must set the ProbOfEmission property from the calling program.
'    'User then queries the Emission property.  If this property is True, then an event has been emitted.  
'    '   If it is false, then an event has not been emitted.  If this property is queried repeatedly, then
'    '   the observed relative frequency of emission will be found to equal the ProbOfEmission.

'    Private m_probOfEmission As Double
'    Private m_objRandom As Utilities.cCalvinRandNumber

'    Public Property ProbOfEmission() As Double
'        'This is the probability of emission
'        Get
'            Return m_probOfEmission
'        End Get
'        Set(ByVal Value As Double)
'            m_probOfEmission = Value
'        End Set
'    End Property

'    Public ReadOnly Property Emission() As Boolean
'        'This property returns true if an event was emitted, false if it was not.
'        Get
'            If m_objRandom.RectangularDecimal <= m_probOfEmission Then
'                Return True
'            Else
'                Return False
'            End If
'        End Get

'    End Property

'    Sub New()
'        m_objRandom = New Utilities.cCalvinRandNumber
'    End Sub

'End Class
