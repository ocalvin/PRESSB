﻿Public Class frmPartInfo
    Private Sub frmPartInfo_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Sets the default values
        txtParticipant.Text = ""
        mskDate.Text = String.Format("{0:D2}/{1:D2}/{2:D4}", DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Year)
        mskTime.Text = FormatDateTime(DateTime.Now, DateFormat.ShortTime)
    End Sub

    Private Sub bttnBegin_Click(sender As Object, e As EventArgs) Handles bttnBegin.Click
        Dim Valid As Boolean = True

        'Checks the txtParticipant value
        If txtParticipant.Text <> "" Then
            For Each c As Char In txtParticipant.Text.ToCharArray
                'If not a number, letter, or '_' declare that there is a problem with the name and set it to be blank
                If Not ((Asc(c) >= 48 And Asc(c) <= 57) Or (Asc(c) >= 65 And Asc(c) <= 90) Or (Asc(c) >= 97 And Asc(c) <= 122) Or (Asc(c) = 95)) Then
                    Valid = False
                    ValProbTxtBox(txtParticipant)
                    Exit For
                End If

                'If all is good it changes the backcolor in case there is another problem
                txtParticipant.BackColor = Color.White
            Next
        Else
            Valid = False
            ValProbTxtBox(txtParticipant)
        End If

        'Checks the mskDate value
        If mskDate.Text <> "" Then
            For Each c As Char In mskDate.Text.ToCharArray
                'If not a number declare that there is a problem with the date
                If Not ((Asc(c) >= 48 And Asc(c) <= 57) Or (Asc(c) = 47)) Then
                    Valid = False
                    ValProbMskBox(mskDate)
                    Exit For
                End If

                'If all is good it changes the backcolor in case there is another problem
                mskDate.BackColor = Color.White
            Next
        Else
            Valid = False
            ValProbMskBox(mskDate)
        End If

        'Checks the mskTime value
        If mskTime.Text <> "" Then
            For Each c As Char In mskTime.Text.ToCharArray
                'If not a number declare that there is a problem with the time
                If Not ((Asc(c) >= 48 And Asc(c) <= 57) Or (Asc(c) = 58)) Then
                    Valid = False
                    ValProbMskBox(mskTime)
                    Exit For
                End If

                'If all is good it changes the backcolor in case there is another problem
                mskTime.BackColor = Color.White
            Next
        Else
            Valid = False
            ValProbMskBox(mskTime)
        End If

        'If there are no problems with the data that is inputted then the experiment starts
        If Valid Then
            frmFindley.Show()
            frmFindley.SetSubjectInfo(txtParticipant.Text, mskDate.Text, mskTime.Text)
            frmFindley.SetCondition = numCondition.Value
            Me.Hide()
        End If
    End Sub

    ''' <summary>
    ''' Notifies the user that there is a problem with the value that was entered
    ''' </summary>
    ''' <param name="comp"></param>
    ''' <remarks></remarks>
    Private Sub ValProbMskBox(ByRef comp As MaskedTextBox)
        comp.BackColor = Color.Pink
        comp.Focus()
        comp.Text = ""
        My.Computer.Audio.PlaySystemSound(Media.SystemSounds.Asterisk)
    End Sub

    ''' <summary>
    ''' Notifies the user that there is a problem with the value that was entered
    ''' </summary>
    ''' <param name="comp"></param>
    ''' <remarks></remarks>
    Private Sub ValProbTxtBox(ByRef comp As TextBox)
        comp.BackColor = Color.Pink
        comp.Focus()
        comp.Text = ""
        My.Computer.Audio.PlaySystemSound(Media.SystemSounds.Asterisk)
    End Sub

End Class