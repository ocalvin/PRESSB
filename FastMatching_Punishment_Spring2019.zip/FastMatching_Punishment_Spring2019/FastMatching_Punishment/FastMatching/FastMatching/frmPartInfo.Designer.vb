﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPartInfo
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.bttnBegin = New System.Windows.Forms.Button()
        Me.txtParticipant = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.mskDate = New System.Windows.Forms.MaskedTextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.mskTime = New System.Windows.Forms.MaskedTextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.numCondition = New System.Windows.Forms.NumericUpDown()
        CType(Me.numCondition, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'bttnBegin
        '
        Me.bttnBegin.Location = New System.Drawing.Point(41, 105)
        Me.bttnBegin.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.bttnBegin.Name = "bttnBegin"
        Me.bttnBegin.Size = New System.Drawing.Size(112, 29)
        Me.bttnBegin.TabIndex = 0
        Me.bttnBegin.Text = "Begin Experiment"
        Me.bttnBegin.UseVisualStyleBackColor = True
        '
        'txtParticipant
        '
        Me.txtParticipant.Location = New System.Drawing.Point(108, 6)
        Me.txtParticipant.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtParticipant.Name = "txtParticipant"
        Me.txtParticipant.Size = New System.Drawing.Size(70, 20)
        Me.txtParticipant.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(14, 9)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(71, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Participant ID"
        '
        'mskDate
        '
        Me.mskDate.Location = New System.Drawing.Point(108, 29)
        Me.mskDate.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.mskDate.Mask = "00/00/0000"
        Me.mskDate.Name = "mskDate"
        Me.mskDate.Size = New System.Drawing.Size(70, 20)
        Me.mskDate.TabIndex = 3
        Me.mskDate.ValidatingType = GetType(Date)
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(14, 32)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(30, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Date"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(14, 54)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(71, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Time (Military)"
        '
        'mskTime
        '
        Me.mskTime.Location = New System.Drawing.Point(108, 52)
        Me.mskTime.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.mskTime.Mask = "00:00"
        Me.mskTime.Name = "mskTime"
        Me.mskTime.Size = New System.Drawing.Size(70, 20)
        Me.mskTime.TabIndex = 5
        Me.mskTime.ValidatingType = GetType(Date)
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(14, 80)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(51, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Condition"
        '
        'numCondition
        '
        Me.numCondition.Location = New System.Drawing.Point(108, 76)
        Me.numCondition.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.numCondition.Maximum = New Decimal(New Integer() {12, 0, 0, 0})
        Me.numCondition.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.numCondition.Name = "numCondition"
        Me.numCondition.Size = New System.Drawing.Size(69, 20)
        Me.numCondition.TabIndex = 9
        Me.numCondition.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'frmPartInfo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(190, 144)
        Me.Controls.Add(Me.numCondition)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.mskTime)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.mskDate)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtParticipant)
        Me.Controls.Add(Me.bttnBegin)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmPartInfo"
        Me.ShowIcon = False
        Me.Text = "Participant Information"
        CType(Me.numCondition, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents bttnBegin As System.Windows.Forms.Button
    Friend WithEvents txtParticipant As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents mskDate As System.Windows.Forms.MaskedTextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents mskTime As System.Windows.Forms.MaskedTextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents numCondition As System.Windows.Forms.NumericUpDown
End Class
