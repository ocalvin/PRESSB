﻿Imports System.Windows.Forms
Imports System.Drawing

Public Class cDepressableButton
    Inherits System.Windows.Forms.Button
    Private _PreventKeyClicking As Boolean
    Private _Depressed As Boolean
    Private _KeyToRespondTo As Integer
    Private Const _PenWidth As Integer = 10
    Private Const _PreventHold As Boolean = True
    Private _PressedAlready As Boolean = False

    Public Sub New()
        MyBase.New()
    End Sub

    Public Property PressKey As Keys
        Get
            Return _KeyToRespondTo
        End Get
        Set(value As Keys)
            _KeyToRespondTo = value
        End Set
    End Property

    Public Property PreventKeyClicking As Boolean
        Get
            Return _PreventKeyClicking
        End Get
        Set(value As Boolean)
            _PreventKeyClicking = value
        End Set
    End Property

    Protected Overrides Sub OnLostFocus(e As EventArgs)
        MyBase.OnLostFocus(e)
        _Depressed = False
        InvokePaint(Me, New PaintEventArgs(Me.CreateGraphics, New Rectangle With {.X = 0, .Y = 0, .Width = Me.Width, .Height = Me.Height}))
    End Sub

    Protected Overrides Sub OnPaint(pevent As PaintEventArgs)
        MyBase.OnPaint(pevent)

        If _Depressed Then
            Dim BPen As New Pen(Color.Black, _PenWidth)
            pevent.Graphics.DrawRectangle(BPen, New Rectangle With {.X = 0, .Y = 0, .Width = Me.Width - 1, .Height = Me.Height - 1})
        End If
    End Sub

    Protected Overrides Sub OnMouseDown(mevent As MouseEventArgs)
        MyBase.OnMouseDown(mevent)
        _Depressed = True
    End Sub

    Protected Overrides Sub OnMouseUp(mevent As MouseEventArgs)
        MyBase.OnMouseUp(mevent)
        _Depressed = False
        InvokePaint(Me, New PaintEventArgs(Me.CreateGraphics, New Rectangle With {.X = 0, .Y = 0, .Width = Me.Width, .Height = Me.Height}))
    End Sub

    Protected Overrides Sub OnMouseLeave(e As EventArgs)
        MyBase.OnMouseLeave(e)
        _Depressed = False
        InvokePaint(Me, New PaintEventArgs(Me.CreateGraphics, New Rectangle With {.X = 0, .Y = 0, .Width = Me.Width, .Height = Me.Height}))
    End Sub

    Protected Overrides Sub OnKeyDown(kevent As KeyEventArgs)
        If (Not _PressedAlready) And _PreventHold Then MyBase.OnKeyDown(kevent)
        If _KeyToRespondTo = kevent.KeyValue Then _Depressed = True
        InvokePaint(Me, New PaintEventArgs(Me.CreateGraphics, New Rectangle With {.X = 0, .Y = 0, .Width = Me.Width, .Height = Me.Height}))
    End Sub

    Protected Overrides Sub OnKeyUp(kevent As KeyEventArgs)
        MyBase.OnKeyUp(kevent)
        _Depressed = False
        InvokePaint(Me, New PaintEventArgs(Me.CreateGraphics, New Rectangle With {.X = 0, .Y = 0, .Width = Me.Width, .Height = Me.Height}))
        _PressedAlready = False
    End Sub

    Protected Overrides Sub OnKeyPress(e As KeyPressEventArgs)
        If (Not _PressedAlready) And _PreventHold Then
            MyBase.OnKeyPress(e)
            _PressedAlready = True
        End If
    End Sub

    Protected Overrides Function ProcessCmdKey(ByRef msg As System.Windows.Forms.Message, ByVal keyData As System.Windows.Forms.Keys) As Boolean
        If _PreventKeyClicking Or (_PressedAlready And _PreventHold) Then
            Return True
        Else
            Return MyBase.ProcessCmdKey(msg, keyData)
        End If
    End Function
End Class
