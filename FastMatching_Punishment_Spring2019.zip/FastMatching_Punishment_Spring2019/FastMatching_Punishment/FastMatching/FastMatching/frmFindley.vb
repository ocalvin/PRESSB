﻿'CONTACT INFORMATION:
'Date Completed:     15 April 2015
'Most Recent Update: 09 April 2019
'Version:            Replication of Critchfield et al. (2003) Experiment 1 - 2.0
'Author:             Olivia L. Calvin, M.A.
'Modifier:           Bryan Klapes, M.A.
'Affiliation:        Emory University
'E-Mail:             bryan.klapes@emory.edu
'Other Contacts:     Jack McDowell - psyjjmd@emory.edu

'DISCLAIMER:
'As per Emory's Intellectual Property Policy 7.6, this intellectual property is owned by the programmer, Olivia L. Calvin.
'Modifications to the original code programmed by Olivia L. Calvin was performed by Bryan Klapes, with consent.

'PROCEDURE:
'   This form implements a set of Findley concurrent RIRI schedules (Findley, 1958). Reinforcers are awarded to the
'participant in the form of points and punishers are implemented as the loss of points. Discriminative stimuli are arrayed across
'the top of the screen to indicate the current schedule. The participant interacts with the environment through two methods: a large 
'button on the form, which constitutes a response on the current alternative, and a smaller, 'switch' button, which changes the
'current response alternative. Data is recorded in an XML file, which details each response, and in an Excel file, which provides a 
'summary. Both data files are outputted to the My Documents folder. Punishment has implemented into this form and is part of the 
'experimental procedures. The stimuli in the top left and right are based on the relative rate of reinforcement with faster rates
'being represented as larger stimuli.

'Following is the outline for this program's operation:
'   1: The experiment begins when the participant clicks bttnLever when is says "START." This sets the timer tBlockDur into effect,
'      which controls when the experiment progresses and data is output.
'   2: Once the timer tBlockDur is in effect there are three main functions that are at operating concurrently.
'       A: The participant can operate bttnLever by clicking or pressing space bar. This data is recorded in an XML file. Reinforcement 
'          and punishment stimuli are presented as needed.
'       B: The participant can operate bttnFindley by clicking or pressing "ctrl".  This action switches between the two response 
'          alternative. This data is recorded in an XML file.  The discriminative stimuli are changed as necessary.
'       C: The function tBlockDur_Tick is called when a periord of time has elapsed, which is set using the parameter _DataBlockDur. 
'          When this function is called, summary data of the participant's behavior is recorded in an Excel file. With each call the
'          _ElapsedBlocks variable is incremented by 1. If the number of elapsed blocks (i.e., _ElapsedBlocks) is equal to or greater
'          than the number indicated for that schedule (indicated in the _NumSchedBlocks array) then the experiment moves onto the next
'          schedule. If all of the schedules have been executed then the experiment terminates.
'   3: Termination of the experiment. This can occur in two ways: when the participant has been through all of the experimental
'      conditions or if the Ctrl and Q buttons are pressed at the same time. On termination, all of the data is saved and the program
'      closes.

'CONTROLS:
'- Press space bar or click the large button to respond.
'- Press "ctrl" or click the 'switch' button to switch between the two response alternatives.
'- Press "Ctrl+Q" to quit early. The data output will close successfully.

Imports DocumentFormat.OpenXml
Imports DocumentFormat.OpenXml.Packaging
Imports DocumentFormat.OpenXml.Spreadsheet

Public Class frmFindley
    'Constants that control how the experiment runs
    Private Const _RandOrder As Boolean = True       'Whether the schedules should be presented in a random order (randomizes groups with the same names in _SchedType.
    Private Const _CollectData As Boolean = True     'Whether data should be collected
    Private Const _Debug As Boolean = True          'Whether this should create debugging output
    Private Const _KeyBoardMode As Boolean = True    'Whether the keyboard can be used to interact with the schedule
    Private Const _ResponseKey As Integer = 32       'The button that counts as a response on the main button
    Private Const _SwitchKey As Integer = 17         'The button that switches between the alternatives
    Private Const _StimDur As UInteger = 250         'How long the reinforcing and punishing visual stimuli are presented
    Private Const _DataBlockDur As UInteger = 20000   'How much time (in milliseconds) needs to elapse before data is output to Excel or a schedule is evaluated for termination

    'The following 6 variables go together and should always have the same number of items. Each value controls the behavior of a specific concurrent schedule.
    '  For example, the 3rd item in each of the arrays occur at the same time.
    Private _NumSchedBlocks() As UInteger = {6, 10, 10, 10, 10, 10, 10, 10, 10, 10} 'The number of data blocks that need to elapse before moving onto the next schedule
    '                                                                                       Multiply by the _DataBlockDur to get the total time in milliseconds.
    Private _SchedType() As String = {"A", "T1", "T2", "T2", "T3", "T4", "T4", "T5", "T6", "T6"} 'A = Acquisition, T = Test, E = Extinction
    '                                                                                                   (controls how the discriminative stimuli are displayed)
    '                                                                                                   the additional number determines which blocks are randomized together
    Private _Comp1RIntervals() As UInteger = {700, 1000, 1000, 1000, 4000, 4000, 4000, 7000, 7000, 7000}  'in milliseconds (ms)
    Private _Comp2RIntervals() As UInteger = {700, 1000, 1000, 1000, 4000, 4000, 4000, 7000, 7000, 7000}  'in milliseconds (ms)
    Private _Comp1PIntervals() As UInteger = {0, 0, 2000, 1250, 0, 0, 0, 0, 14000, 8750}             'in milliseconds (ms)
    Private _Comp2PIntervals() As UInteger = {0, 0, 0, 0, 0, 8000, 5000, 0, 0, 0}                'in milliseconds (ms)
    Private _Comp1RMagnitudes() As UInteger = {1, 1, 1, 1, 1, 1, 1, 1, 1, 1}              'in points
    Private _Comp2RMagnitudes() As UInteger = {1, 1, 1, 1, 1, 1, 1, 1, 1, 1}              'in points
    Private _Comp1PMagnitudes() As Integer = {0, 0, -1, -1, 0, 0, 0, 0, -1, -1}         'in points
    Private _Comp2PMagnitudes() As Integer = {0, 0, 0, 0, 0, -1, -1, 0, 0, 0}          'in points
    Private _ForceBreak As Boolean = True                                           'Whether the participant may take a break
    Private _BreaksBefore() As UInteger = {1, 2, 3, 4, 5, 6, 7, 8, 9}           'Allow the participant to take a break this schedule ID (remember arrays start at 0)
    Private _BreakDuration As UInteger = 5000                                       'The duration of the forced break in milliseconds (ms)
    Private _CODDuration As UInteger = 500                                          'How long the COD lasts in milliseconds (ms)
    Private _RStimColor As System.Drawing.Color = System.Drawing.Color.Green        'The color of the reinforcement stimulus
    Private _RStimOffColor As System.Drawing.Color = System.Drawing.Color.DarkGreen 'The color of the reinforcement stimulus when it is turned off
    Private _PStimColor As System.Drawing.Color = System.Drawing.Color.Red          'The color of the punishment stimulus
    Private _PStimOffColor As System.Drawing.Color = System.Drawing.Color.DarkRed   'The color of the punishment stimulus when it is turned off
    Private _StimDAlt1Color As System.Drawing.Color = System.Drawing.Color.Gold     'The color of the discriminative stimulus when the 1st alternative is in effect
    Private _StimDAlt2Color As System.Drawing.Color = System.Drawing.Color.Blue     'The color of the discriminative stimulus when the 2nd alternative is in effect
    Private _DStimR As System.Drawing.Color = System.Drawing.Color.WhiteSmoke       'The color of the reinforcing discriminatve stimulus
    Private _DStimP As System.Drawing.Color = System.Drawing.Color.Orange           'The color of the punishing discriminatve stimulus
    Private _NoStim As System.Drawing.Color = System.Drawing.Color.Black            'The color when a stimulus is not active

    'The Environment
    Private _Environment As cEnvironment

    'Data output variables
    Private _XMLFile As XDocument                   'The XML document
    Private _ExcelDoc As SpreadsheetDocument        'The Excel document
    Private _XMLSaveLoc As String                   'This and the following are the save locations for the XML and Excel files
    Private _ExcelSaveLoc As String
    Private _OutputCommands As List(Of DataCommand) 'The commands sent to the environmen to collect the data that will be output to the Excel file
    Private _WSheet As Sheet                        'This is used for the Excel output
    Private RunElem As New XElement("Run")          'This and the two following elements are used for the output to the XML file
    Private TElem As New XElement("T")
    Private SchedElem As New XElement("Schedule_")
    Private _CurrentExcelRow As Integer             'The current row to be output to in excel
    Private _LastBlockCs As List(Of Integer)        'The output values at the last end of the last block
    Private _HSFile As String                       'The location of the High Score File                 

    'Variables that are used when the experiment is conducted
    Private _ElapsedBlocks As UInteger              'The number of data blocks that have elapsed since the current schedule began. Used to track 
    '                                                    whether the next schedule should begin.
    Private _Points As Integer                      'The number of points that have been collected.
    Private _Effects As List(Of Decimal)            'How the environment reacted to the participant's behavior.
    Private _Timer As Stopwatch                     'Used to track how much time has elapsed since a schedule has begun.
    Private _SchedOrder As List(Of Integer)         'The order that the schedules will be executed
    Private _ScheduleIterator As Integer             'This parameter sis used to keep track of where in _SchedOrder the experiment currently is
    Private _CurrentAlt As Integer                  '1 = First Alternative, 2 = Second Alternative
    Private _NumScheds As UInteger                  'The number of schedules in the experiment
    Private _Started As Boolean = False             'Whether the experiment has been initiated
    Private _DisableKBResp As Boolean = False       'Allows the keyboard responding to be temporarily turned off
    Private _RStimSizeDiff As Decimal               'Resizes the R stimuli based on the difference between the largest and smallest rates
    Private _PStimSizeDiff As Decimal               'Resizes the P stimuli based on the difference between the largest and smallest rates
    Private _RStimSizeMin As Decimal                'Offsets the R stimuli size based on this
    Private _PStimSizeMin As Decimal                'Offsets the R stimuli size based on this

    'Subject Information
    Private _ID As String
    Private _Date As String
    Private _Time As String

    'Highscore Info
    Private _Names As List(Of String)
    Private _TopScores As List(Of Integer)

    Private Sub frmFindley_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Counts the number of trials that will "test" the participant
        For Each s As String In _SchedType
            If s.Contains("T") Or s.Contains("t") Then _NumScheds += 1
        Next

        'Sets starting values and prepares certain parts of the environment
        _CurrentAlt = 1
        _ScheduleIterator = 0
        _ElapsedBlocks = 0
        _CurrentExcelRow = 1
        tStimDur.Interval = _StimDur
        tBlockDur.Interval = _DataBlockDur
        _XMLSaveLoc = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\test.xml"
        _ExcelSaveLoc = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\test_Summary.xlsx"

        'Initiates the objects and lists
        _Timer = New Stopwatch
        _Environment = New cEnvironment
        _OutputCommands = New List(Of DataCommand)
        _Effects = New List(Of Decimal)
        _SchedOrder = New List(Of Integer)
        _LastBlockCs = New List(Of Integer)
        _Names = New List(Of String)
        _TopScores = New List(Of Integer)

        '**The rest of this section prepares the form***
        'BK 9/23: Discriminitive stimuli will be removed for this experiment

        'Adjusts the location of the points label and the text boxes that display the points
        lblPoints.Left = (Screen.PrimaryScreen.Bounds.Width - lblPoints.Width) / 2
        txt2Place.Left = Screen.PrimaryScreen.Bounds.Width / 2
        txt1Place.Left = txt2Place.Right
        txt3Place.Left = txt2Place.Left - txt3Place.Width
        txt4Place.Left = txt3Place.Left - txt4Place.Width

        'Adjusts the placement of the "lever" and the R+ and P+ discriminative stimuli
        bttnLever.Left = (Screen.PrimaryScreen.Bounds.Width - bttnLever.Width) / 2
        pnlRStim.Left = bttnLever.Left - pnlRStim.Width * 1.5
        pnlPStim.Left = bttnLever.Right + pnlPStim.Width / 2
        bttnFindley.Left = (Screen.PrimaryScreen.Bounds.Width - bttnFindley.Width) / 2
        bttnLever.PressKey = _ResponseKey
        bttnFindley.PressKey = _SwitchKey
    End Sub

    ''' <summary>
    ''' Starts the experiment
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub StartExperiment()
        Dim maxP, maxR, minR, minP As UInteger

        'Prepares the environment to begin accepting responses
        BuildEnvironment() 'This sub-routine constructs the environment together
        _Environment.Prepare()

        'Adds all of the unique schedule IDs
        For Each sched As ExpSchedule In _Environment.Schedules
            If Not _SchedOrder.Contains(sched.Schedule) Then _SchedOrder.Add(sched.Schedule)
        Next

        'Randomizes the schedule if necessary
        If _RandOrder Then
            'This section randomizes the schedules that have been given the same name in _SchedType
            Dim SchuffledItems As New List(Of String)
            Dim SchufPos As New List(Of Integer)
            Dim SchufItems As New List(Of Integer)

            'To Schuffle
            For x = 0 To _SchedType.Count - 1
                If Not SchuffledItems.Contains(_SchedType(x)) Then 'The the current item in the list has not been previously schuffled
                    'Resets the lists
                    SchufItems = New List(Of Integer)
                    SchufPos = New List(Of Integer)

                    'Adds the items to their respective lists
                    For y = x To _SchedType.Count - 1
                        If _SchedType(y) = _SchedType(x) Then
                            SchufItems.Add(y)
                            SchufPos.Add(y)
                        End If
                    Next

                    'Shuffles where the items will be located
                    SchufPos = ShuffleList(SchufPos)

                    For z = 0 To SchufItems.Count - 1
                        _SchedOrder(SchufPos(z)) = SchufItems(z)
                    Next

                    'Adds to the list of what has been completed
                    SchuffledItems.Add(_SchedType(x))
                End If
            Next

            If _Debug Then
                Dim s As String = "Schedule Order: "
                For x = 0 To _SchedOrder.Count - 1
                    s &= _SchedOrder(x) & IIf(x <> _SchedOrder.Count - 1, ", ", "")
                Next
                Debug.Print(s)
            End If
        End If

        'Starts the data output. StartOutput is a sub-routine that prepares the data output to both Excel and XML.
        If _CollectData Then StartOutput()

        'Goes through the schedules and sets the environment with the applicable values
        For Each sched As ExpSchedule In _Environment.Schedules
            If sched.Schedule = _SchedOrder(_ScheduleIterator) Then
                _Environment.Components(sched.CompID).ParamVal(sched.ParamName) = sched.ParamVal
            End If
        Next
        _Environment.Prepare()

        '***The following section sets up the stimuli display variables***
        'Finds the size of the slowest reinforcer rate
        For x = 0 To _Comp1RIntervals.Count - 1
            If _Comp1RIntervals(x) > maxR Then maxR = _Comp1RIntervals(x)
            If _Comp1RIntervals(x) < minR And _Comp1RIntervals(x) <> 0 Then minR = _Comp1RIntervals(x)
        Next
        For x = 0 To _Comp2RIntervals.Count - 1
            If _Comp2RIntervals(x) > maxR Then maxR = _Comp2RIntervals(x)
            If _Comp2RIntervals(x) < minR And _Comp2RIntervals(x) <> 0 Then minR = _Comp2RIntervals(x)
        Next

        'Finds the size of the slowest punisher rate
        For x = 0 To _Comp1PIntervals.Count - 1
            If _Comp1PIntervals(x) > maxP Then maxP = _Comp1PIntervals(x)
            If _Comp1PIntervals(x) < minP And _Comp1PIntervals(x) <> 0 Then minP = _Comp1PIntervals(x)
        Next
        For x = 0 To _Comp2PIntervals.Count - 1
            If _Comp2PIntervals(x) > maxP Then maxP = _Comp2PIntervals(x)
            If _Comp2PIntervals(x) < minP And _Comp2PIntervals(x) <> 0 Then minP = _Comp2PIntervals(x)
        Next

        'Sets the rate of reinforcement and punishment
        _RStimSizeDiff = maxR - minR
        _RStimSizeMin = minR
        _PStimSizeDiff = maxP - minP
        _PStimSizeMin = minP
        '***End Section***

        'Changes the form's display to start of the experiment and sets the _Started parameter to True
        _Started = True
        bttnLever.Text = ""
        DispSD(_SchedOrder(_ScheduleIterator))

        'Starts the timers
        _Timer.Restart()
        tBlockDur.Start() 'See tBlockDur_Tick to see how the end of each block is handled for output and the schedules are advanced.

        'Debug output
        If _Debug Then Debug.Print("Experiment Successfully Started")

        'Hides the top scores
        lstScores.Visible = False
        lblScores.Visible = False

        
    End Sub

    Public WriteOnly Property SetCondition As Integer
        Set(value As Integer)
            Select Case value
                Case 1 '1-4-7, 1 More Punished
                    _HSFile = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\BehaviorData\FindleyRIRI_OverlaidP\TopScores.txt"
                Case 2 '1-4-7, 2 More Punished
                    _Comp1RIntervals = {700, 1000, 1000, 1000, 4000, 4000, 4000, 7000, 7000, 7000}  'in milliseconds (ms)
                    _Comp2RIntervals = {700, 1000, 1000, 1000, 4000, 4000, 4000, 7000, 7000, 7000}  'in milliseconds (ms)
                    _Comp1PIntervals = {0, 0, 0, 0, 0, 8000, 5000, 0, 0, 0}                        'in milliseconds (ms)
                    _Comp2PIntervals = {0, 0, 2000, 1250, 0, 0, 0, 0, 14000, 8750}                 'in milliseconds (ms)
                    _Comp1PMagnitudes = {0, 0, 0, 0, 0, -1, -1, 0, 0, 0}                          'in points
                    _Comp2PMagnitudes = {0, 0, -1, -1, 0, 0, 0, 0, -1, -1}                            'in points
                    _HSFile = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\BehaviorData\FindleyRIRI_OverlaidP\TopScores.txt"
                Case 3 '1-7-4, 1 More Punished
                    _Comp1RIntervals = {700, 1000, 1000, 1000, 7000, 7000, 7000, 4000, 4000, 4000}  'in milliseconds (ms)
                    _Comp2RIntervals = {700, 1000, 1000, 1000, 7000, 7000, 7000, 4000, 4000, 4000}  'in milliseconds (ms)
                    _Comp1PIntervals = {0, 0, 2000, 1250, 0, 0, 0, 0, 8000, 5000}                    'in milliseconds (ms)
                    _Comp2PIntervals = {0, 0, 0, 0, 0, 14000, 8750, 0, 0, 0}                         'in milliseconds (ms)
                    _HSFile = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\BehaviorData\FindleyRIRI_OverlaidP\TopScores.txt"
                Case 4 '1-7-4, 2 More Punished
                    _Comp1RIntervals = {700, 1000, 1000, 1000, 7000, 7000, 7000, 4000, 4000, 4000}  'in milliseconds (ms)
                    _Comp2RIntervals = {700, 1000, 1000, 1000, 7000, 7000, 7000, 4000, 4000, 4000}  'in milliseconds (ms)
                    _Comp1PIntervals = {0, 0, 0, 0, 0, 14000, 8750, 0, 0, 0}                         'in milliseconds (ms)
                    _Comp2PIntervals = {0, 0, 2000, 1250, 0, 0, 0, 0, 8000, 5000}                    'in milliseconds (ms)
                    _Comp1PMagnitudes = {0, 0, 0, 0, 0, -1, -1, 0, 0, 0}                          'in points
                    _Comp2PMagnitudes = {0, 0, -1, -1, 0, 0, 0, 0, -1, -1}                            'in points
                    _HSFile = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\BehaviorData\FindleyRIRI_OverlaidP\TopScores.txt"
                Case 5 '4-1-7, 1 More Punished
                    _Comp1RIntervals = {700, 4000, 4000, 4000, 1000, 1000, 1000, 7000, 7000, 7000}  'in milliseconds (ms)
                    _Comp2RIntervals = {700, 4000, 4000, 4000, 1000, 1000, 1000, 7000, 7000, 7000}  'in milliseconds (ms)
                    _Comp1PIntervals = {0, 0, 8000, 5000, 0, 0, 0, 0, 14000, 8750}                    'in milliseconds (ms)
                    _Comp2PIntervals = {0, 0, 0, 0, 0, 2000, 1250, 0, 0, 0}                         'in milliseconds (ms)
                    _HSFile = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\BehaviorData\FindleyRIRI_OverlaidP\TopScores.txt"
                Case 6 '4-1-7, 2 More Punished
                    _Comp1RIntervals = {700, 4000, 4000, 4000, 1000, 1000, 1000, 7000, 7000, 7000}  'in milliseconds (ms)
                    _Comp2RIntervals = {700, 4000, 4000, 4000, 1000, 1000, 1000, 7000, 7000, 7000}  'in milliseconds (ms)
                    _Comp1PIntervals = {0, 0, 0, 0, 0, 2000, 1250, 0, 0, 0}                       'in milliseconds (ms)
                    _Comp2PIntervals = {0, 0, 8000, 5000, 0, 0, 0, 0, 14000, 8750}                'in milliseconds (ms)
                    _Comp1PMagnitudes = {0, 0, 0, 0, 0, -1, -1, 0, 0, 0}                          'in points
                    _Comp2PMagnitudes = {0, 0, -1, -1, 0, 0, 0, 0, -1, -1}                            'in points
                    _HSFile = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\BehaviorData\FindleyRIRI_OverlaidP\TopScores.txt"
                Case 7 '4-7-1, 1 More Punished
                    _Comp1RIntervals = {700, 4000, 4000, 4000, 7000, 7000, 7000, 1000, 1000, 1000}  'in milliseconds (ms)
                    _Comp2RIntervals = {700, 4000, 4000, 4000, 7000, 7000, 7000, 1000, 1000, 1000}  'in milliseconds (ms)
                    _Comp1PIntervals = {0, 0, 8000, 5000, 0, 0, 0, 0, 2000, 1250}                   'in milliseconds (ms)
                    _Comp2PIntervals = {0, 0, 0, 0, 0, 14000, 8750, 0, 0, 0}                         'in milliseconds (ms)
                    _HSFile = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\BehaviorData\FindleyRIRI_OverlaidP\TopScores.txt"
                Case 8 '4-7-1, 2 More Punished
                    _Comp1RIntervals = {700, 4000, 4000, 4000, 7000, 7000, 7000, 1000, 1000, 1000}  'in milliseconds (ms)
                    _Comp2RIntervals = {700, 4000, 4000, 4000, 7000, 7000, 7000, 1000, 1000, 1000}  'in milliseconds (ms)
                    _Comp1PIntervals = {0, 0, 0, 0, 0, 14000, 8750, 0, 0, 0}                        'in milliseconds (ms)
                    _Comp2PIntervals = {0, 0, 8000, 5000, 0, 0, 0, 0, 2000, 1250}                     'in milliseconds (ms)
                    _Comp1PMagnitudes = {0, 0, 0, 0, 0, -1, -1, 0, 0, 0}                          'in points
                    _Comp2PMagnitudes = {0, 0, -1, -1, 0, 0, 0, 0, -1, -1}                            'in points
                    _HSFile = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\BehaviorData\FindleyRIRI_OverlaidP\TopScores.txt"
                Case 9 '7-1-4, 1 More Punished
                    _Comp1RIntervals = {700, 7000, 7000, 7000, 1000, 1000, 1000, 4000, 4000, 4000}  'in milliseconds (ms)
                    _Comp2RIntervals = {700, 7000, 7000, 7000, 1000, 1000, 1000, 4000, 4000, 4000}  'in milliseconds (ms)
                    _Comp1PIntervals = {0, 0, 14000, 8750, 0, 0, 0, 0, 8000, 5000}                    'in milliseconds (ms)
                    _Comp2PIntervals = {0, 0, 0, 0, 0, 2000, 1250, 0, 0, 0}                         'in milliseconds (ms)
                    _HSFile = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\BehaviorData\FindleyRIRI_OverlaidP\TopScores.txt"
                Case 10 '7-1-4, 2 More Punished
                    _Comp1RIntervals = {700, 7000, 7000, 7000, 1000, 1000, 1000, 4000, 4000, 4000}  'in milliseconds (ms)
                    _Comp2RIntervals = {700, 7000, 7000, 7000, 1000, 1000, 1000, 4000, 4000, 4000}  'in milliseconds (ms)
                    _Comp1PIntervals = {0, 0, 0, 0, 0, 2000, 1250, 0, 0, 0}                       'in milliseconds (ms)
                    _Comp2PIntervals = {0, 0, 14000, 8750, 0, 0, 0, 0, 8000, 5000}                'in milliseconds (ms)
                    _Comp1PMagnitudes = {0, 0, 0, 0, 0, -1, -1, 0, 0, 0}                          'in points
                    _Comp2PMagnitudes = {0, 0, -1, -1, 0, 0, 0, 0, -1, -1}                            'in points
                    _HSFile = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\BehaviorData\FindleyRIRI_OverlaidP\TopScores.txt"
                Case 11 '7-4-1, 1 More Punished
                    _Comp1RIntervals = {700, 7000, 7000, 7000, 4000, 4000, 4000, 1000, 1000, 1000}  'in milliseconds (ms)
                    _Comp2RIntervals = {700, 7000, 7000, 7000, 4000, 4000, 4000, 1000, 1000, 1000}  'in milliseconds (ms)
                    _Comp1PIntervals = {0, 0, 14000, 8750, 0, 0, 0, 0, 2000, 1250}                  'in milliseconds (ms)
                    _Comp2PIntervals = {0, 0, 0, 0, 0, 8000, 5000, 0, 0, 0}                         'in milliseconds (ms)
                    _HSFile = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\BehaviorData\FindleyRIRI_OverlaidP\TopScores.txt"
                Case 12 '7-4-1, 2 More Punished
                    _Comp1RIntervals = {700, 7000, 7000, 7000, 4000, 4000, 4000, 1000, 1000, 1000}  'in milliseconds (ms)
                    _Comp2RIntervals = {700, 7000, 7000, 7000, 4000, 4000, 4000, 1000, 1000, 1000}  'in milliseconds (ms)
                    _Comp1PIntervals = {0, 0, 0, 0, 0, 8000, 5000, 0, 0, 0}                        'in milliseconds (ms)
                    _Comp2PIntervals = {0, 0, 14000, 8750, 0, 0, 0, 0, 2000, 1250}                     'in milliseconds (ms)
                    _Comp1PMagnitudes = {0, 0, 0, 0, 0, -1, -1, 0, 0, 0}                          'in points
                    _Comp2PMagnitudes = {0, 0, -1, -1, 0, 0, 0, 0, -1, -1}                            'in points
                    _HSFile = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\BehaviorData\FindleyRIRI_OverlaidP\TopScores.txt"
            End Select


            'Loads the high scores
            If IO.File.Exists(_HSFile) Then
                Dim HS As New IO.StreamReader(_HSFile)
                Do
                    Dim l As String
                    l = HS.ReadLine()
                    _Names.Add(l.Split(Chr(9))(0))
                    _TopScores.Add(CInt(l.Split(Chr(9))(1)))
                Loop Until HS.EndOfStream
                HS.Close()
            Else
                _Names.Add("???")
                _Names.Add("???")
                _Names.Add("???")
                _Names.Add("???")
                _Names.Add("???")
                _TopScores.Add(0)
                _TopScores.Add(0)
                _TopScores.Add(0)
                _TopScores.Add(0)
                _TopScores.Add(0)
            End If

            'Shows the high scores
            lblScores.Left = ((pnlPStim.Right + Screen.PrimaryScreen.Bounds.Width - lblScores.Width) / 2)
            lstScores.Left = lblScores.Left + (lblScores.Width - lstScores.Width) / 2
            lstScores.Items.Clear()

            For x = 0 To _Names.Count - 1
                lstScores.Items.Add(_Names(x) & " - " & _TopScores(x))
            Next
        End Set
    End Property


    ''' <summary>
    ''' This ends the experiment by saving all of the data and closing the form.
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub TerminateExperiment()
        'Ends the experiment and saves all data
        If _CollectData And _Started Then 'Finalizes data for a worksheet
            _XMLFile.Element("Experiment").Element("Runs").Add(RunElem)
            _ExcelDoc.WorkbookPart.Workbook.Save()
            _XMLFile.Save(_XMLSaveLoc)
            _ExcelDoc.WorkbookPart.Workbook.Save()
            _ExcelDoc.Close()
        End If

        'Check to see if the participant's score makes it into the top scores
        For x = 0 To _TopScores.Count - 1
            If _TopScores(x) <= _Points Then
                Dim N As String = ""

                Do
                    N = InputBox("You just beat a high score! Type in three letters to represent you in the top scores.", "High Score!")

                    If N.Length <> 3 Then N = ""
                Loop Until N <> ""

                'Adds in the new top score
                _TopScores.Insert(x, _Points)
                _Names.Insert(x, N)
                _TopScores.RemoveAt(_TopScores.Count - 1)
                _Names.RemoveAt(_Names.Count - 1)

                'Writes the scores
                Dim SW As New IO.StreamWriter(_HSFile, False)
                For y = 0 To _TopScores.Count - 1
                    SW.WriteLine(_Names(y) & Chr(9) & _TopScores(y))
                Next
                SW.Close()

                'Kicks out of the loop
                Exit For
            End If
        Next

        'Closes the form and then ends the program
        Me.Close()
        End
    End Sub

    ''' <summary>
    ''' Detects the key press combination of "Ctrl+Q" to allow for early termination and saves the data up to that point.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub KeyBoardDetection(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        'Quits if "Ctrl+Q" is pressed
        If (e.KeyCode And Not Keys.Modifiers) = Keys.Q AndAlso e.Modifiers = Keys.Control Then
            TerminateExperiment() 'Saves the data that has been collected
            Me.Close() 'Closes the program
        End If

        'Handles Keyboardmode
        If _KeyBoardMode And Not _DisableKBResp Then
            Select Case e.KeyCode
                Case _ResponseKey
                    bttnLever.Focus()
                    bttnLever_Click(sender, e)
                    bttnFindley_KeyUp(sender, e)
                Case _SwitchKey
                    bttnFindley.Focus()
                    bttnFindley_Click(sender, e)
                    bttnLever_KeyUp(sender, e)
                Case Else
                    e.Handled = True
            End Select
        Else
            e.Handled = True
        End If
    End Sub

    ''' <summary>
    ''' Builds the environment that the experiment utilizes
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub BuildEnvironment()
        With _Environment
            'Adds the necessary components
            .Components.Add(New cELever_PRange)                     'Comp #0 (L1)
            .Components.Add(New cELever_PRange)                     'Comp #1 (L2)
            .Components.Add(New cETape_RandomIntervalExponential)   'Comp #2 (T1)
            .Components.Add(New cETape_RandomIntervalExponential)   'Comp #3 (T2)
            .Components.Add(New cETape_RandomIntervalExponential)   'Comp #4 (T3)
            .Components.Add(New cETape_RandomIntervalExponential)   'Comp #5 (T4)
            .Components.Add(New cEMagazine_Fixed)                   'Comp #6 (M1)
            .Components.Add(New cEMagazine_Fixed)                   'Comp #7 (M2)
            .Components.Add(New cEMagazine_Fixed)                   'Comp #8 (M1)
            .Components.Add(New cEMagazine_Fixed)                   'Comp #9 (M2)
            .Components.Add(New cEChangeOver_Fixed)                 'Comp #10 (COD)

            'Sets the priority order (i.e., the order of execution; lower numbers go first and numbers that are the same occur simultaneously)
            .Components(0).Priority = 1
            .Components(1).Priority = 1
            .Components(10).Priority = 2
            .Components(2).Priority = 3
            .Components(3).Priority = 3
            .Components(4).Priority = 3
            .Components(5).Priority = 3
            .Components(6).Priority = 4
            .Components(7).Priority = 4
            .Components(8).Priority = 4
            .Components(9).Priority = 4

            'Sets the parameters of the apparatus
            .Components(0).ParamVal("LBound") = 1
            .Components(0).ParamVal("UBound") = 1
            .Components(1).ParamVal("LBound") = 2
            .Components(1).ParamVal("UBound") = 2
            .Components(10).ParamVal("Duration") = _CODDuration

            'Adds the experimental schedules
            For x = 0 To _NumSchedBlocks.Count - 1
                .Schedules.Add(New ExpSchedule With {.Schedule = x, .CompID = 2, .ParamName = "Interval", .ParamVal = _Comp1RIntervals(x)})
                .Schedules.Add(New ExpSchedule With {.Schedule = x, .CompID = 3, .ParamName = "Interval", .ParamVal = _Comp2RIntervals(x)})
                .Schedules.Add(New ExpSchedule With {.Schedule = x, .CompID = 4, .ParamName = "Interval", .ParamVal = _Comp1PIntervals(x)})
                .Schedules.Add(New ExpSchedule With {.Schedule = x, .CompID = 5, .ParamName = "Interval", .ParamVal = _Comp2PIntervals(x)})
                .Schedules.Add(New ExpSchedule With {.Schedule = x, .CompID = 6, .ParamName = "Amount", .ParamVal = _Comp1RMagnitudes(x)})
                .Schedules.Add(New ExpSchedule With {.Schedule = x, .CompID = 7, .ParamName = "Amount", .ParamVal = _Comp2RMagnitudes(x)})
                .Schedules.Add(New ExpSchedule With {.Schedule = x, .CompID = 8, .ParamName = "Amount", .ParamVal = _Comp1PMagnitudes(x)})
                .Schedules.Add(New ExpSchedule With {.Schedule = x, .CompID = 9, .ParamName = "Amount", .ParamVal = _Comp2PMagnitudes(x)})
            Next

            'Wires the components together
            .Components(0).WireTo(2)    'L1 to T1
            .Components(0).WireTo(4)    'L1 to T3
            .Components(0).WireTo(10)   'L1 to COD
            .Components(1).WireTo(3)    'L2 to T2
            .Components(1).WireTo(5)    'L2 to T4
            .Components(1).WireTo(10)   'L2 to COD
            .Components(10).WireTo(2)   'COD to T1
            .Components(10).WireTo(3)   'COD to T2
            .Components(10).WireTo(4)   'COD to T3
            .Components(10).WireTo(5)   'COD to T4
            .Components(2).WireTo(6)    'T1 to M1
            .Components(3).WireTo(7)    'T2 to M2
            .Components(4).WireTo(8)    'T3 to M3
            .Components(5).WireTo(9)    'T4 to M4
        End With

        _Environment.Prepare()
    End Sub


    ''' <summary>
    ''' Outputs data and determines the consequences of the participant's behavior.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub bttnLever_Click(sender As Object, e As EventArgs) Handles bttnLever.Click
        If _Started = False Then
            StartExperiment() '_Started is set to True in this sub-routine
        Else
            Dim time As UInteger = _Timer.ElapsedMilliseconds 'Collects the time so this is the same value throughout this function

            If _Debug Then Debug.Print("Press Time: " & time)

            'Determines how the environment responds to the participant's behavior and makes sure that information is displayed to the participant
            _Effects.Clear()
            _Effects.AddRange(_Environment.ReceiveBehavior(_CurrentAlt, time))
            DispConsq(_Effects) 'This sub-routine displays the environmental consequences (i.e., point changes and stimuli presentation)

            'Outputs the current time, the alternative that was selected, and whether it was reinforced or punished
            If _CollectData Then
                'Sets the tie
                TElem = New XElement("T_" & time)

                'Outputs "1" if the user clicked while the 1st alternative was in effect or "2" if the 2nd alternative was in effect
                TElem.Add(New XAttribute("b", _CurrentAlt))
                If _Effects.Count > 0 Then
                    Dim r = 0, p As Decimal = 0

                    'Adds together all of the reinforcers and punishers
                    For Each eff As Decimal In _Effects
                        If eff > 0 Then r += eff
                        If eff < 0 Then p += eff
                    Next

                    'Outputs the net reinforcemena and punishment magnitudes (in points)
                    If r > 0 Then TElem.Add(New XAttribute("r", r))
                    If p < 0 Then TElem.Add(New XAttribute("p", p))
                End If

                'Adds the behavior and consequences to the current schedule's XML data
                SchedElem.Add(TElem)
            End If
        End If
    End Sub

    ''' <summary>
    ''' Switches between the response alternatives, displays the changes in the discriminative stimulus/stimuli, and outputs data.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub bttnFindley_Click(sender As Object, e As EventArgs) Handles bttnFindley.Click
        'Ensures that this has no effect if the experiment has not begun.
        If _Started Then
            Dim time As UInteger = _Timer.ElapsedMilliseconds 'Collects the time so this is the same value throughout this function

            'Alternates between the 1st and 2nd response alternative, sends the behavior to the environment, and displays the change in the discriminative stimulus.
            '    The effects of the environment are not displayed because reinforcement and punishment cannot occur due to the changeover delay.
            _CurrentAlt = IIf(_CurrentAlt = 1, 2, 1)
            _Environment.ReceiveBehavior(_CurrentAlt, time)
            DispSD(_SchedOrder(_ScheduleIterator))

            'Outputs the current time, what the new alternative is, and a CO parameter that indicates that a changeover occured
            If _CollectData Then
                TElem = New XElement("T_" & time)
                TElem.Add(New XAttribute("b", _CurrentAlt))
                TElem.Add(New XAttribute("CO", 1))
                SchedElem.Add(TElem)
            End If

            If _Debug Then Debug.Print("Change Over Time:" & time)
        End If
    End Sub

    ''' <summary>
    ''' Displays the changes in points and the R and P stimuli.
    ''' </summary>
    ''' <param name="Effects">The programmed consequences of the environment</param>
    ''' <remarks></remarks>
    Private Sub DispConsq(ByVal Effects As List(Of Decimal))
        Dim RStim = False, PStim As Boolean = False
        Dim StartPoints As Integer = _Points

        'Determines how the environmental effects should be displayed
        For Each e As Decimal In Effects
            If e > 0 Then RStim = True
            If e < 0 Then PStim = True
            _Points += Int(e)
        Next

        'Presents the reinforcement stimuli (only presents auditory stimulus if a net gain)
        If RStim Then
            pnlRStim.BackColor = _RStimColor
            If StartPoints < _Points Then My.Computer.Audio.Play(My.Resources.BellDing, AudioPlayMode.Background)
        End If

        'Presents the punishment stimuli (only presents auditory stimulus if a net loss)
        If PStim Then
            pnlPStim.BackColor = _PStimColor
            If StartPoints > _Points Then My.Computer.Audio.Play(My.Resources.Loss, AudioPlayMode.Background)
        End If

        'Restarts the stimuli timer so that the R and P stimuli end after the elapsed time
        ' (See tStimDur_Tick to see what occurs when the timer elapses)
        If RStim Or PStim Then tStimDur.Stop() : tStimDur.Start()

        'Displays the points
        If _Points < 0 Then _Points = 0 'Ensures that points cannot become negative
        txt4Place.Text = Int((_Points Mod 10000) / 1000)
        txt3Place.Text = Int((_Points Mod 1000) / 100)
        txt2Place.Text = Int((_Points Mod 100) / 10)
        txt1Place.Text = (_Points Mod 10)
    End Sub

    ''' <summary>
    ''' Displays the current discriminative stimulus/stimuli
    ''' </summary>
    ''' <param name="CurrStim">The current schedule iteration which determines the discriminative stimulus display.</param>
    ''' <remarks></remarks>
    Private Sub DispSD(ByVal CurrStim As UInteger)
        'BK 9/23: Discriminitive stiumli for schedules have been removed for this experiment
        'Displays the color of the current discriminative stimulus
        bttnLever.BackColor = IIf(_CurrentAlt = 1, _StimDAlt1Color, _StimDAlt2Color)
    End Sub

    Private Sub tStimDur_Tick(sender As Object, e As EventArgs) Handles tStimDur.Tick
        'Stops the timer
        tStimDur.Stop()

        'Resets the R and P stimuli to being turned off
        pnlPStim.BackColor = _PStimOffColor
        pnlRStim.BackColor = _RStimOffColor
    End Sub

    ''' <summary>
    ''' This keeps track of the experiment's progress and performs all of the necessary data output at the correct times.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub tBlockDur_Tick(sender As Object, e As EventArgs) Handles tBlockDur.Tick
        'Counts the number of blocks that have elapsed
        _ElapsedBlocks += 1

        'Outputs the data for the most recent block
        If _CollectData Then
            _CurrentExcelRow += 1 'Advances which row the data should be output to.
            InsertValue(_ExcelDoc, _SchedOrder(_ScheduleIterator) + 1, "A", _CurrentExcelRow) 'Outputs the current schedule number

            'Outputs the data that was collected by the environment
            For x = 0 To _OutputCommands.Count - 1
                _Environment.Components(_OutputCommands(x).Component).SpeedUpdateOut()
                InsertValue(_ExcelDoc, CInt(_Environment.Components(_OutputCommands(x).Component).OutputVal(_OutputCommands(x).Command)) - _LastBlockCs(x), Chr(Asc("B") + x), _CurrentExcelRow)
                _LastBlockCs(x) = (CInt(_Environment.Components(_OutputCommands(x).Component).OutputVal(_OutputCommands(x).Command)))
            Next
        End If

        If _Debug Then Debug.Print("Block Advanced -> Block Num: " & _ElapsedBlocks)

        'If the current schedules's time has elapsed it advances the schedule
        If _ElapsedBlocks >= _NumSchedBlocks(_SchedOrder(_ScheduleIterator)) Then
            'Sets the values that track the experiment's progress
            _ElapsedBlocks = 0
            _ScheduleIterator += 1

            'Stops the block timer
            tBlockDur.Stop()

            'Takes a break if necessary
            If _ForceBreak And _BreaksBefore.Contains(_ScheduleIterator) Then
                Dim EndTime As UInteger = _Timer.ElapsedMilliseconds + _BreakDuration

                bttnFindley.Enabled = False
                bttnFindley.Text = ""
                bttnLever.Enabled = False
                _DisableKBResp = True

                'Forces the user to take a break
                Do
                    bttnLever.Text = String.Format("Break For:" & Chr(13) & "{0}" & Chr(58) & "{1:00}", Int((EndTime - _Timer.ElapsedMilliseconds) / 60000), Int(((EndTime - _Timer.ElapsedMilliseconds) Mod 60000) / 1000))
                    Application.DoEvents()
                Loop Until _Timer.ElapsedMilliseconds >= EndTime

                Dim EndBreak
                Do Until EndBreak = vbOK
                    EndBreak = MsgBox("The break is over. Press the OK button to continue the task.", MsgBoxStyle.DefaultButton2 + MsgBoxStyle.OkCancel, "Break")
                Loop
                _DisableKBResp = False
                bttnLever.Text = ""
                bttnFindley.Text = "SWITCH"
                bttnFindley.Enabled = True
                bttnLever.Enabled = True
            End If

            'Adds the last batch of schedule information
            If _CollectData Then RunElem.Add(SchedElem)

            'If the experiment is not over then...
            If _ScheduleIterator < _NumSchedBlocks.Count Then
                'Creates a new Schedule element
                If _CollectData Then SchedElem = New XElement("Schedule_" & _SchedOrder(_ScheduleIterator))

                'Sets all of the parameter values for the next schedule
                For x As UInteger = 0 To _Environment.Schedules.Count - 1
                    If _Environment.Schedules(x).Schedule = _SchedOrder(_ScheduleIterator) Then
                        With _Environment.Schedules(x)
                            _Environment.Components(.CompID).ParamVal(.ParamName) = .ParamVal
                        End With
                    End If
                Next

                'Resets the data counts that were collected from the environment
                For x = 0 To _LastBlockCs.Count - 1 : _LastBlockCs(x) = 0 : Next

                'Displays the current discriminative stimulus
                DispSD(_SchedOrder(_ScheduleIterator))

                'Resets the environment and sets it up to run quickly.
                _Environment.Prepare()

                'Restarts the timer (i.e., sets the time to 0 and starts tracking the time from there.)
                _Timer.Restart()
            Else
                'Ends the experiment
                TerminateExperiment()
            End If
        End If

        'Restarts the block timer
        tBlockDur.Start()
    End Sub

    ''' <summary>
    ''' Prevents the user from interacting with the text boxes that display the number of collected points.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub RedirectFocus(sender As Object, e As EventArgs) Handles txt1Place.GotFocus, txt2Place.GotFocus, txt3Place.GotFocus, txt4Place.GotFocus
        Me.Focus()
    End Sub

    ''' <summary>
    ''' Prevents the user from interacting with the text boxes that display the number of collected points.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Points_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt1Place.KeyPress, txt2Place.KeyPress, txt3Place.KeyPress, txt4Place.KeyPress
        e.KeyChar = ""
    End Sub

#Region "Data Output Sub-Routines, Functions, and Structures"
    ''' <summary>
    ''' The location where the data XML file will be saved.
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub SetSaveName(ByVal Name As String)
        Dim FolderPath As String

        'The following is put in place a test to see if the 
        If Not Name.Contains("\") Then
            Name = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\BehaviorData\FindleyRIRI_OverlaidP\" & Name 'Defaults to the MyDocuments folder
        End If

        'Ensures that the resulting file is readibly identified as an XML file
        If Not Name.Contains(".xml") Then Name = Name & ".xml"

        'Sets the names that will be used for data output.
        _XMLSaveLoc = Name
        _ExcelSaveLoc = Name.Replace(".xml", "_Summary.xlsx")

        'Creates the path to the folder
        FolderPath = Name
        FolderPath = FolderPath.Remove(InStrRev(FolderPath, "\"))

        'Creates the folder directory for the save's information
        If Not System.IO.Directory.Exists(FolderPath) Then
            System.IO.Directory.CreateDirectory(FolderPath)
        End If
    End Sub

    ''' <summary>
    ''' Sets the subject's information that will be outputed to the data files.
    ''' </summary>
    ''' <param name="Id">The subjects information</param>
    ''' <param name="D">The current date</param>
    ''' <param name="T">The current time</param>
    ''' <remarks></remarks>
    Public Sub SetSubjectInfo(ByVal Id As String, ByVal D As String, ByVal T As String)
        _ID = Id
        _Date = D
        _Time = T

        SetSaveName(_ID)
    End Sub

    ''' <summary>
    ''' Initializes the XML document that stores the experimental run and fills in some of the information.
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub StartOutput()
        _XMLFile = New XDocument
        _XMLFile.Add(New XElement("Experiment"))

        'Adds the subject's information
        _XMLFile.Element("Experiment").Add(New XElement("Subject"))
        _XMLFile.Element("Experiment").Element("Subject").Add(New XAttribute("Time", _Time))
        _XMLFile.Element("Experiment").Element("Subject").Add(New XAttribute("Date", _Date))
        _XMLFile.Element("Experiment").Element("Subject").Add(New XAttribute("ID", _ID))

        'Adds the description of the environment
        _XMLFile.Element("Experiment").Add(_Environment.EnvironmentXML)

        'Adds a description of the experimental manipulations to the environment.
        If _Environment.ScheduleCount > 0 Then
            _XMLFile.Element("Experiment").Add(_Environment.ScheduleXML)
        End If

        'Add runs section (this will be filled in during the experiment)
        _XMLFile.Element("Experiment").Add(New XElement("Runs"))

        'Saves the XML file
        _XMLFile.Save(_XMLSaveLoc)


        '***Prepares the Excel File for output***
        'Creates the output document for the current run
        _ExcelDoc = SpreadsheetDocument.Create(_ExcelSaveLoc, SpreadsheetDocumentType.Workbook)
        Dim WB As WorkbookPart = _ExcelDoc.AddWorkbookPart
        WB.Workbook = New Workbook

        ' Add a WorksheetPart to the WorkbookPart.
        Dim worksheetPart As WorksheetPart = WB.AddNewPart(Of WorksheetPart)()
        worksheetPart.Worksheet = New Worksheet(New SheetData())

        ' Add Sheets to the Workbook.
        _ExcelDoc.WorkbookPart.Workbook.AppendChild(Of Sheets)(New Sheets())

        ' Add an experiment WS and associate it with the workbook.
        Dim sheet As Sheet = New Sheet With {.Id = _ExcelDoc.WorkbookPart.GetIdOfPart(worksheetPart), .SheetId = 1, .Name = "Experiment"}
        _ExcelDoc.WorkbookPart.Workbook.Sheets.Append(sheet)

        Dim LongDesc As String
        Dim Desc() As String

        'Outputs the environment
        LongDesc = _Environment.TextDescription
        LongDesc = Replace(LongDesc, "  ", "__")
        Desc = LongDesc.Split(Chr(13))

        ' Insert cell A1 into the new worksheet.
        InsertText(_ExcelDoc, "***Experiment***", "A", 1)

        For x = 0 To UBound(Desc)
            InsertText(_ExcelDoc, Desc(x), "A", x + 2)
        Next

        'Outputs the subject's information
        InsertText(_ExcelDoc, "Subject ID: " & _ID, "C", 1)
        InsertText(_ExcelDoc, "Date: " & _Date, "C", 2)
        InsertText(_ExcelDoc, "Time: " & _Time, "C", 3)

        WB.Workbook.Save()

        'This sets up the commands that will request data and will provide information for the column headers
        PrepareOutCommands()

        RunElem = New XElement("Run")

        ' Add a WorksheetPart to the WorkbookPart.
        Dim worksheetPart2 As WorksheetPart = _ExcelDoc.WorkbookPart.AddNewPart(Of WorksheetPart)()
        worksheetPart2.Worksheet = New Worksheet(New SheetData())

        ' Add an experiment WS and associate it with the workbook.
        _WSheet = New Sheet With {.Id = _ExcelDoc.WorkbookPart.GetIdOfPart(worksheetPart2), .SheetId = 2, .Name = "Organism"}
        _ExcelDoc.WorkbookPart.Workbook.Sheets.Append(_WSheet)

        InsertText(_ExcelDoc, "Schedule", "A", _CurrentExcelRow)
        If _OutputCommands.Count > 0 Then
            For x = 0 To _OutputCommands.Count - 1
                InsertText(_ExcelDoc, _OutputCommands(x).Component & "_" & _OutputCommands(x).Command, Chr(Asc("B") + x), _CurrentExcelRow)
            Next
        End If

        SchedElem = New XElement("Schedule_" & _SchedOrder(_ScheduleIterator))
    End Sub

    ''' <summary>
    ''' Prepares the program to collect data at every data block
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub PrepareOutCommands()
        _OutputCommands.Clear()
        _LastBlockCs.Clear()

        'Prepares the list of output commands
        For x = 0 To _Environment.Components.Count - 1
            If _Environment.Components(x).OutputCount > 0 Then
                For y = 0 To _Environment.Components(x).OutputCount - 1
                    _OutputCommands.Add(New DataCommand With {.Component = x, .Command = _Environment.Components(x).OutputName(y)})
                    _LastBlockCs.Add(0)
                Next
            End If
        Next
    End Sub

    ' Given a document name and text, 
    ' inserts a new worksheet and writes the text to cell "A1" of the new worksheet.
    Private Sub InsertText(ByRef SS As SpreadsheetDocument, ByVal text As String, ByVal col As String, ByVal rowID As UInteger)
        ' Get the SharedStringTablePart. If it does not exist, create a new one.
        Dim shareStringPart As SharedStringTablePart

        If (SS.WorkbookPart.GetPartsOfType(Of SharedStringTablePart).Count() > 0) Then
            shareStringPart = SS.WorkbookPart.GetPartsOfType(Of SharedStringTablePart).First()
        Else
            shareStringPart = SS.WorkbookPart.AddNewPart(Of SharedStringTablePart)()
        End If

        ' Insert the text into the SharedStringTablePart.
        Dim index As Integer = InsertSharedStringItem(text, shareStringPart)

        ' Insert cell A1 into the new worksheet.
        Dim cell As Cell = InsertCellInWorksheet(col, rowID, SS.WorkbookPart.Workbook.WorkbookPart.WorksheetParts.Last)

        ' Set the value of cell A1.
        cell.CellValue = New CellValue(index.ToString)
        cell.DataType = New EnumValue(Of CellValues)(CellValues.SharedString)
    End Sub

    Private Sub InsertValue(ByRef SS As SpreadsheetDocument, ByVal Value As Decimal, ByVal col As String, ByVal rowID As UInteger)
        ' Insert cell A1 into the new worksheet.
        Dim cell As Cell = InsertCellInWorksheet(col, rowID, SS.WorkbookPart.Workbook.WorkbookPart.WorksheetParts.Last)

        ' Set the value of cell A1.
        cell.CellValue = New CellValue(Value)
        cell.DataType = New EnumValue(Of CellValues)(CellValues.Number)
    End Sub

    ' Given text and a SharedStringTablePart, creates a SharedStringItem with the specified text 
    ' and inserts it into the SharedStringTablePart. If the item already exists, returns its index.
    Private Function InsertSharedStringItem(ByVal text As String, ByVal shareStringPart As SharedStringTablePart) As Integer
        ' If the part does not contain a SharedStringTable, create one.
        If (shareStringPart.SharedStringTable Is Nothing) Then
            shareStringPart.SharedStringTable = New SharedStringTable
        End If

        Dim i As Integer = 0

        ' Iterate through all the items in the SharedStringTable. If the text already exists, return its index.
        For Each item As SharedStringItem In shareStringPart.SharedStringTable.Elements(Of SharedStringItem)()
            If (item.InnerText = text) Then
                Return i
            End If
            i = (i + 1)
        Next

        ' The text does not exist in the part. Create the SharedStringItem and return its index.
        shareStringPart.SharedStringTable.AppendChild(New SharedStringItem(New DocumentFormat.OpenXml.Spreadsheet.Text(text)))
        shareStringPart.SharedStringTable.Save()

        Return i
    End Function

    ' Given a column name, a row index, and a WorksheetPart, inserts a cell into the worksheet. 
    ' If the cell already exists, return it.
    Private Function InsertCellInWorksheet(ByVal columnName As String, ByVal rowIndex As UInteger, ByVal worksheetPart As WorksheetPart) As Cell
        Dim worksheet As Worksheet = worksheetPart.Worksheet
        Dim sheetData As SheetData = worksheet.GetFirstChild(Of SheetData)()
        Dim cellReference As String = (columnName + rowIndex.ToString())

        ' If the worksheet does not contain a row with the specified row index, insert one.
        Dim row As Row
        If (sheetData.Elements(Of Row).Where(Function(r) r.RowIndex.Value = rowIndex).Count() <> 0) Then
            row = sheetData.Elements(Of Row).Where(Function(r) r.RowIndex.Value = rowIndex).First()
        Else
            row = New Row()
            row.RowIndex = rowIndex
            sheetData.Append(row)
        End If

        ' If there is not a cell with the specified column name, insert one.  
        If (row.Elements(Of Cell).Where(Function(c) c.CellReference.Value = columnName + rowIndex.ToString()).Count() > 0) Then
            Return row.Elements(Of Cell).Where(Function(c) c.CellReference.Value = cellReference).First()
        Else
            ' Cells must be in sequential order according to CellReference. Determine where to insert the new cell.
            Dim refCell As Cell = Nothing
            For Each cell As Cell In row.Elements(Of Cell)()
                If (String.Compare(cell.CellReference.Value, cellReference, True) > 0) Then
                    refCell = cell
                    Exit For
                End If
            Next

            Dim newCell As Cell = New Cell
            newCell.CellReference = cellReference

            row.InsertBefore(newCell, refCell)
            worksheet.Save()

            Return newCell
        End If
    End Function

    Private Structure DataCommand
        Public Component As Integer
        Public Command As String
    End Structure
#End Region

    Protected Overrides Function ProcessCmdKey(ByRef msg As Message, keyData As Keys) As Boolean
        Select Case CType(msg.WParam.ToInt32, Keys)
            Case Keys.Enter
                'Disables the Enter key from clicking the first button on the form.
                Return True
            Case Else
                Return MyBase.ProcessCmdKey(msg, keyData)
        End Select
    End Function

    Private Sub bttnFindley_KeyUp(sender As Object, e As KeyEventArgs) Handles bttnFindley.KeyUp

    End Sub

    Private Sub bttnLever_KeyUp(sender As Object, e As KeyEventArgs) Handles bttnLever.KeyUp

    End Sub
End Class
