﻿Public Module modShufflevb
    Public Function ShuffleList(ByVal values As List(Of Integer)) As List(Of Integer)
        Dim TempList As New List(Of Integer)
        Dim TempList2 As New List(Of Integer)
        Dim TempID As Integer
        Dim Rand As New cCalvinRandNumber

        Rand.HighestInteger = values.Count - 1
        Rand.LowestInteger = 0

        TempList2.AddRange(values)

        'Performs the shuffle 10 times
        '   Once is insufficient to completely undo the orderring. For example, in cards it is necessary to perform a riffle shuffle 7 times which
        '   this method roughly approximates.
        For x = 0 To 9
            Do
                'Resets the highest integer that random can sample
                Rand.HighestInteger = TempList2.Count - 1

                'Pulls a random integer
                TempID = Rand.RectangularInteger

                'Pulls out of the other list and inserts it into the temp list
                TempList.Add(TempList2(TempID))
                TempList2.RemoveAt(TempID)
            Loop Until TempList2.Count = 0

            TempList2.AddRange(TempList)
            TempList.Clear()
        Next

        Return TempList2
    End Function
End Module
