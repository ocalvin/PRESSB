﻿Module StringFunction
    '''<summary>
    '''Examine a string and return the number of instances that a particular character is present in it.
    '''</summary>
    ''' <param name="S">The string to be examined</param>
    ''' <param name="C">The character to be checked for</param>
    '''<remarks></remarks>
    Public Function CountChars(ByVal S As String, ByVal C As Char) As Integer
        CountChars = 0

        For X = 1 To Len(S)
            If CChar(Mid(S, X, 1)) = C Then CountChars += 1
        Next

        Return CountChars
    End Function
End Module
