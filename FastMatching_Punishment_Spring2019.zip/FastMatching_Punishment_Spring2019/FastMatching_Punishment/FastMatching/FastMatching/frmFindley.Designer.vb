﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmFindley
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.txt3Place = New System.Windows.Forms.TextBox()
        Me.pnlRStim = New System.Windows.Forms.Panel()
        Me.pnlPStim = New System.Windows.Forms.Panel()
        Me.lblPoints = New System.Windows.Forms.Label()
        Me.txt4Place = New System.Windows.Forms.TextBox()
        Me.txt2Place = New System.Windows.Forms.TextBox()
        Me.txt1Place = New System.Windows.Forms.TextBox()
        Me.tBlockDur = New System.Windows.Forms.Timer(Me.components)
        Me.tStimDur = New System.Windows.Forms.Timer(Me.components)
        Me.lstScores = New System.Windows.Forms.ListBox()
        Me.lblScores = New System.Windows.Forms.Label()
        Me.bttnFindley = New QLEFastMatching.cDepressableButton()
        Me.bttnLever = New QLEFastMatching.cDepressableButton()
        Me.SuspendLayout()
        '
        'txt3Place
        '
        Me.txt3Place.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt3Place.Location = New System.Drawing.Point(638, 228)
        Me.txt3Place.Name = "txt3Place"
        Me.txt3Place.Size = New System.Drawing.Size(40, 40)
        Me.txt3Place.TabIndex = 1
        Me.txt3Place.TabStop = False
        Me.txt3Place.Text = "0"
        Me.txt3Place.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'pnlRStim
        '
        Me.pnlRStim.BackColor = System.Drawing.Color.DarkGreen
        Me.pnlRStim.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlRStim.ForeColor = System.Drawing.Color.Black
        Me.pnlRStim.Location = New System.Drawing.Point(230, 381)
        Me.pnlRStim.Name = "pnlRStim"
        Me.pnlRStim.Size = New System.Drawing.Size(154, 131)
        Me.pnlRStim.TabIndex = 2
        '
        'pnlPStim
        '
        Me.pnlPStim.BackColor = System.Drawing.Color.DarkRed
        Me.pnlPStim.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlPStim.ForeColor = System.Drawing.Color.Khaki
        Me.pnlPStim.Location = New System.Drawing.Point(967, 381)
        Me.pnlPStim.Name = "pnlPStim"
        Me.pnlPStim.Size = New System.Drawing.Size(154, 131)
        Me.pnlPStim.TabIndex = 3
        '
        'lblPoints
        '
        Me.lblPoints.AutoSize = True
        Me.lblPoints.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblPoints.Font = New System.Drawing.Font("Microsoft Sans Serif", 30.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPoints.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblPoints.Location = New System.Drawing.Point(613, 177)
        Me.lblPoints.Name = "lblPoints"
        Me.lblPoints.Size = New System.Drawing.Size(132, 46)
        Me.lblPoints.TabIndex = 10
        Me.lblPoints.Text = "Points"
        '
        'txt4Place
        '
        Me.txt4Place.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt4Place.Location = New System.Drawing.Point(601, 228)
        Me.txt4Place.Name = "txt4Place"
        Me.txt4Place.Size = New System.Drawing.Size(40, 40)
        Me.txt4Place.TabIndex = 11
        Me.txt4Place.TabStop = False
        Me.txt4Place.Text = "0"
        Me.txt4Place.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt2Place
        '
        Me.txt2Place.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt2Place.Location = New System.Drawing.Point(676, 228)
        Me.txt2Place.Name = "txt2Place"
        Me.txt2Place.Size = New System.Drawing.Size(40, 40)
        Me.txt2Place.TabIndex = 12
        Me.txt2Place.TabStop = False
        Me.txt2Place.Text = "0"
        Me.txt2Place.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt1Place
        '
        Me.txt1Place.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt1Place.Location = New System.Drawing.Point(712, 228)
        Me.txt1Place.Name = "txt1Place"
        Me.txt1Place.Size = New System.Drawing.Size(40, 40)
        Me.txt1Place.TabIndex = 13
        Me.txt1Place.TabStop = False
        Me.txt1Place.Text = "0"
        Me.txt1Place.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tBlockDur
        '
        '
        'tStimDur
        '
        '
        'lstScores
        '
        Me.lstScores.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstScores.FormattingEnabled = True
        Me.lstScores.ItemHeight = 29
        Me.lstScores.Location = New System.Drawing.Point(1187, 522)
        Me.lstScores.Margin = New System.Windows.Forms.Padding(2)
        Me.lstScores.Name = "lstScores"
        Me.lstScores.SelectionMode = System.Windows.Forms.SelectionMode.None
        Me.lstScores.Size = New System.Drawing.Size(151, 149)
        Me.lstScores.TabIndex = 17
        Me.lstScores.TabStop = False
        '
        'lblScores
        '
        Me.lblScores.AutoSize = True
        Me.lblScores.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblScores.Location = New System.Drawing.Point(1182, 488)
        Me.lblScores.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblScores.Name = "lblScores"
        Me.lblScores.Size = New System.Drawing.Size(173, 31)
        Me.lblScores.TabIndex = 18
        Me.lblScores.Text = "High Scores"
        Me.lblScores.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'bttnFindley
        '
        Me.bttnFindley.Font = New System.Drawing.Font("Microsoft Sans Serif", 30.0!, System.Drawing.FontStyle.Bold)
        Me.bttnFindley.Location = New System.Drawing.Point(412, 622)
        Me.bttnFindley.Margin = New System.Windows.Forms.Padding(2)
        Me.bttnFindley.Name = "bttnFindley"
        Me.bttnFindley.PressKey = System.Windows.Forms.Keys.None
        Me.bttnFindley.PreventKeyClicking = False
        Me.bttnFindley.Size = New System.Drawing.Size(525, 106)
        Me.bttnFindley.TabIndex = 16
        Me.bttnFindley.TabStop = False
        Me.bttnFindley.Text = "SWITCH"
        Me.bttnFindley.UseVisualStyleBackColor = True
        '
        'bttnLever
        '
        Me.bttnLever.Font = New System.Drawing.Font("Microsoft Sans Serif", 30.0!, System.Drawing.FontStyle.Bold)
        Me.bttnLever.Location = New System.Drawing.Point(412, 289)
        Me.bttnLever.Margin = New System.Windows.Forms.Padding(2)
        Me.bttnLever.Name = "bttnLever"
        Me.bttnLever.PressKey = System.Windows.Forms.Keys.None
        Me.bttnLever.PreventKeyClicking = False
        Me.bttnLever.Size = New System.Drawing.Size(525, 313)
        Me.bttnLever.TabIndex = 15
        Me.bttnLever.TabStop = False
        Me.bttnLever.Text = "START"
        Me.bttnLever.UseVisualStyleBackColor = True
        '
        'frmFindley
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DimGray
        Me.ClientSize = New System.Drawing.Size(1370, 772)
        Me.Controls.Add(Me.lblScores)
        Me.Controls.Add(Me.lstScores)
        Me.Controls.Add(Me.bttnFindley)
        Me.Controls.Add(Me.bttnLever)
        Me.Controls.Add(Me.txt1Place)
        Me.Controls.Add(Me.txt2Place)
        Me.Controls.Add(Me.txt4Place)
        Me.Controls.Add(Me.lblPoints)
        Me.Controls.Add(Me.pnlPStim)
        Me.Controls.Add(Me.pnlRStim)
        Me.Controls.Add(Me.txt3Place)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.KeyPreview = True
        Me.Name = "frmFindley"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Two Alternative Response Panel"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.ResumeLayout(False)
        Me.PerformLayout

End Sub
    Friend WithEvents txt3Place As System.Windows.Forms.TextBox
    Friend WithEvents pnlRStim As System.Windows.Forms.Panel
    Friend WithEvents pnlPStim As System.Windows.Forms.Panel
    Friend WithEvents lblPoints As System.Windows.Forms.Label
    Friend WithEvents txt4Place As System.Windows.Forms.TextBox
    Friend WithEvents txt2Place As System.Windows.Forms.TextBox
    Friend WithEvents txt1Place As System.Windows.Forms.TextBox
    Friend WithEvents tBlockDur As System.Windows.Forms.Timer
    Friend WithEvents tStimDur As System.Windows.Forms.Timer
    Friend WithEvents bttnLever As QLEFastMatching.cDepressableButton
    Friend WithEvents bttnFindley As QLEFastMatching.cDepressableButton
    Friend WithEvents lstScores As System.Windows.Forms.ListBox
    Friend WithEvents lblScores As System.Windows.Forms.Label

End Class
