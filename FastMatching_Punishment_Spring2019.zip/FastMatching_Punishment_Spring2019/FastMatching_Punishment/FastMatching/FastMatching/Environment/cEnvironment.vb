﻿
'This class is in charge of executing the new experiments and collecting data
Public Class cEnvironment
    Public Schedules As New List(Of ExpSchedule)
    Public Components As List(Of cEBaseComponents)
    Private _Time As Decimal
    Private _TimeIncrement As Decimal
    Private _Effects As List(Of Decimal)
    Private _CRunOrd As List(Of UInteger)
    Private _Prepared As Boolean

    Public Sub New()
        Components = New List(Of cEBaseComponents)
        _Effects = New List(Of Decimal)
        _CRunOrd = New List(Of UInteger)
        _Time = 0
        _Prepared = False
        _TimeIncrement = 1
    End Sub

    Public Function Copy() As cEnvironment
        Dim TempE As New cEnvironment

        For Each comp As cEBaseComponents In Components
            TempE.Components.Add(comp.Copy)
        Next

        For Each sched As ExpSchedule In Schedules
            TempE.Schedules.Add(sched)
        Next

        TempE._Time = Me._Time
        TempE._Prepared = False
        TempE._TimeIncrement = Me._TimeIncrement
        TempE.SortComponents()
        TempE.Prepare()

        Return TempE
    End Function

    ''' <summary>
    ''' The order that the components are processed.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property ComponentRunOrder As List(Of UInteger)
        Get
            Return _CRunOrd
        End Get
    End Property

    ''' <summary>
    ''' Returns the number of unique schedules that have ben set up for the experiment.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property ScheduleCount As Integer
        Get
            Dim SchedulesUsed As New List(Of UInteger)

            For Each sched As ExpSchedule In Schedules
                If Not SchedulesUsed.Contains(sched.schedule) Then
                    SchedulesUsed.Add(sched.schedule)
                End If
            Next

            Return SchedulesUsed.Count
        End Get
    End Property

    ''' <summary>
    ''' Creates an XML description of the experimental schedules
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property ScheduleXML As XElement
        Get
            Dim TempElem As New XElement("Schedules")

            For Each sched As ExpSchedule In Schedules
                If IsNothing(TempElem.Element("s_" & sched.schedule.ToString)) Then
                    TempElem.Add(New XElement("s_" & sched.schedule.ToString))
                End If

                TempElem.Element("s_" & sched.schedule.ToString).Add(New XElement("Comp_" & sched.compID.ToString))
                TempElem.Element("s_" & sched.schedule.ToString).Element("Comp_" & sched.compID.ToString).Add(New XAttribute("param", sched.ParamName), _
                                                                                                              New XAttribute("val", sched.ParamVal.ToString))
            Next

            Return TempElem
        End Get
    End Property

    ''' <summary>
    ''' A text description of the environment
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property TextDescription As String
        Get
            Dim TempS As String

            'Outputs a list of the components
            TempS = "Components: " & Chr(13)
            For v = 0 To Components.Count - 1
                TempS &= "  " & Components(v).Type & " of Type " & Components(v).Name & Chr(13)

                For x = 0 To Components(v).ParamCount - 1
                    Dim Exper As Boolean = False

                    For Each S As ExpSchedule In Schedules
                        If S.compID = v And S.ParamName = Components(v).ParamName(x) Then Exper = True
                    Next

                    If Exper Then
                        TempS &= "    " & Components(v).ParamName(x) & " = "

                        For Each S As ExpSchedule In Schedules
                            If S.compID = v And S.ParamName = Components(v).ParamName(x) Then
                                TempS &= S.ParamVal & ","
                            End If
                        Next
                        'Removes the extra ','
                        TempS = TempS.Remove(TempS.LastIndexOf(","), 1)
                    Else
                        TempS &= "    " & Components(v).ParamName(x) & " = " & Components(v).ParamVal(x)
                    End If

                    'finishes the libe
                    TempS &= Chr(13)
                Next
            Next

            'Outputs a list of how the components are wired
            TempS &= Chr(13) & "Wiring: " & Chr(13)
            If Components.Count > 0 Then
                For x = 0 To Components.Count - 1
                    If Components(x).ConnectionCount > 0 Then
                        For y = 0 To Components(x).ConnectionCount - 1
                            TempS &= "  " & x & "-->" & Components(x).ConnectionTarget(y) & Chr(13)
                        Next
                    End If
                Next
            End If

            Return TempS
        End Get
    End Property

    ''' <summary>
    ''' Creates an XML description of the environment.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property EnvironmentXML As XElement
        Get
            Dim TempElem As New XElement("Environment")
            TempElem.Add(New XElement("Wiring"))
            Dim SubElement As XElement 'Strictly unneccessary but makes for easier reading

            'Writes all of the components in XML format
            For x = 0 To Components.Count - 1
                'Lists the components name and type
                SubElement = New XElement("Component_" & x)
                SubElement.Add(New XAttribute("type", Components(x).Type), _
                               New XAttribute("name", Components(x).Name))

                'Adds a description of all  of the parameters
                If Components(x).ParamCount > 0 Then
                    For y = 0 To Components(x).ParamCount - 1
                        SubElement.Add(New XElement(Components(x).ParamName(y)))
                        SubElement.Element(Components(x).ParamName(y)).Add(New XAttribute("val", Components(x).ParamVal(y)))
                    Next
                End If

                'Writes all of the connections
                If Components(x).ConnectionCount > 0 Then
                    For y = 0 To Components(x).ConnectionCount - 1
                        TempElem.Element("Wiring").Add(New XElement("Connection"))
                        TempElem.Element("Wiring").Elements("Connection").Last.Add(New XAttribute("from", x),
                                                                                   New XAttribute("to", Components(x).ConnectionTarget(y)))
                    Next
                End If

                'Adds the current component
                TempElem.Add(SubElement)
            Next

            'Returns the entire set of elements
            Return TempElem
        End Get
    End Property

    ''' <summary>
    ''' Prepares the environment for the beginning of an experiment.  Resets all of the components, time, 
    ''' and prepares the order of operations.
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Prepare()
        'Resets the time data
        _Time = 0

        'Sorts the components and prepares them to run
        SortComponents()
        For Each c As cEBaseComponents In Components
            c.Reset()
            c.SpeedPrep()
        Next

        _Prepared = True
    End Sub

    ''' <summary>
    ''' Allows for interaction with the programmed environment and the return of a respose.
    ''' </summary>
    ''' <param name="beh">The decimal representation of the behavior the creature emitted.</param>
    ''' <param name="Time">Use the provided time rather than the iterative time.</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function ReceiveBehavior(ByVal beh As Decimal, Optional Time As Decimal = -1) As List(Of Decimal)
        If Not _Prepared Then Throw New Exception("Class cEnvironment: The environment has not been prepared for testing.")

        'Sets the current time based on either the provided time or the incrementation of time.
        If Time <> -1 Then
            _Time = Time
        Else
            _Time += _TimeIncrement
        End If

        'Clears out the effects that occured during the last phase.
        _Effects.Clear()

        'Goes through all of the components in priority order
        For v = 0 To Components.Count - 1
            With Components(_CRunOrd(v))
                'If the unit can interact, determine whether it is affected 
                If .Interacts Then .DetectTouch(beh, _Time)

                'Determine whether the unit will be powered
                .CheckPower(_Time)

                'If is powered then send power to the components that connect to the component
                If .Sending Then
                    If Not .OverridesConnections Then
                        For x = 0 To .ConnectionCount - 1
                            Components(.ConnectionTarget(x)).ReceivePower(v, .Conduct)
                        Next
                    Else
                        'This is split out so that this property minimally slows down the process.
                        For x = 0 To .ConnectionCount - 1
                            If Not .OverrideConnection(x) Then Components(.ConnectionTarget(x)).ReceivePower(v, .Conduct)
                        Next
                    End If
                End If

                'Collects the effects that will affect the organism
                If .Affects And .IsPowered Then _Effects.Add(.Deliver(_Time))
            End With
        Next

        'Prepares and returns a list of all of the effects that occured.
        ReceiveBehavior = New List(Of Decimal)
        ReceiveBehavior.AddRange(_Effects)
        Return ReceiveBehavior
    End Function

    ''' <summary>
    ''' This goes through and sorts the components based on priority ratings to ensure the proper order of operations.
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SortComponents()
        Dim LowID As Integer
        Dim NumSorts As Integer = Components.Count - 1

        _CRunOrd.Clear()

        'Reorders all of the components
        For x = 0 To NumSorts
            LowID = 0

            'Determines the order that the components operate in.
            For y = 0 To Components.Count - 1
                If _CRunOrd.Contains(LowID) Then
                    LowID = y
                Else
                    If Not _CRunOrd.Contains(y) Then
                        If Components(LowID).Priority > Components(y).Priority Then LowID = y
                    End If
                End If
            Next

            'Adds to the new list and removes from the old list
            _CRunOrd.Add(LowID)
        Next
    End Sub
End Class

Public Structure ExpSchedule
    Public Schedule As UInteger
    Public CompID As UInteger
    Public ParamName As String
    Public ParamVal As Object
End Structure