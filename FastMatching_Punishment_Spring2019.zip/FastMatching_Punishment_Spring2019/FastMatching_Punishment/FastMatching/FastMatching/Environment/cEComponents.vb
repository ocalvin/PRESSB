﻿#Region "Levers"

Public Class cELever_PRange
    Inherits cELever
    Private _Lbound, _Ubound As Integer
    Private _Inv As Boolean
    Private _WrapAround As Boolean

    Public Sub New()
        MyBase.New()

        _Params.Add("LBound", "The lower bound of the phenotype range.", 0I)
        _Params.Add("UBound", "The upper bound of the phenotype range.", 40I)
        _Params.Add("Inverted", "Whether outside the bounds are considered presses and inside the bounds not considered presses.", False)
        _Params.Add("Wrapped", "Permits alternative detection method where a press is detected if the behavior is less than the UBound" & _
                    "OR greater than the LBound. This method is only in place if the LBound is greater than the UBound", True)
    End Sub

    Public Overrides Sub SpeedPrep()
        MyBase.SpeedPrep()

        _Lbound = ParamVal("LBound")
        _Ubound = ParamVal("UBound")
        _Inv = ParamVal("Inverted")

        If ParamVal("Wrapped") = True And _Lbound > _Ubound Then _WrapAround = True
    End Sub

    Public Overrides ReadOnly Property Name As String
        Get
            Return "Pheno Range"
        End Get
    End Property

    Public Overrides Function ConstitutesPress(Behavior As Decimal) As Boolean
        'Catches both options that could be true
        If _WrapAround Then
            If (Behavior >= _Lbound Or Behavior <= _Ubound) Then Return True
        Else
            If (Behavior >= _Lbound And Behavior <= _Ubound) Then Return True
        End If

        'Otherwise False
        Return False
    End Function
End Class
#End Region

#Region "Tapes"

Public Class cETape_FixedRatio
    Inherits cETape
    Private _NumChecks As Integer
    Private _Rate As Integer

    Public Sub New()
        MyBase.New()

        _Params.Add("Rate", "The number of presses between reinforcements", 10I)
    End Sub

    Public Overrides Sub Reset()
        MyBase.Reset()

        'Resets the number of times it has been checked in the past
        _NumChecks = 0
    End Sub

    Public Overrides Sub SpeedPrep()
        MyBase.SpeedPrep()

        _Rate = ParamVal("Rate")
    End Sub

    Public Overrides ReadOnly Property Name As String
        Get
            Return "Fixed Ratio"
        End Get
    End Property

    Protected Overrides Function Check(Time As Decimal) As Boolean
        'Increments the number of times this has been checked.
        _NumChecks += 1

        'Determines whether the component will turn on.
        If (_NumChecks Mod _Rate) = 0 And _Rate > 0 Then
            Return True 'The component will turn on.
        Else
            Return False 'The component will not turn on.
        End If
    End Function
End Class

Public Class cETape_RandomRatioExponential
    Inherits cETape
    Private _NumChecks As Integer
    Private _Rate As Decimal
    Private _NextEmission As Integer
    Private _Rand As cCalvinRandNumber

    Public Sub New()
        MyBase.New()

        _Rand = New cCalvinRandNumber
        _Params.Add("Rate", "The average number of presses between reinforcements (exponential distribution).", 10D)
    End Sub

    Public Overrides Sub Reset()
        MyBase.Reset()

        'Resets the number of times it has been checked in the past
        _NumChecks = 0
        _NextEmission = 0
        _NextEmission += CInt(_Rand.ExponentialDouble)
    End Sub

    Public Overrides Sub SpeedPrep()
        MyBase.SpeedPrep()

        _Rate = ParamVal("Rate")
        _NextEmission = 0
        _Rand.Mean = _Rate
        _NextEmission += CInt(_Rand.ExponentialDouble)
    End Sub

    Public Overrides ReadOnly Property Name As String
        Get
            Return "Random Exponential Ratio"
        End Get
    End Property

    Protected Overrides Function Check(Time As Decimal) As Boolean
        'Increments the number of times this has been checked.
        _NumChecks += 1

        'Code to help with debugging
        If _DebugMode Then Debug.Print("RR_Tape-> Time: " & Time & " NextEmission: " & _NextEmission)

        'Determines whether the component will turn on.
        If (_NumChecks >= _NextEmission) = 0 And _Rate > 0 Then
            _NextEmission += CInt(_Rand.ExponentialDouble)
            Return True 'The component will turn on.
        Else
            Return False 'The component will not turn on.
        End If
    End Function
End Class

Public Class cETape_RandomIntervalExponential
    Inherits cETape
    Private _NumChecks As Integer
    Private _Interval As Decimal
    Private _NextEmission As Decimal
    Private _Rand As cCalvinRandNumber

    Public Sub New()
        MyBase.New()

        _Rand = New cCalvinRandNumber
        _Params.Add("Interval", "The average duration of time between reinforcment availabilities (exponential distribution).", 70D)
    End Sub

    Public Overrides Sub Reset()
        MyBase.Reset()

        'Resets the number of times it has been checked in the past
        _NumChecks = 0
    End Sub

    Public Overrides Sub SpeedPrep()
        MyBase.SpeedPrep()

        _Interval = ParamVal("Interval")
        _NextEmission = 0
        _Rand.Mean = _Interval
        _NextEmission += _Rand.ExponentialDouble
    End Sub

    Public Overrides ReadOnly Property Name As String
        Get
            Return "Random Exponential Interval"
        End Get
    End Property

    Protected Overrides Function Check(Time As Decimal) As Boolean
        'Increments the number of times this has been checked.
        _NumChecks += 1

        'Code to help with debugging
        If _DebugMode Then Debug.Print("RI_Tape-> Time: " & Time & " NextEmission: " & _NextEmission)

        'Determines whether the component will turn on.
        If _NextEmission <= Time And _Interval > 0 Then
            _NextEmission = Time + _Rand.ExponentialDouble
            Return True 'The component will turn on.
        Else
            Return False 'The component will not turn on.
        End If
    End Function
End Class

Public Class cETape_RIPropAllocation
    Inherits cETape
    Private _NumChecks As Integer
    Private _Interval As Decimal
    Private _NextEmission As Decimal
    Private _NextAlt As Integer
    Private _NumAlts As Integer
    Private _Rand As cCalvinRandNumber

    Public Sub New()
        MyBase.New()

        _Rand = New cCalvinRandNumber
        _Params.Add("Interval", "The average duration of time between reinforcment availabilities (exponential distribution).", 70D)
    End Sub

    Public Overrides Sub Reset()
        MyBase.Reset()

        'Resets the number of times it has been checked in the past
        _NumChecks = 0

    End Sub

    Public Overrides Sub SpeedPrep()
        MyBase.SpeedPrep()

        _Interval = ParamVal("Interval")
        _NextEmission = 0
        _Rand.Mean = _Interval
        _NextEmission += _Rand.ExponentialDouble
        _NumAlts = ParamCount - 3

        _Rand.HighestInteger = 0
        If ConnectionCount > 0 Then
            For x = 0 To ConnectionCount - 1
                _Rand.HighestInteger += ParamVal(3 + x)
            Next
        End If
        If _Rand.HighestInteger > 0 Then _Rand.LowestInteger = 1
        AssignAlt()
    End Sub

    Public Overrides ReadOnly Property Name As String
        Get
            Return "RI Exp. Proportional"
        End Get
    End Property

    Public Overrides ReadOnly Property OverridesConnections As Boolean
        Get
            Return True
        End Get
    End Property

    Public Overrides Function OverrideConnection(ConnectionID As Integer) As Boolean
        If ConnectionID <> _NextAlt Then
            Return True
        Else
            Return False
        End If
    End Function

    Protected Overrides Function Check(Time As Decimal) As Boolean
        'Increments the number of times this has been checked.
        _NumChecks += 1

        'Determines whether the component will turn on.
        If _NextEmission <= Time And _Interval > 0 Then
            If _PowerFrom.TryGetValue(_NextAlt, 0) Then
                _NextEmission = Time + _Rand.ExponentialDouble
                AssignAlt()

                Return True 'The component will turn on.
            End If
        End If

        Return False
    End Function

    Private Sub AssignAlt()
        Dim r As Integer = _Rand.RectangularInteger
        Dim sum As Integer

        For x = 0 To ConnectionCount - 1
            sum += ParamVal(x + 3)
            If r <= sum Then
                _NextAlt = x
                Exit For
            End If
        Next
    End Sub

    Public Overrides Sub WireTo(target As Integer)
        MyBase.WireTo(target)

        'Adds the weight for the target magazine
        _Params.Add("ID" & target & "Weight", "The weighting for the target. The probability of the reinforcer being allocated to the target is its weight divided by the sum of all weights.", 1I)
    End Sub

    Public Overrides Sub Disconnect(target As Integer)
        'Removes the weight parameter for the target magazine
        If ConnectsTo(target) Then _Params.Delete("ID" & target & "Weight")

        MyBase.Disconnect(target)
    End Sub

End Class
#End Region

#Region "Magazines"

Public Class cEMagazine_Fixed
    Inherits cEMagazine
    Private _Amount As Decimal

    Public Sub New()
        MyBase.New()

        _Params.Add("Amount", "The size of the reinforcement to be delivered.", 40D)
    End Sub

    Public Overrides Sub SpeedPrep()
        MyBase.SpeedPrep()

        _Amount = ParamVal("Amount")
    End Sub

    Public Overrides ReadOnly Property Amount As Decimal
        Get
            Return _Amount
        End Get
    End Property

    Public Overrides ReadOnly Property Name As String
        Get
            Return "Fixed Amount"
        End Get
    End Property
End Class
#End Region

#Region "Changeover Delays"
Public Class cEChangeOver_Null
    Inherits cEChangeOver

    Protected Overrides Function NewCODEndTime(Time As Decimal) As Decimal
        Return (Time)
    End Function

    Public Overrides ReadOnly Property Name As String
        Get
            Return "Null - Counter"
        End Get
    End Property
End Class

Public Class cEChangeOver_Fixed
    Inherits cEChangeOver
    Private _Duration As Decimal

    Public Sub New()
        MyBase.New()

        _Params.Add("Duration", "The duration that the change over delay lasts.", 5D)
    End Sub

    Public Overrides Sub SpeedPrep()
        MyBase.SpeedPrep()

        _Duration = ParamVal("Duration")
    End Sub

    Protected Overrides Function NewCODEndTime(Time As Decimal) As Decimal
        Return (Time + _Duration)
    End Function

    Public Overrides ReadOnly Property Name As String
        Get
            Return "Fixed Duration"
        End Get
    End Property
End Class
#End Region