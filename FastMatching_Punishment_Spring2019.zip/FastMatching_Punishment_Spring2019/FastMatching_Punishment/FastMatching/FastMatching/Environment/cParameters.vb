﻿
''' <summary>
''' This class is used to act as a variable number of parameters.
''' </summary>
''' <remarks></remarks>
Public Class cParameters
    Private _Params As New List(Of cParam)

    ''' <summary>
    ''' The number of parameters instantiated.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property Count As UInteger
        Get
            Return _Params.Count
        End Get
    End Property

    ''' <summary>
    ''' Returns the name of the parameter at the given index.
    ''' </summary>
    ''' <param name="Index">The index in the list of parameters.</param>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property Name(ByVal Index As Integer) As String
        Get
            Return _Params(Index).Name
        End Get
    End Property

    ''' <summary>
    ''' Returns the description of the parameter at the given index.
    ''' </summary>
    ''' <param name="Index">The parameter's index in the list</param>
    ''' <value></value>
    ''' <returns>A description of the parameter</returns>
    ''' <remarks></remarks>
    Public Overloads Property Description(ByVal Index As Integer) As String
        Get
            Return _Params(Index).Description
        End Get
        Set(value As String)
            _Params(Index).Description = value
        End Set
    End Property

    ''' <summary>
    ''' Returns the description of the parameter with a certain name.
    ''' </summary>
    ''' <param name="name">The parameter's name</param>
    ''' <value></value>
    ''' <returns>A description of the parameter</returns>
    ''' <remarks></remarks>
    Public Overloads Property Description(ByVal name As String) As String
        Get
            Return Me.Description(GetIDNum(name))
        End Get
        Set(value As String)
            Me.Description(GetIDNum(name)) = value
        End Set
    End Property

    ''' <summary>
    ''' Returns the description of the parameter at the given index.
    ''' </summary>
    ''' <param name="Index">The parameter's index in the list</param>
    ''' <value></value>
    ''' <returns>A description of the parameter</returns>
    ''' <remarks></remarks>
    Public Overloads Property Value(ByVal Index As Integer) As Object
        Get
            Return _Params(Index).Value
        End Get
        Set(value As Object)
            If value.GetType.ToString = _Params(Index).Value.GetType.ToString Then
                _Params(Index).Value = value
            Else
                Try
                    Select Case _Params(Index).Value.GetType.ToString
                        Case "System.Int16"
                            _Params(Index).Value = Convert.ToInt16(value)
                        Case "System.Int32"
                            _Params(Index).Value = Convert.ToInt32(value)
                        Case "System.Int64"
                            _Params(Index).Value = Convert.ToInt64(value)
                        Case "System.UInt16"
                            _Params(Index).Value = Convert.ToUInt16(value)
                        Case "System.UInt32"
                            _Params(Index).Value = Convert.ToUInt32(value)
                        Case "System.UInt64"
                            _Params(Index).Value = Convert.ToUInt64(value)
                        Case "System.Single"
                            _Params(Index).Value = Convert.ToSingle(value)
                        Case "System.Double"
                            _Params(Index).Value = Convert.ToDouble(value)
                        Case "System.String"
                            _Params(Index).Value = Convert.ToString(value)
                        Case "System.Decimal"
                            _Params(Index).Value = Convert.ToDecimal(value)
                        Case "System.Boolean"
                            _Params(Index).Value = Convert.ToBoolean(value)
                        Case "System.Byte"
                            _Params(Index).Value = Convert.ToByte(value)
                        Case "System.Char"
                            _Params(Index).Value = Convert.ToChar(value)
                        Case "System.SByte"
                            _Params(Index).Value = Convert.ToSByte(value)
                        Case Else
                            Try
                                'This checks to see if the base objects are identical regardless of whether added
                                '  classes within it are also identical.  When looking at the base class with a class
                                '  in it, VB adds a '+' at the end of the base class's name and then writes the name 
                                '  of the internal classes after it.
                                If Left(value.GetType.ToString, InStr(value.GetType.ToString, "+")) = Left(_Params(Index).Value.GetType.ToString, InStr(_Params(Index).Value.GetType.ToString, "+")) Then
                                    _Params(Index).Value = value.copy()
                                Else
                                    Debug.Print(value.GetType.ToString & "-" & _Params(Index).Value.GetType.ToString)
                                    Throw New ArgumentException("Class cParams: Tried the copy() method assumption, but it failed")
                                End If
                            Catch ex As Exception
                                Debug.Print(value.GetType.ToString & "-" & _Params(Index).Value.GetType.ToString)
                                Throw New ArgumentException("Class cParams: The type of value assigned the parameter is incorrect.")
                            End Try
                    End Select
                Catch ex As Exception
                    Throw New ArgumentException("Class cParams: Could not convert the data to the correct type.")
                End Try
            End If
        End Set
    End Property

    ''' <summary>
    ''' Returns the description of the parameter with a certain name.
    ''' </summary>
    ''' <param name="name">The parameter's name</param>
    ''' <value></value>
    ''' <returns>A description of the parameter</returns>
    ''' <remarks></remarks>
    Public Overloads Property Value(ByVal name As String) As Object
        Get
            Return Me.Value(GetIDNum(name))
        End Get
        Set(value As Object)
            Me.Value(GetIDNum(name)) = value
        End Set
    End Property

    ''' <summary>
    ''' Add a new parameter to the object.
    ''' </summary>
    ''' <param name="Name">The name of the parameter</param>
    ''' <param name="Description">A description of the parameters function</param>
    ''' <param name="Val">The valuee of the parameter</param>
    ''' <remarks></remarks>
    Public Sub Add(ByVal Name As String, ByVal Description As String, ByVal Val As Object)
        Dim TempC As New cParam With { _
            .Name = Name, _
            .Description = Description, _
            .Value = Val}
        Dim Exists As Boolean = False

        For Each P As cParam In _Params
            If UCase(P.Name) = UCase(Name) Then Exists = True
        Next

        If Not Exists Then
            _Params.Add(TempC)
        Else
            Throw New ArgumentException("Class cParams: Unable to add the item, because the name was not unique.")
        End If

    End Sub

    ''' <summary>
    ''' Deletes the parameter at the given index.
    ''' </summary>
    ''' <param name="Index">The index of the parameter to be deleted.</param>
    ''' <remarks></remarks>
    Public Overloads Sub Delete(ByVal Index As Integer)
        _Params.RemoveAt(Index)
    End Sub

    ''' <summary>
    ''' Deletes the parameter with a given name.
    ''' </summary>
    ''' <param name="Name">The name of the parameter to be removed.</param>
    ''' <remarks></remarks>
    Public Overloads Sub Delete(ByVal Name As String)
        _Params.RemoveAt(GetIDNum(Name))
    End Sub

    ''' <summary>
    ''' Gets the ID Number that is associated with the name.
    ''' </summary>
    ''' <param name="name">The name of the parameter to be accessed.</param>
    ''' <returns></returns>
    ''' <remarks>Will throw an error if the name does not exist like an out of bounds error.</remarks>
    Public Function GetIDNum(ByVal name As String) As Integer
        For x = 0 To _Params.Count - 1
            If UCase(_Params(x).Name) = UCase(name) Then Return x
        Next

        Throw New IndexOutOfRangeException("Class cParams: There is no ID that matches that name.")
    End Function

    Private Class cParam
        Public Name As String
        Public Description As String
        Public Value As Object
    End Class
End Class


