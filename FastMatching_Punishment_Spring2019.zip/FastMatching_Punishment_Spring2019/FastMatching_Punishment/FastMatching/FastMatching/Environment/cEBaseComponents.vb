﻿'10/27/13
'This set of classes includes the basic cEComponent class design and the base classes for levers, magazines, tapes, lights, and CODs
'the reason for this change is to give more flexibility to the design of the environment.  Ideally this will be combined with a visual
'interface that will permit the modification of the environment through a point and click interface.  This should feel very intuitive
'and will permit easy use for new models of behavior.

'10/29/13
'Added in cEMagazine and a specific type.  Also started the overall environment that interacts with the virtual creatures.

'10/30/13
'Built the basics of the overall environment that will be used to run the program.
'
'11/6/13
'Finished code and moved individual components to the cEComponents class library.  See programming note for more details.

'11/7/13
'Built GUI and made some slight changes to the components.  Reflection added to the base classes so that the ListOfTypes
'no longer needs editted when a new class is created.

'11/25/13
'Added data output tags to the base classes

'12/19/13
'Corrected the priority assignmen mechanism

'This is the base class that underlies all of the other environmental components.
Public MustInherit Class cEBaseComponents
    Protected _Powered As Boolean
    Protected _LastPowerStatusChange As Decimal
    Protected _LastPowerTime As Decimal
    Protected _LastExcitation, _LastInhibition As Decimal
    Protected _Params As cParameters
    Protected _Outputs As cParameters
    Protected _ConductPower As Decimal
    Protected _Connections As List(Of Integer)
    Protected _PowerFrom As Dictionary(Of Integer, Decimal)
    Protected Const _DebugMode As Boolean = False

    Private _Priority As Decimal
    Public LastPowerFrom As Dictionary(Of Integer, Decimal)

    Public Sub New()
        _Powered = False
        _Priority = -1
        _LastPowerStatusChange = 0
        _LastPowerTime = 0
        _Params = New cParameters
        _Params.Add("Priority", "Delineates the order that the components are processed.  Lower numbers indicate that they will occur earlier.", 1D)
        _Params.Add("Conduct", "The amount of power sent to the next component when this component is powered.", 1D)
        _Outputs = New cParameters

        _Connections = New List(Of Integer)
        _PowerFrom = New Dictionary(Of Integer, Decimal)
        LastPowerFrom = New Dictionary(Of Integer, Decimal)
    End Sub

    Public Property Priority As Decimal
        Get
            If _Priority < 0 Then
                Return ParamVal("Priority")
            Else
                Return _Priority
            End If
        End Get
        Set(value As Decimal)
            _Priority = value
            _Params.Value("Priority") = value
        End Set
    End Property

    ''' <summary>
    ''' The function of this class is to set the easily assignable parameter arrays to local variables.
    ''' This enhances the speed of execution resulting in faster runs.  Automatically called in the copy
    ''' command.
    ''' </summary>
    ''' <remarks></remarks>
    Public Overridable Sub SpeedPrep()
        _Priority = CDec(ParamVal("Priority"))
        _ConductPower = CDec(ParamVal("Conduct"))
    End Sub

    ''' <summary>
    ''' Orders the component to update the data that will be used for output.
    ''' </summary>
    ''' <remarks></remarks>
    Public MustOverride Sub SpeedUpdateOut()

    ''' <summary>
    ''' Resets the component's status to the start values
    ''' </summary>
    ''' <remarks></remarks>
    Public Overridable Sub Reset()
        _Powered = False
        _LastPowerStatusChange = 0
        _LastPowerTime = 0
        _PowerFrom = New Dictionary(Of Integer, Decimal)
    End Sub

    ''' <summary>
    ''' Whether this component is transmitting power.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overridable ReadOnly Property Sending As Boolean
        Get
            Return IsPowered
        End Get
    End Property

    ''' <summary>
    ''' This property allows for a component to select which connections receive power.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overridable ReadOnly Property OverridesConnections As Boolean
        Get
            Return False
        End Get
    End Property

    ''' <summary>
    ''' This function allows the component to specify which connections receive power.
    ''' </summary>
    ''' <param name="ConnectionID">The integer identifier for the specified connection</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overridable Function OverrideConnection(ByVal ConnectionID As Integer) As Boolean
        Return False
    End Function

    ''' <summary>
    ''' Returns a copy of cEComponent
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride Function Copy() As cEBaseComponents

    Public ReadOnly Property Conduct As Decimal
        Get
            Return _ConductPower
        End Get
    End Property

    ''' <summary>
    ''' Returns the name of the component.
    ''' </summary>
    ''' <value>A string that has a name to describe the class</value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride ReadOnly Property Name As String

    ''' <summary>
    ''' What type of component this is.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride ReadOnly Property Type As String


    ''' <summary>
    ''' Whether the virtual creature's behavior interacts with this component of the environment.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride ReadOnly Property Interacts As Boolean

    ''' <summary>
    ''' This component of the environment reacts based on the virtual creatures behavior.
    ''' </summary>
    ''' <param name="Behavior">The behavior that the virtual creature exhibited.</param>
    ''' <param name="Time">The time at which the virtual creature behaved.</param>
    ''' <remarks></remarks>
    Public MustOverride Sub DetectTouch(ByVal Behavior As Decimal, ByVal Time As Decimal)

    ''' <summary>
    ''' Whether the virtual creature is affected by this component of the environment.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride ReadOnly Property Affects As Boolean

    ''' <summary>
    ''' This component of the environment may affect the virtual creature in some way (i.e., new stimuli or reinforcement).
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride Function Deliver(Time As Decimal) As Decimal

    ''' <summary>
    ''' The component receives power from a target component.
    ''' </summary>
    ''' <param name="FromComponentID">The index of the component</param>
    ''' <param name="Amount">The amount of power from the component.  Positive values are excitatory and negative values are inhibitory.</param>
    ''' <remarks></remarks>
    Public Overridable Sub ReceivePower(ByVal FromComponentID As Integer, ByVal Amount As Decimal)
        _PowerFrom.Add(FromComponentID, Amount)
    End Sub

    ''' <summary>
    ''' Whether this component is currently powered.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overridable ReadOnly Property IsPowered As Boolean
        Get
            Return _Powered
        End Get
    End Property

    ''' <summary>
    ''' This property exists for things like tapes and CODs where you want to override power status transitions.
    ''' For most classes this should be false, which is the default.
    ''' </summary>
    ''' <param name="Time">The current time.</param>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Protected Overridable ReadOnly Property OverridePowerChange(ByVal Time As Decimal) As Boolean
        Get
            Return False
        End Get
    End Property

    ''' <summary>
    ''' Sets whether the component is powered.
    ''' </summary>
    ''' <param name="Time">The current time step that the power status is changed.</param>
    ''' <remarks></remarks>
    Public Overridable Sub CheckPower(ByVal Time As Decimal)
        Dim Powered As Boolean

        'Resets excitation and inhibition
        _LastExcitation = 0
        _LastInhibition = 0

        'Goes through all of the power that was received and categorizes it into excitation and inhibition
        If _PowerFrom.Count > 0 Then
            For Each i In _PowerFrom
                If i.Value > 0 Then
                    _LastExcitation += i.Value
                Else
                    _LastInhibition -= i.Value
                End If
            Next
        End If

        'Determines whether the unit should be powered based on recent input
        If _LastExcitation > _LastInhibition Then 'Suggests that the unit should be turned on
            Powered = True
            _Powered = False
        ElseIf (_LastExcitation < _LastInhibition) Or (_LastExcitation = 0 And _LastInhibition = 0) Then
            'Suggests that more inhibition than excitation OR no excitation at all should turn the unit off
            Powered = False
            _Powered = False
        Else 'Maintains the current status if excitation = inhibition and that at least some of each occurred
            Powered = _Powered
        End If

        'This section will only be entered if the old status and the new status differ
        If Powered Then
            If Not OverridePowerChange(Time) Then 'DO NOT MOVE THIS
                'tracks the last time that the power was switched
                If Powered Xor _Powered Then _LastPowerStatusChange = Time

                'If the unit should be turned on
                If Powered Then
                    TurnOn()
                Else 'If the unit has been turned off
                    ShutDown()
                    _LastPowerStatusChange = Time
                End If
            End If
        End If

        'Updates the current time
        _LastPowerTime = Time

        'Clears out the list of values that powered the unit as maintains a copy of the list for one time step.
        LastPowerFrom.Clear()
        For Each i In _PowerFrom
            LastPowerFrom.Add(i.Key, i.Value)
        Next
        _PowerFrom.Clear()
    End Sub

    ''' <summary>
    ''' Turns the component on.
    ''' </summary>
    ''' <remarks></remarks>
    Protected MustOverride Sub TurnOn(Optional ByVal Time As Decimal = -1)

    ''' <summary>
    ''' Turns the component off.
    ''' </summary>
    ''' <remarks></remarks>
    Protected MustOverride Sub ShutDown(Optional ByVal Time As Decimal = -1)


    ''' <summary>
    ''' The value of the measured output at the given index.
    ''' </summary>
    ''' <param name="Index">Integer value representing the location in the list</param>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overloads Property OutputVal(ByVal Index As Integer) As Object
        Get
            Return _Outputs.Value(Index)
        End Get
        Set(value As Object)
            _Outputs.Value(Index) = value
        End Set
    End Property

    ''' <summary>
    ''' The value of the measured output with the given name.
    ''' </summary>
    ''' <param name="Name">The name of the measured output to be checked.</param>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overloads Property OutputVal(ByVal Name As String) As Object
        Get
            Return _Outputs.Value(Name)
        End Get
        Set(value As Object)
            _Outputs.Value(Name) = value
        End Set
    End Property

    ''' <summary>
    ''' A description of the measured output at the given index.
    ''' </summary>
    ''' <param name="Index">Integer value representing the location in the list</param>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overloads ReadOnly Property OutputDesc(ByVal Index As Integer) As String
        Get
            Return _Outputs.Description(Index)
        End Get
    End Property

    ''' <summary>
    ''' A description of the measured output with the given name.
    ''' </summary>
    ''' <param name="Name">The name of the measured output to be described.</param>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overloads ReadOnly Property OutputDesc(ByVal Name As String) As String
        Get
            Return _Outputs.Description(Name)
        End Get
    End Property

    ''' <summary>
    ''' The name of the output parameter that is being tracked.
    ''' </summary>
    ''' <param name="index">The index of the output parameter whose name is desired.</param>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property OutputName(ByVal index As Integer)
        Get
            Return _Outputs.Name(index)
        End Get
    End Property

    ''' <summary>
    ''' The number of output values.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property OutputCount As Integer
        Get
            Return _Outputs.Count
        End Get
    End Property


    ''' <summary>
    ''' The number of parameters that this class has
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property ParamCount As Integer
        Get
            Return _Params.Count
        End Get
    End Property

    ''' <summary>
    ''' The name of the parameter at the given index.
    ''' </summary>
    ''' <param name="Index">Integer value representing the location in the list</param>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property ParamName(ByVal Index As Integer) As String
        Get
            Return _Params.Name(Index)
        End Get
    End Property

    ''' <summary>
    ''' A description of the parameter at the given index.
    ''' </summary>
    ''' <param name="Index">Integer value representing the location in the list</param>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overloads ReadOnly Property ParamDesc(ByVal Index As Integer) As String
        Get
            Return _Params.Description(Index)
        End Get
    End Property

    ''' <summary>
    ''' A description of the parameter with the given name.
    ''' </summary>
    ''' <param name="Name">The name of the parameter to be checked.</param>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overloads ReadOnly Property ParamDesc(ByVal Name As String) As String
        Get
            Return _Params.Description(Name)
        End Get
    End Property

    ''' <summary>
    ''' The value of the parameter at the given index.
    ''' </summary>
    ''' <param name="Index">Integer value representing the location in the list</param>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overloads Property ParamVal(ByVal Index As Integer) As Object
        Get
            Return _Params.Value(Index)
        End Get
        Set(value As Object)
            _Params.Value(Index) = value
        End Set
    End Property

    ''' <summary>
    ''' The value of the parameter with the given name.
    ''' </summary>
    ''' <param name="Name">The name of the parameter to be checked.</param>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overloads Property ParamVal(ByVal Name As String) As Object
        Get
            Return _Params.Value(Name)
        End Get
        Set(value As Object)
            If UCase(Name) = "PRIORITY" Then
                Priority = value
                _Params.Value(Name) = value
            Else
                _Params.Value(Name) = value
            End If
        End Set
    End Property


    ''' <summary>
    ''' Adds a connection to the component.
    ''' </summary>
    ''' <param name="target">The target component's index</param>
    ''' <remarks></remarks>
    Public Overridable Sub WireTo(ByVal target As Integer)
        If Not _Connections.Contains(target) Then
            _Connections.Add(target)
        End If
    End Sub

    ''' <summary>
    ''' Removes a connection to the component.
    ''' </summary>
    ''' <param name="target">The target component's index</param>
    ''' <remarks></remarks>
    Public Overridable Sub Disconnect(ByVal target As Integer)
        If _Connections.Contains(target) Then
            _Connections.Remove(target)
        End If
    End Sub

    ''' <summary>
    ''' The number of components that this is connected to.
    ''' </summary>
    ''' <value>An integer value that states the number of connections this component has.</value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overridable ReadOnly Property ConnectionCount As Integer
        Get
            Return _Connections.Count
        End Get
    End Property

    ''' <summary>
    ''' Returns the target connection that is specified by the component
    ''' </summary>
    ''' <param name="index"></param>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overridable Property ConnectionTarget(ByVal index As Integer) As Integer
        Get
            If (index < ConnectionCount) Or (index < 0) Then
                Return _Connections(index)
            Else
                Throw New ArgumentException("Class cEComponent: The requested connection index does not exist.")
            End If
        End Get
        Set(value As Integer)
            _Connections(index) = value
        End Set
    End Property

    ''' <summary>
    ''' Whether a particular component is targeted by this component.
    ''' </summary>
    ''' <param name="index">The index of the target component.</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overridable Function ConnectsTo(ByVal index As Integer) As Boolean
        Return _Connections.Contains(index)
    End Function
End Class

Public MustInherit Class cELever
    Inherits cEBaseComponents
    Protected _LastPressTime As Decimal
    Protected _NumberOfPresses As UInteger

    Public Sub New()
        MyBase.New()

        _Outputs.Add("NumPresses", "The number of times that the lever has been pressed.", 0)
    End Sub

    Public Overrides Sub SpeedUpdateOut()
        _Outputs.Value("NumPresses") = _NumberOfPresses
    End Sub

    Public Overrides Sub Reset()
        MyBase.Reset()

        'Resets the class specific parameters
        _LastPressTime = 0
        _NumberOfPresses = 0
    End Sub

    Public ReadOnly Property ListOfTypes As List(Of cELever)
        Get
            Dim LComp As System.Type = GetType(cELever)
            Dim LTypes As New List(Of cELever)
            Dim asm As System.Reflection.Assembly

            'Loads all of the classes that are used in the assembly
            asm = System.Reflection.Assembly.GetEntryAssembly

            'Goes through the entire assembly and loads all of the class subtypes.
            For Each t As Type In asm.GetTypes()
                If t.IsSubclassOf(LComp) Then LTypes.Add(Activator.CreateInstance(t))
            Next

            Return LTypes
        End Get
    End Property

    Public Overrides Function Copy() As cEBaseComponents
        Dim tempL As cELever

        For x = 0 To Me.ListOfTypes.Count - 1
            If Me.Name = Me.ListOfTypes(x).Name Then
                tempL = Me.ListOfTypes(x)

                tempL._Connections.AddRange(Me._Connections)

                If _Params.Count > 0 Then
                    For y As Integer = 0 To _Params.Count - 1
                        tempL._Params.Value(y) = Me._Params.Value(y)
                    Next
                End If

                tempL.SpeedPrep()
                tempL.Priority = Me.Priority

                Return tempL
            End If
        Next

        Throw New IndexOutOfRangeException("Class cELever: The type that was searched for does not exist")
    End Function

    Public Overrides ReadOnly Property Name As String
        Get
            Return "Base"
        End Get
    End Property

    Protected Overrides Sub ShutDown(Optional ByVal Time As Decimal = -1)
        _Powered = False
    End Sub

    Public Overrides Sub SpeedPrep()
        MyBase.SpeedPrep()
    End Sub

    Protected Overrides Sub TurnOn(Optional ByVal Time As Decimal = -1)
        _Powered = True
    End Sub

    Public Overrides ReadOnly Property Type As String
        Get
            Return "Lever"
        End Get
    End Property

    Public Overrides ReadOnly Property Interacts As Boolean
        Get
            Return True 'Default for levers.
        End Get
    End Property

    Public Overrides ReadOnly Property Affects As Boolean
        Get
            Return False 'Default value for levers.
        End Get
    End Property

    Public Overrides Function Deliver(Time As Decimal) As Decimal
        'Throw an Error.
        Throw New ArgumentException("Class cELever: This component does not deliver anything to the virtual creatures.")

        Return Nothing
    End Function

    Public Overrides Sub DetectTouch(Behavior As Decimal, Time As Decimal)
        If ConstitutesPress(Behavior) Then
            _NumberOfPresses += 1
            _LastPressTime = Time

            ReceivePower(-999, _ConductPower)
        End If
    End Sub

    ''' <summary>
    ''' Determines whether the exhibited behavior counts as a press.
    ''' </summary>
    ''' <param name="Behavior">The behavior that the virtual creature exhibited.</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride Function ConstitutesPress(ByVal Behavior As Decimal) As Boolean

End Class

Public MustInherit Class cETape
    Inherits cEBaseComponents
    Protected _LastCheck As Decimal

    Public Sub New()
        MyBase.New()

        'Gets a list of all of the inherited classes?
        'Dim L As New List(Of Type)
        'L.AddRange(System.Reflection.Assembly.GetCallingAssembly

    End Sub

    Public Overrides Sub Reset()
        MyBase.Reset()

        'Resets the class specific parameters
        _LastCheck = 0
    End Sub

    Public ReadOnly Property ListOfTypes As List(Of cETape)
        Get
            Dim LComp As System.Type = GetType(cETape)
            Dim TTypes As New List(Of cETape)
            Dim asm As System.Reflection.Assembly

            'Loads all of the classes that are used in the assembly
            asm = System.Reflection.Assembly.GetEntryAssembly

            'Goes through the entire assembly and loads all of the class subtypes.
            For Each t As Type In asm.GetTypes()
                'Debug.Print(t.ToString)
                If t.IsSubclassOf(LComp) Then TTypes.Add(Activator.CreateInstance(t))
            Next

            Return TTypes
        End Get
    End Property

    Public Overrides Function Copy() As cEBaseComponents
        Dim tempT As cETape

        For x = 0 To Me.ListOfTypes.Count - 1
            If Me.Name = Me.ListOfTypes(x).Name Then
                tempT = Me.ListOfTypes(x)

                'Usees the wireto command rather than copying the range so that any special commands are executed
                For y = 0 To ConnectionCount - 1
                    tempT.WireTo(Me.ConnectionTarget(y))
                Next

                If _Params.Count > 0 Then
                    For y As Integer = 0 To _Params.Count - 1
                        tempT._Params.Value(y) = Me._Params.Value(y)
                    Next
                End If

                tempT.SpeedPrep()
                tempT.Priority = Me.Priority

                Return tempT
            End If
        Next

        Throw New IndexOutOfRangeException("Class cETape: The type that was searched for does not exist")
    End Function

    Public Overrides ReadOnly Property Name As String
        Get
            Return "Base"
        End Get
    End Property

    Protected Overrides Sub ShutDown(Optional ByVal Time As Decimal = -1)
        _Powered = False
    End Sub

    Public Overrides Sub SpeedPrep()
        MyBase.SpeedPrep()
    End Sub

    Protected Overrides Sub TurnOn(Optional ByVal Time As Decimal = -1)
        _Powered = True
    End Sub

    Protected Overrides ReadOnly Property OverridePowerChange(Time As Decimal) As Boolean
        Get
            'This section will prevent the tape from conducting unless the tape indicates that something is available
            If Not _Powered Then
                If Check(Time) Then
                    Return False
                End If
            End If

            'Defaults to override
            Return True
        End Get
    End Property

    Public Overrides ReadOnly Property Type As String
        Get
            Return "Tape"
        End Get
    End Property

    Public Overrides ReadOnly Property Interacts As Boolean
        Get
            Return False 'Default for tapes.
        End Get
    End Property

    Public Overrides ReadOnly Property Affects As Boolean
        Get
            Return False 'Default value for tapes.
        End Get
    End Property

    Public Overrides Function Deliver(Time As Decimal) As Decimal
        'Throw an Error.
        Throw New ArgumentException("Class cETape: This component does not deliver anything to the virtual creatures.")

        Return Nothing
    End Function

    Public Overrides Sub DetectTouch(Behavior As Decimal, Time As Decimal)
        'Throw an Error.
        Throw New ArgumentException("Class cETape: Virtual creatures cannot interact with this class")
    End Sub

    Protected MustOverride Function Check(Time As Decimal) As Boolean

    Public Overrides Sub SpeedUpdateOut()
        'Do Nothing
    End Sub
End Class

Public MustInherit Class cEMagazine
    Inherits cEBaseComponents
    Protected _NumDeliveries As Integer
    Protected _LastAmount As Decimal
    Protected _LastTime As Decimal

    Public MustOverride ReadOnly Property Amount As Decimal

    Public Sub New()
        MyBase.New()

        _Outputs.Add("NumDeliveries", "The number of times that reinforcement or punishment were delivered.", 0)

        'Resets all of the tracking data types.
        _NumDeliveries = 0
        _LastAmount = 0
        _LastTime = 0
    End Sub

    Public Overrides Sub Reset()
        MyBase.Reset()

        _Outputs.Value("NumDeliveries") = 0 ', "The number of times that reinforcement or punishment were delivered.", 0)

        'Resets all of the tracking data types.
        _NumDeliveries = 0
        _LastAmount = 0
        _LastTime = 0
    End Sub

    Public Overrides Sub SpeedUpdateOut()
        _Outputs.Value("NumDeliveries") = _NumDeliveries
    End Sub

    Public ReadOnly Property ListOfTypes As List(Of cEMagazine)
        Get
            Dim LComp As System.Type = GetType(cEMagazine)
            Dim MTypes As New List(Of cEMagazine)
            Dim asm As System.Reflection.Assembly

            'Loads all of the classes that are used in the assembly
            asm = System.Reflection.Assembly.GetEntryAssembly

            'Goes through the entire assembly and loads all of the class subtypes.
            For Each t As Type In asm.GetTypes()
                If t.IsSubclassOf(LComp) Then MTypes.Add(Activator.CreateInstance(t))
            Next

            Return MTypes
        End Get
    End Property

    Public Overrides ReadOnly Property Affects As Boolean
        Get
            Return True
        End Get
    End Property

    Public Overrides Function Copy() As cEBaseComponents
        Dim tempM As cEMagazine

        For x = 0 To Me.ListOfTypes.Count - 1
            If Me.Name = Me.ListOfTypes(x).Name Then
                tempM = Me.ListOfTypes(x)

                tempM._Connections.AddRange(Me._Connections)

                If _Params.Count > 0 Then
                    For y As Integer = 0 To _Params.Count - 1
                        tempM._Params.Value(y) = Me._Params.Value(y)
                    Next
                End If

                tempM.SpeedPrep()
                tempM.Priority = Me.Priority

                Return tempM
            End If
        Next

        Throw New IndexOutOfRangeException("Class cEMagazine: The type that was searched for does not exist")
    End Function

    Public Overrides Function Deliver(Time As Decimal) As Decimal
        Dim Mag As Decimal = Amount

        'Increments the number of reinforcment deliveries that have occured
        _NumDeliveries += 1
        _LastAmount = Mag
        _LastTime = Time

        'Delivers whatever the magnitude is
        Return Mag
    End Function

    Public Overrides Sub DetectTouch(Behavior As Decimal, Time As Decimal)
        'Throw an Error.
        Throw New ArgumentException("Class cEMagazine: Virtual creatures cannot interact with this class")
    End Sub

    Public Overrides ReadOnly Property Interacts As Boolean
        Get
            Return False
        End Get
    End Property

    Public Overrides ReadOnly Property Name As String
        Get
            Return "Base"
        End Get
    End Property

    Protected Overrides Sub ShutDown(Optional ByVal Time As Decimal = -1)
        _Powered = False
    End Sub

    Public Overrides Sub SpeedPrep()
        MyBase.SpeedPrep()
    End Sub

    Protected Overrides Sub TurnOn(Optional ByVal Time As Decimal = -1)
        _Powered = True
    End Sub

    Public Overrides ReadOnly Property Type As String
        Get
            Return "Magazine"
        End Get
    End Property

End Class

Public MustInherit Class cEChangeOver
    Inherits cEBaseComponents
    Private _LastCheck As Decimal
    Private _Switches As Integer
    Private _LastIDs As List(Of Integer)
    Private _EndTime As Decimal

    Public Sub New()
        MyBase.New()

        _LastCheck = 0
        _Switches = -1
        _LastIDs = New List(Of Integer)
        _EndTime = 0

        _Params.Delete("Conduct")
        _Params.Add("Inhibit", "The amount of inhibitory power sent to the next component when this component is powered.", 1D)

        _Outputs.Add("ChangeOvers", "The number of times that a switch has occured.", 0)
    End Sub


    Public Overrides Sub SpeedUpdateOut()
        _Outputs.Value("ChangeOvers") = _Switches
    End Sub

    Public Overrides Sub SpeedPrep()
        _ConductPower = -ParamVal("Inhibit")
    End Sub

    Public Overrides ReadOnly Property Sending As Boolean
        Get
            Return (Not MyBase.IsPowered) 'This is reversed because you want it to shut down other components when it is on.
        End Get
    End Property

    Public Overrides Sub Reset()
        MyBase.Reset()

        'Resets the class specific parameters
        _LastCheck = 0
        _Switches = -1
        _EndTime = 0
        _LastIDs.Clear()
    End Sub

    Public Overrides ReadOnly Property Affects As Boolean
        Get
            Return False
        End Get
    End Property

    Public Overrides Sub CheckPower(ByVal Time As Decimal)
        Dim Powered As Boolean
        Dim Switch As Boolean = False

        'Resets excitation and inhibition
        _LastExcitation = 0
        _LastInhibition = 0

        'Goes through all of the power that was received and categorizes it into excitation and inhibition
        If _PowerFrom.Count > 0 Then
            For Each i In _PowerFrom
                'Checks to see if a switch has occured
                If Not Switch Then 'Only checks if a switch has not already been detected occurred
                    If Not _LastIDs.Contains(i.Key) Then
                        Switch = True

                        'Tracks all of the current IDs
                        _LastIDs.Clear()
                        For Each j In _PowerFrom
                            _LastIDs.Add(j.Key)
                        Next
                    End If
                End If

                'Calculates the excitation and inhibition values
                If i.Value > 0 Then
                    _LastExcitation += i.Value
                Else
                    _LastInhibition -= i.Value
                End If
            Next
        End If

        'Determines whether the unit should be powered based on recent input
        If _LastExcitation > _LastInhibition Then 'Suggests that the unit should be turned on
            Powered = True
            _Powered = False
        ElseIf (_LastExcitation < _LastInhibition) Or (_LastExcitation = 0 And _LastInhibition = 0) Then
            'Suggests that more inhibition than excitation OR no excitation at all should turn the unit off
            Powered = False
            _Powered = False
        Else 'Maintains the current status if excitation = inhibition and that at least some of each occurred
            Powered = _Powered
        End If

        'Counts switches and sets the new time
        If Switch And Powered Then
            _Switches += 1

            'This prevents the first press from starting the COD
            If _Switches > 0 Then _EndTime = NewCODEndTime(Time)
        End If

        'This section will only be entered if the old status and the new status differ
        If Powered And Not OverridePowerChange(Time) Then
            'Tracks the last time that the power changed
            _LastPowerStatusChange = Time

            'Code for debugging
            If _DebugMode Then Debug.Print("ChangeOver at Time:" & Time)

            'If the unit should be turned on
            If Powered Then
                TurnOn()
            Else 'If the unit has been turned off
                ShutDown()
            End If
        End If

        'Updates the current time
        _LastPowerTime = Time

        'Clears out the list of values that powered the unit as maintains a copy of the list for one time step.
        LastPowerFrom.Clear()
        For Each i In _PowerFrom
            LastPowerFrom.Add(i.Key, i.Value)
        Next
        _PowerFrom.Clear()
    End Sub

    Protected Overrides ReadOnly Property OverridePowerChange(Time As Decimal) As Boolean
        Get
            If Time >= _EndTime Then
                Return False
            Else
                Return True
            End If
        End Get
    End Property

    Protected MustOverride Function NewCODEndTime(ByVal Time As Decimal) As Decimal

    Public ReadOnly Property ListOfTypes As List(Of cEChangeOver)
        Get
            Dim LComp As System.Type = GetType(cEChangeOver)
            Dim CTypes As New List(Of cEChangeOver)
            Dim asm As System.Reflection.Assembly

            'Loads all of the classes that are used in the assembly
            asm = System.Reflection.Assembly.GetEntryAssembly

            'Goes through the entire assembly and loads all of the class subtypes.
            For Each t As Type In asm.GetTypes()
                If t.IsSubclassOf(LComp) Then CTypes.Add(Activator.CreateInstance(t))
            Next

            Return CTypes
        End Get
    End Property

    Public Overrides Function Copy() As cEBaseComponents
        Dim tempC As cEChangeOver

        For x = 0 To Me.ListOfTypes.Count - 1
            If Me.Name = Me.ListOfTypes(x).Name Then
                tempC = Me.ListOfTypes(x)

                tempC._Connections.AddRange(Me._Connections)

                If _Params.Count > 0 Then
                    For y As Integer = 0 To _Params.Count - 1
                        tempC._Params.Value(y) = Me._Params.Value(y)
                    Next
                End If

                tempC.SpeedPrep()
                tempC.Priority = Me.Priority

                Return tempC
            End If
        Next

        Throw New IndexOutOfRangeException("Class cEChangeOver: The type that was searched for does not exist")
    End Function

    Public Overrides Function Deliver(Time As Decimal) As Decimal
        'Throw an Error.
        Throw New ArgumentException("Class cEChangeOver: This component does not deliver anything to the virtual creatures.")
    End Function

    Public Overrides Sub DetectTouch(Behavior As Decimal, Time As Decimal)
        'Throw an Error.
        Throw New ArgumentException("Class cEChangeOver: Virtual creatures cannot interact with this class")
    End Sub

    Public Overrides ReadOnly Property Interacts As Boolean
        Get
            Return False
        End Get
    End Property

    Public Overrides ReadOnly Property Name As String
        Get
            Return "Base"
        End Get
    End Property

    Protected Overrides Sub ShutDown(Optional ByVal Time As Decimal = -1)
        _Powered = False
    End Sub

    Protected Overrides Sub TurnOn(Optional ByVal Time As Decimal = -1)
        _Powered = True
    End Sub

    Public Overrides ReadOnly Property Type As String
        Get
            Return "COD"
        End Get
    End Property

End Class
