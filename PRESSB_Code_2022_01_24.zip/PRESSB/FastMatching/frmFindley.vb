﻿'CONTACT INFORMATION:
'Date Completed:     12 December 2014
'Most Recent Update: 07 July 2020
'Version Name:       Blackouts with Extended Reinforcement Range
'Author:             Olivia L. Calvin, PhD 
'Modifier:           Bryan Klapes, M.A. (Graduate Students)
'Affiliation:        Emory University
'E-Mail:             ocalvin05@gmail.com; bryan.klapes@emory.edu
'Other Contacts:     Jack McDowell - psyjjmd@emory.edu (Advisor)

'PROCEDURE:
'   This form implements a set of Findley concurrent RIRI schedules (Findley, 1958). Reinforcers are awarded to the
'participant in the form of points and punishers are implemented as the loss of points. Discriminative stimuli are arrayed across
'the top of the screen to indicate the current schedule. The participant interacts with the environment through two methods: a large 
'button on the form, which constitutes a response on the current alternative, and a smaller, 'switch' button, which changes the
'current response alternative. Data is recorded in a comma delineated text file, which details each response. This file is saved 
'to the My Documents folder. Punishment has implemented into this form and is part of the experimental procedures. The stimuli in 
'the top left And right are based On the relative rate Of reinforcement with faster rates being represented as larger stimuli.

'Following is the outline for this program's operation:
'   1: The experiment begins when the participant clicks bttnLever when is says "START." This sets the timer tBlockDur into effect,
'      which controls when the experiment progresses and data is output.
'   2: Once the timer tBlockDur is in effect there are three main functions that are at operating concurrently.
'       A: The participant can operate bttnLever by clicking or pressing space bar. Reinforcement and punishment stimuli are delivered
'          when appropriate.
'       B: The participant can operate bttnFindley by clicking or pressing "ctrl".  This action switches between the two response 
'          alternative. The discriminative stimuli are changed as necessary.
'       C: The function tBlockDur_Tick is called when a period of time has elapsed, which is set using the parameter _DataBlockDur. h
'          When this function is called, summary data of the participant's behavior is recorded in an Excel file. With each call the
'          _ElapsedBlocks variable is incremented by 1. If the number of elapsed blocks (i.e., _ElapsedBlocks) is equal to or greater
'          than the number indicated for that schedule (indicated in the _NumSchedBlocks array) then the experiment moves onto the next
'          schedule. If all of the schedules have been executed then the experiment terminates.
'   3: Termination of the experiment. This can occur in two ways: when the participant has been through all of the experimental
'      conditions or if the Ctrl and Q buttons are pressed at the same time. On termination, all of the data is saved and the program
'      closes.

'CONTROLS:
'- Press space bar or click the large button to respond.
'- Press "ctrl" or click the 'switch' button to switch between the two response alternatives.
'- Press "Ctrl+Q" to quit early. The data output will close successfully.

Public Class frmFindley
    ' Constants that control how the experiment runs
    Private Const _RandOrder As Boolean = True       'Whether the schedules should be presented in a random order
    Private Const _CollectData As Boolean = True     'Whether data should be collected
    Private Const _Debug As Boolean = True          'Whether this should create debugging output
    Private Const _KeyBoardMode As Boolean = True    'Whether the keyboard can be used to interact with the schedule
    Private Const _ResponseKey As Integer = 32       'The button that counts as a response on the main button
    Private Const _SwitchKey As Integer = 17         'The button that switches between the alternatives
    Private Const _StimDur As UInteger = 250         'How long the reinforcing and punishing visual stimuli are presented

    ' Color constants for the form
    Private _RStimColor As System.Drawing.Color = System.Drawing.Color.Green        'The color of the reinforcement stimulus
    Private _RStimOffColor As System.Drawing.Color = System.Drawing.Color.DarkGreen 'The color of the reinforcement stimulus when it is turned off
    Private _PStimColor As System.Drawing.Color = System.Drawing.Color.Red          'The color of the punishment stimulus
    Private _PStimOffColor As System.Drawing.Color = System.Drawing.Color.DarkRed   'The color of the punishment stimulus when it is turned off
    Private _StimDAlt1Color As System.Drawing.Color = System.Drawing.Color.Gold     'The color of the discriminative stimulus when the 1st alternative is in effect
    Private _StimDAlt2Color As System.Drawing.Color = System.Drawing.Color.Blue     'The color of the discriminative stimulus when the 2nd alternative is in effect
    Private _StimDSchedule As System.Drawing.Color = System.Drawing.Color.White     'The color of the discriminative stimulus that indicates what the current schedule is
    Private _NoStim As System.Drawing.Color = System.Drawing.Color.Black            'The color when a stimulus is not active

    'The following 6 variables go together and should always have the same number of items. Each value controls the behavior of a specific concurrent schedule.
    '  For example, the 3rd item in each of the arrays occur at the same time
    Private _SchedNums As New List(Of UInteger)
    Private _SchedType As New List(Of Char)  'A = Acquisition, T = Test, E = Extinction, B = Break
    Private _SchedDurs As New List(Of UInteger)
    Private _Comp1RIntervals As New List(Of UInteger)
    Private _Comp2RIntervals As New List(Of UInteger)
    Private _Comp1PIntervals As New List(Of UInteger)
    Private _Comp2PIntervals As New List(Of UInteger)
    Private _Comp1RMagnitudes As New List(Of UInteger)
    Private _Comp2RMagnitudes As New List(Of UInteger)
    Private _Comp1PMagnitudes As New List(Of Integer)
    Private _Comp2PMagnitudes As New List(Of Integer)
    Private _CODs As New List(Of UInteger)
    Private _BreakPoints As New List(Of UInteger)

    Private _MagCompIDs() As Integer = {6, 7, 8, 9}                                 '***SEE the BuildEnvironment command to determine where these come from. This is currently a rushed fix.
    Private _ForceBreak As Boolean = True                                           'If there is a break

    'The Environment
    Private _Environment As cEnvironment

    'Variables that are used when the experiment is conducted
    Private _Points As Integer                      'The number of points that have been collected.
    Private _Effects As List(Of Decimal)            'How the environment reacted to the participant's behavior.
    Private _Timer As Stopwatch                     'Used to track how much time has elapsed since a schedule has begun.
    Private _SchedOrder As List(Of Integer)         'The order that the schedules will be executed
    Private _ScheduleIterator As Integer            'This parameter is used to keep track of where in _SchedOrder the experiment currently is
    Private _CurrentAlt As Integer                  '1 = First Alternative, 2 = Second Alternative
    Private _NumScheds As UInteger                  'The number of schedules in the experiment
    Private _Started As Boolean = False             'Whether the experiment has been initiated
    Private _DisableKBResp As Boolean = False       'Allows the keyboard responding to be temporarily turned off

    'Part of the experiment's display
    Private _SDPanels() As Panel                    'The discriminative stimuli that are procedurally generated based on the number of "T" schedules

    'Subject Information
    Private _ID As String
    Private _Date As String
    Private _Time As String

    'Location of the experiment file and where to save the subject data
    Private _ExpLoc As String
    Private _SaveLoc As String

    'Data output variables
    Private _PartOutput As IO.StreamWriter
    Private _RunLog As String                  'Where the run log is saved
    Private _HSFile As String                  'Where the high score file is saved

    'Highscore Info
    Private _Names As New List(Of String)
    Private _TopScores As New List(Of Integer)

    ''' <summary>
    ''' Sets the participant information that will be outputed to the data files.
    ''' </summary>
    ''' <param name="ExperimentLoc">Name of the the experiment form.</param>
    ''' <param name="Id">The subjects information</param>
    ''' <param name="D">The current date</param>
    ''' <param name="T">The current time</param>
    ''' <remarks></remarks>
    Public Function SetParticipantInfo(ByVal ExperimentLoc As String,
                                       ByVal Id As String,
                                       ByVal D As String,
                                       ByVal T As String) As Boolean
        Dim fileReader As System.IO.StreamReader
        Dim path As String
        Dim fldr As String
        Dim values() As String

        ' Set up the path to output to.
        path = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\PRESSB\Data\"
        fldr = ExperimentLoc.Split("\").Last
        fldr = fldr.Split(".").First
        path = path & fldr & "\"
        checkLoaders(path)

        ' Set the participant information
        _ID = Id
        _Date = D
        _Time = T

        ' Load the experiment file
        _ExpLoc = ExperimentLoc

        'Work with the experiment files.
        fileReader = My.Computer.FileSystem.OpenTextFileReader(_ExpLoc)
        fileReader.ReadLine()

        Do While Not fileReader.EndOfStream
            values = fileReader.ReadLine().Split(",")

            'Assign the values
            _SchedNums.Add(values(0))
            _SchedType.Add(values(1))
            _SchedDurs.Add(values(2))
            _Comp1RIntervals.Add(values(3))
            _Comp1RMagnitudes.Add(values(4))
            _Comp2RIntervals.Add(values(5))
            _Comp2RMagnitudes.Add(values(6))
            _CODs.Add(values(7))
            _Comp1PIntervals.Add(0)
            _Comp2PIntervals.Add(0)
            _Comp1PMagnitudes.Add(0)
            _Comp2PMagnitudes.Add(0)
        Loop

        ' Check to see if this subject has been used before
        If My.Computer.FileSystem.FileExists(path & _ID & ".csv") Then
            Dim valid = False
            Do
                Dim mResp As MsgBoxResult
                Dim newID As String

                mResp = MsgBox("Participant " & _ID & " already has data recorded. Should this data be overridden?", 4)

                If mResp = MsgBoxResult.Yes Then
                    valid = True
                Else
                    newID = InputBox("What should the new ID be?", "New ID", _ID)

                    ' If the researcher clicks 'Cancel'
                    If newID = "" Then Me.Close()
                    _ID = newID

                    'Validates that 
                    If Not My.Computer.FileSystem.FileExists(path & newID & ".csv") Then valid = True
                End If

            Loop Until (valid = True)
        End If

        'Creates the participant data file
        _PartOutput = My.Computer.FileSystem.OpenTextFileWriter(path & _ID & ".csv", False)
        _PartOutput.WriteLine("Block,Time,Response,Reinforced")

        'Load the high scores (if they don't already exist then they will be created in checkLoaders).
        Dim HS As New IO.StreamReader(_HSFile)
        HS.ReadLine()
        Do
            Dim l As String

            l = HS.ReadLine()
            _Names.Add(l.Split(",")(0))
            _TopScores.Add(CInt(l.Split(",")(1)))
        Loop Until HS.EndOfStream
        HS.Close()


        'Shows the high scores
        lblScores.Left = ((pnlPStim.Right + Screen.PrimaryScreen.Bounds.Width - lblScores.Width) / 2)
        lstScores.Left = lblScores.Left + (lblScores.Width - lstScores.Width) / 2
        lstScores.Items.Clear()

        For x = 0 To _Names.Count - 1
            lstScores.Items.Add(_Names(x) & " - " & _TopScores(x))
        Next

        Return True
    End Function

    ''' <summary>
    ''' Verifies that the necessary folders and files exist.
    ''' </summary>
    ''' <param name="fldr">Folder in which data will be saved.</param>
    Private Sub checkLoaders(fldr As String)
        ' This is used to check whether the necessary files exist.
        ' If not, this will create them.
        Dim outFile As System.IO.StreamWriter

        With My.Computer.FileSystem
            ' Check that the directory exists.
            If Not .DirectoryExists(fldr) Then
                .CreateDirectory(fldr)
            End If

            ' Set up the default high scores if it doesn't exist.
            _HSFile = fldr & "HighScores.csv"
            If Not .FileExists(_HSFile) Then
                outFile = .OpenTextFileWriter(_HSFile, False)
                outFile.WriteLine("Name,Score")
                outFile.WriteLine("???,0")
                outFile.WriteLine("???,0")
                outFile.WriteLine("???,0")
                outFile.WriteLine("???,0")
                outFile.WriteLine("???,0")
                outFile.Close()
            End If

            ' Set up the default run log if it doesn't exist.
            _RunLog = fldr & "RunLog.csv"
            If Not .FileExists(_RunLog) Then
                outFile = .OpenTextFileWriter(_RunLog, False)
                outFile.WriteLine("ID,Date,StartTime,EndTime")
                outFile.Close()
            End If
        End With
    End Sub

    Private Sub frmSingle_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim PanSize As UInteger = Screen.PrimaryScreen.Bounds.Width * 0.05
        Dim PaddingWidth As UInteger = PanSize / 2

        'Counts the number of trials that will "test" the participant
        For Each s As Char In _SchedType
            If s = "T" Then _NumScheds += 1
        Next

        'Sets starting values and prepares certain parts of the environment
        _CurrentAlt = 1
        _ScheduleIterator = 0
        tStimDur.Interval = _StimDur

        'Initiates the objects and lists
        _Timer = New Stopwatch
        _Environment = New cEnvironment
        _Effects = New List(Of Decimal)
        _SchedOrder = New List(Of Integer)

        '**The rest of this section prepares the form***
        'Sets up the group box that holds the disciminative stimuli
        gbDiscStim.Width = PaddingWidth * (_NumScheds + 1) + PanSize * _NumScheds
        gbDiscStim.Left = (Screen.PrimaryScreen.Bounds.Width - gbDiscStim.Width) / 2

        'Sets up the Discriminative Stimuli (all values are relative to the inside of the group box)
        ReDim _SDPanels(0 To _NumScheds - 1)
        For x As UInteger = 0 To _NumScheds - 1
            _SDPanels(x) = New Panel
            _SDPanels(x).Width = PanSize
            _SDPanels(x).Height = PanSize
            _SDPanels(x).BackColor = _StimDSchedule
            _SDPanels(x).Left = PaddingWidth * (x + 1) + PanSize * x
            _SDPanels(x).Top = (gbDiscStim.Height - _SDPanels(x).Height) / 2
            _SDPanels(x).BorderStyle = BorderStyle.FixedSingle
        Next
        gbDiscStim.Controls.AddRange(_SDPanels) 'Adds the discriminative stimuli to the group box

        'Adjusts the location of the points label and the text boxes that display the points
        lblPoints.Left = (Screen.PrimaryScreen.Bounds.Width - lblPoints.Width) / 2
        txt2Place.Left = Screen.PrimaryScreen.Bounds.Width / 2
        txt1Place.Left = txt2Place.Right
        txt3Place.Left = txt2Place.Left - txt3Place.Width
        txt4Place.Left = txt3Place.Left - txt4Place.Width

        'Adjusts the placement of the "lever" and the R+ and P+ discriminative stimuli
        bttnLever.Top = txt1Place.Bottom + Screen.PrimaryScreen.Bounds.Height * 0.05
        bttnLever.Height = Screen.PrimaryScreen.Bounds.Height * 1 / 3
        bttnLever.Width = Screen.PrimaryScreen.Bounds.Width * 1 / 3
        bttnLever.Left = (Screen.PrimaryScreen.Bounds.Width - bttnLever.Width) / 2
        bttnLever.PressKey = _ResponseKey

        bttnFindley.Left = bttnLever.Left
        bttnFindley.Width = bttnLever.Width
        bttnFindley.Top = bttnLever.Bottom + Screen.PrimaryScreen.Bounds.Height * 0.025
        bttnFindley.Height = Screen.PrimaryScreen.Bounds.Height * 1 / 6
        bttnFindley.PressKey = _SwitchKey

        pnlRStim.Height = bttnLever.Height * 2 / 3
        pnlPStim.Height = pnlRStim.Height
        pnlRStim.Top = bttnLever.Top + (bttnLever.Height - pnlRStim.Height) / 2
        pnlPStim.Top = pnlRStim.Top
        pnlRStim.Width = pnlRStim.Height
        pnlPStim.Width = pnlPStim.Height
        pnlRStim.Left = bttnLever.Left - pnlRStim.Width * 1.5
        pnlPStim.Left = bttnLever.Right + pnlPStim.Width * 0.5

        'Positions the High Scores
        lblScores.Left = pnlPStim.Left + (pnlPStim.Width - lblScores.Width) / 2
        lblScores.Top = pnlPStim.Bottom + Screen.PrimaryScreen.Bounds.Height * 0.01
        lstScores.Width = lblScores.Width
        lstScores.Left = lblScores.Left
        lstScores.Top = lblScores.Bottom + Screen.PrimaryScreen.Bounds.Height * 0.005
        lstScores.Height = bttnFindley.Bottom - lstScores.Top
    End Sub

    ''' <summary>
    ''' Starts the experiment
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub StartExperiment()
        Dim outFile As System.IO.StreamWriter

        'Prepares the environment to begin accepting responses
        BuildEnvironment() 'This sub-routine constructs the environment together
        _Environment.Prepare()

        'Adds all of the unique schedule IDs
        For Each sched As ExpSchedule In _Environment.Schedules
            If Not _SchedOrder.Contains(sched.Schedule) Then _SchedOrder.Add(sched.Schedule)
        Next

        'Randomizes the schedule if necessary
        If _RandOrder Then
            Dim omit As New List(Of Integer)
            Dim values As New List(Of String)

            For x As UInteger = 0 To _SchedOrder.Count - 1
                If Not _SchedType(x) = "T" Then
                    values.Add(_SchedOrder(x))
                    omit.Add(x)
                End If
            Next

            For x As UInteger = 0 To omit.Count - 1
                _SchedOrder.RemoveAt(omit(omit.Count - x - 1))
            Next

            'Shuffles the remainder
            _SchedOrder = ShuffleList(_SchedOrder)

            For x As UInteger = 0 To omit.Count - 1
                _SchedOrder.Insert(omit(x), values(x))
            Next
        End If

        For x As UInteger = 0 To _SchedOrder.Count - 1
            If _SchedType(x) = "B" Then
                _BreakPoints.Add(x)
            End If
        Next

        'Goes through the schedules and sets the environment with the applicable values
        For Each sched As ExpSchedule In _Environment.Schedules
            If sched.Schedule = _SchedOrder(_ScheduleIterator) Then
                _Environment.Components(sched.CompID).ParamVal(sched.ParamName) = sched.ParamVal
            End If
        Next
        _Environment.Prepare()

        'Changes the form's display to start of the experiment and sets the _Started parameter to True
        _Started = True
        bttnLever.Text = ""
        DispSD(_SchedOrder(_ScheduleIterator))

        'Starts the timers
        _Timer.Restart()
        tSchedDur.Interval = _SchedDurs(_ScheduleIterator)
        tSchedDur.Start()

        'Debug output
        If _Debug Then Debug.Print("Experiment Successfully Started")

        outFile = My.Computer.FileSystem.OpenTextFileWriter(_RunLog, True)
        outFile.Write(_ID & ",")
        outFile.Write(_Date & ",")
        outFile.Write(_Time & ",")
        outFile.Close()

        'Hides the top scores
        lstScores.Visible = False
        lblScores.Visible = False
    End Sub

    ''' <summary>
    ''' This ends the experiment by saving all of the data and closing the form.
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub TerminateExperiment()
        Dim outFile As IO.StreamWriter

        'Ends the experiment and saves all data
        If _CollectData And _Started Then
            _PartOutput.Close()

            'Adds the end time
            outFile = My.Computer.FileSystem.OpenTextFileWriter(_RunLog, True)
            outFile.WriteLine(FormatDateTime(DateTime.Now, DateFormat.ShortTime))
            outFile.Close()
        End If

        'Check to see if the participant's score makes it into the top scores
        For x = 0 To _TopScores.Count - 1
            If _TopScores(x) <= _Points Then
                Dim N As String = ""
                Do
                    N = InputBox("You just beat a high score! Type in three letters to represent you in the top scores.", "High Score!")

                    If N.Length <> 3 Then N = ""
                Loop Until N <> ""

                'Adds in the new top score
                _TopScores.Insert(x, _Points)
                _Names.Insert(x, N)
                _TopScores.RemoveAt(_TopScores.Count - 1)
                _Names.RemoveAt(_Names.Count - 1)

                'Writes the scores
                Dim SW As New IO.StreamWriter(_HSFile, False)
                SW.WriteLine("Name,Score")
                For y = 0 To _TopScores.Count - 1
                    SW.WriteLine(_Names(y) & "," & _TopScores(y))
                Next
                SW.Close()

                'Kicks out of the loop
                Exit For
            End If
        Next

        'Closes the form and then ends the program
        frmPartInfo.Close()
        Me.Close()
        End
    End Sub

    ''' <summary>
    ''' Detects the key press combination of "Ctrl+Q" to allow for early termination and saves the data up to that point.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub KeyBoardDetection(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        'Quits if "Ctrl+Q" is pressed
        If (e.KeyCode And Not Keys.Modifiers) = Keys.Q AndAlso e.Modifiers = Keys.Control Then
            TerminateExperiment() 'Saves the data that has been collected
            Me.Close() 'Closes the program
        End If

        'Handles Keyboardmode
        If _KeyBoardMode Then
            Select Case e.KeyCode
                Case _ResponseKey
                    If Not bttnLever.Focused Then
                        ' Will pass the key press to the lever key
                        bttnLever.Focus()
                        bttnLever_KeyDown(sender, e)
                        e.Handled = True
                        bttnLever.Depressed = True
                    End If
                Case _SwitchKey
                    If Not bttnFindley.Focused Then
                        ' Will pass the key press to the findley key
                        bttnFindley.Focus()
                        bttnFindley_KeyDown(sender, e)
                        bttnFindley.Depressed = True
                        e.Handled = True
                    End If
                Case Else
                    e.Handled = True
            End Select
        Else
            e.Handled = True
        End If
    End Sub

    ''' <summary>
    ''' Builds the environment that the experiment utilizes
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub BuildEnvironment()
        With _Environment
            'Adds the necessary components
            .Components.Add(New cELever_PRange)                     'Comp #0 (L1)
            .Components.Add(New cELever_PRange)                     'Comp #1 (L2)
            .Components.Add(New cETape_RandomIntervalExponential)   'Comp #2 (T1)
            .Components.Add(New cETape_RandomIntervalExponential)   'Comp #3 (T2)
            .Components.Add(New cETape_RandomIntervalExponential)   'Comp #4 (T3)
            .Components.Add(New cETape_RandomIntervalExponential)   'Comp #5 (T4)
            .Components.Add(New cEMagazine_Fixed)                   'Comp #6 (M1)
            .Components.Add(New cEMagazine_Fixed)                   'Comp #7 (M2)
            .Components.Add(New cEMagazine_Fixed)                   'Comp #8 (M1)
            .Components.Add(New cEMagazine_Fixed)                   'Comp #9 (M2)
            .Components.Add(New cEChangeOver_Fixed)                 'Comp #10 (COD)

            'Sets the priority order (i.e., the order of execution; lower numbers go first and numbers that are the same occur simultaneously)
            .Components(0).Priority = 1
            .Components(1).Priority = 1
            .Components(10).Priority = 2
            .Components(2).Priority = 3
            .Components(3).Priority = 3
            .Components(4).Priority = 3
            .Components(5).Priority = 3
            .Components(6).Priority = 4
            .Components(7).Priority = 4
            .Components(8).Priority = 4
            .Components(9).Priority = 4

            'Sets the parameters of the apparatus
            .Components(0).ParamVal("LBound") = 1
            .Components(0).ParamVal("UBound") = 1
            .Components(1).ParamVal("LBound") = 2
            .Components(1).ParamVal("UBound") = 2
            .Components(10).ParamVal("Duration") = _CODs(0)

            'Adds the experimental schedules
            For x = 0 To _SchedType.Count - 1
                .Schedules.Add(New ExpSchedule With {.Schedule = x, .CompID = 2, .ParamName = "Interval", .ParamVal = _Comp1RIntervals(x)})
                .Schedules.Add(New ExpSchedule With {.Schedule = x, .CompID = 3, .ParamName = "Interval", .ParamVal = _Comp2RIntervals(x)})
                .Schedules.Add(New ExpSchedule With {.Schedule = x, .CompID = 4, .ParamName = "Interval", .ParamVal = _Comp1PIntervals(x)})
                .Schedules.Add(New ExpSchedule With {.Schedule = x, .CompID = 5, .ParamName = "Interval", .ParamVal = _Comp2PIntervals(x)})
                .Schedules.Add(New ExpSchedule With {.Schedule = x, .CompID = 6, .ParamName = "Amount", .ParamVal = _Comp1RMagnitudes(x)})
                .Schedules.Add(New ExpSchedule With {.Schedule = x, .CompID = 7, .ParamName = "Amount", .ParamVal = _Comp2RMagnitudes(x)})
                .Schedules.Add(New ExpSchedule With {.Schedule = x, .CompID = 8, .ParamName = "Amount", .ParamVal = _Comp1PMagnitudes(x)})
                .Schedules.Add(New ExpSchedule With {.Schedule = x, .CompID = 9, .ParamName = "Amount", .ParamVal = _Comp2PMagnitudes(x)})
            Next

            'Wires the components together
            .Components(0).WireTo(2)    'L1 to T1
            .Components(0).WireTo(4)    'L1 to T3
            .Components(0).WireTo(10)   'L1 to COD
            .Components(1).WireTo(3)    'L2 to T2
            .Components(1).WireTo(5)    'L2 to T4
            .Components(1).WireTo(10)   'L2 to COD
            .Components(10).WireTo(2)   'COD to T1
            .Components(10).WireTo(3)   'COD to T2
            .Components(10).WireTo(4)   'COD to T3
            .Components(10).WireTo(5)   'COD to T4
            .Components(2).WireTo(6)    'T1 to M1
            .Components(3).WireTo(7)    'T2 to M2
            .Components(4).WireTo(8)    'T3 to M3
            .Components(5).WireTo(9)    'T4 to M4
        End With

        _Environment.Prepare()
    End Sub


    ''' <summary>
    ''' Outputs data and determines the consequences of the participant's behavior.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub bttnLever_Click(sender As Object, e As EventArgs) Handles bttnLever.Click
        LeverPress()
    End Sub

    Private Sub bttnLever_KeyDown(sender As Object, e As KeyEventArgs) Handles bttnLever.KeyDown
        LeverPress()
    End Sub

    Private Sub LeverPress()
        Dim reinf As Boolean = False

        If _Started = False Then
            StartExperiment() '_Started is set to True in this sub-routine
        Else
            Dim time As UInteger = _Timer.ElapsedMilliseconds 'Collects the time so this is the same value throughout this function

            If _Debug Then Debug.Print("Press Time: " & time)

            'Determines how the environment responds to the participant's behavior and makes sure that information is displayed to the participant
            _Effects.Clear()
            _Effects.AddRange(_Environment.ReceiveBehavior(_CurrentAlt, time))
            reinf = DispConsq(_Effects) 'This sub-routine displays the environmental consequences (i.e., point changes and stimuli presentation)

            'Outputs the current time, the alternative that was selected, and whether it was reinforced or punished
            If _CollectData Then
                _PartOutput.WriteLine(_SchedNums(_SchedOrder(_ScheduleIterator)) & "," _
                                       & time & "," _
                                       & _CurrentAlt & "," _
                                       & Int(reinf))
            End If
        End If
    End Sub

    ''' <summary>
    ''' Switches between the response alternatives, displays the changes in the discriminative stimulus/stimuli, and outputs data.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub bttnFindley_Click(sender As Object, e As EventArgs) Handles bttnFindley.Click
        FindleyPress()
    End Sub

    Private Sub bttnFindley_KeyDown(sender As Object, e As KeyEventArgs) Handles bttnFindley.KeyDown
        FindleyPress()
    End Sub

    Private Sub FindleyPress()
        'Ensures that this has no effect if the experiment has not begun.
        If _Started Then
            Dim time As UInteger = _Timer.ElapsedMilliseconds 'Collects the time so this is the same value throughout this function

            'Alternates between the 1st and 2nd response alternative, sends the behavior to the environment, and displays the change in the discriminative stimulus.
            '    The effects of the environment are not displayed because reinforcement and punishment cannot occur due to the changeover delay.
            _CurrentAlt = IIf(_CurrentAlt = 1, 2, 1)
            _Environment.ReceiveBehavior(_CurrentAlt, time)
            DispSD(_SchedOrder(_ScheduleIterator))

            'Outputs the current time, what the new alternative is, and a CO parameter that indicates that a changeover occured
            If _CollectData Then
                _PartOutput.WriteLine(_SchedNums(_SchedOrder(_ScheduleIterator)) & "," _
                                       & time & "," _
                                       & "S,0")
            End If
        End If
    End Sub

    ''' <summary>
    ''' Displays the changes in points and the R and P stimuli.
    ''' </summary>
    ''' <param name="Effects">The programmed consequences of the environment</param>
    ''' <remarks></remarks>
    Private Function DispConsq(ByVal Effects As List(Of Decimal)) As Boolean
        Dim RStim = False, PStim As Boolean = False

        'Determines how the environmental effects should be displayed
        For Each e As Decimal In Effects
            If e > 0 Then RStim = True
            If e < 0 Then PStim = True
            _Points += Int(e)
        Next

        'Presents the reinforcement stimuli
        If RStim Then
            pnlRStim.BackColor = _RStimColor
            My.Computer.Audio.Play(My.Resources.BellDing, AudioPlayMode.Background)
        End If

        'Presents the punishment stimuli
        If PStim Then
            pnlPStim.BackColor = _PStimColor
            My.Computer.Audio.Play(My.Resources.womp, AudioPlayMode.Background)
        End If

        'Restarts the stimuli timer so that the R and P stimuli end after the elapsed time
        ' (See tStimDur_Tick to see what occurs when the timer elapses)
        If RStim Or PStim Then tStimDur.Stop() : tStimDur.Start()

        'Displays the points
        If _Points < 0 Then _Points = 0 'Ensures that points cannot become negative
        txt4Place.Text = Int((_Points Mod 10000) / 1000)
        txt3Place.Text = Int((_Points Mod 1000) / 100)
        txt2Place.Text = Int((_Points Mod 100) / 10)
        txt1Place.Text = (_Points Mod 10)

        Return RStim
    End Function

    ''' <summary>
    ''' Displays the current discriminative stimulus/stimuli
    ''' </summary>
    ''' <param name="CurrStim">The current schedule iteration which determines the discriminative stimulus display.</param>
    ''' <remarks></remarks>
    Private Sub DispSD(ByVal CurrStim As UInteger)
        'Determines what type of schedule needs to be displayed
        Select Case _SchedType(CurrStim)
            Case "A"                                'For acquisition schedules (all are lit up)
                'For Each p As Panel In _SDPanels : p.BackColor = IIf(_CurrentAlt = 1, _StimDAlt1Color, _StimDAlt2Color) : Next
                For Each p As Panel In _SDPanels : p.BackColor = _StimDSchedule : Next
            Case "E"                                'For extinction schedules (all are turned off)
                For Each p As Panel In _SDPanels : p.BackColor = _NoStim : Next
            Case "T"                                'Lights up only the current discriminative stimuli
                Dim OffSet As Integer

                'Turns off all of the discriminative stimuli
                For x = 0 To _SDPanels.Count - 1
                    _SDPanels(x).BackColor = _NoStim
                Next

                'Determines the offset, which is necessary to ensure that correct discriminative stimuli is displayed.
                For x As UInteger = 0 To CurrStim
                    If _SchedType(x) <> "T" Then OffSet += 1
                Next

                'Lights up the correct discriminative stimulus
                '_SDPanels(CurrStim - OffSet).BackColor = IIf(_CurrentAlt = 1, _StimDAlt1Color, _StimDAlt2Color)
                _SDPanels(CurrStim - OffSet).BackColor = _StimDSchedule
        End Select

        'Displays the color of the current discriminative stimulus
        bttnLever.BackColor = IIf(_CurrentAlt = 1, _StimDAlt1Color, _StimDAlt2Color)
    End Sub

    Private Sub tStimDur_Tick(sender As Object, e As EventArgs) Handles tStimDur.Tick
        'Stops the timer
        tStimDur.Stop()

        'Resets the R and P stimuli to being turned off
        pnlPStim.BackColor = _PStimOffColor
        pnlRStim.BackColor = _RStimOffColor
    End Sub

    ''' <summary>
    ''' This keeps track of the experiment's progress and performs all of the necessary data output at the correct times.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub tSchedDur_Tick(sender As Object, e As EventArgs) Handles tSchedDur.Tick
        'Increase the schedule number
        _ScheduleIterator += 1

        'Stops the block timer
        tSchedDur.Stop()

        'Takes a break if necessary
        If _ForceBreak And _BreakPoints.Count > 0 Then
            If _BreakPoints.Contains(_ScheduleIterator) Then
                Dim EndTime As UInteger = _Timer.ElapsedMilliseconds + _SchedDurs(_ScheduleIterator)

                bttnFindley.Enabled = False
                bttnFindley.Text = ""
                bttnLever.Enabled = False
                _DisableKBResp = True

                'Forces the user to take a break
                Do
                    bttnLever.Text = String.Format("Break For:" & Chr(13) & "{0}" & Chr(58) & "{1:00}", Int((EndTime - _Timer.ElapsedMilliseconds) / 60000), Int(((EndTime - _Timer.ElapsedMilliseconds) Mod 60000) / 1000))
                    Application.DoEvents()
                Loop Until _Timer.ElapsedMilliseconds >= EndTime

                Dim EndBreak
                Do
                    EndBreak = MsgBox("The break is over. Press the OK button to continue the task.", MsgBoxStyle.DefaultButton2 + MsgBoxStyle.OkCancel, "Break")
                Loop Until EndBreak = vbOK

                _ScheduleIterator += 1
                _DisableKBResp = False
                bttnLever.Text = ""
                bttnFindley.Text = "SWITCH"
                bttnFindley.Enabled = True
                bttnLever.Enabled = True
            End If
        End If

        'If the experiment is not over then...
        If _ScheduleIterator < _SchedType.Count Then
            'Sets all of the parameter values for the next schedule
            For x As UInteger = 0 To _Environment.Schedules.Count - 1
                If _Environment.Schedules(x).Schedule = _SchedOrder(_ScheduleIterator) Then
                    With _Environment.Schedules(x)
                        _Environment.Components(.CompID).ParamVal(.ParamName) = .ParamVal
                    End With
                End If
            Next

            'Displays the current discriminative stimulus
            DispSD(_SchedOrder(_ScheduleIterator))

            'Resets the environment and sets it up to run quickly.
            _Environment.Prepare()
        Else
            'Ends the experiment
            TerminateExperiment()
        End If

        tSchedDur.Interval = _SchedDurs(_ScheduleIterator)
        tSchedDur.Start()
    End Sub


    ''' <summary>
    ''' Prevents the user from interacting with the text boxes that display the number of collected points.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub RedirectFocus(sender As Object, e As EventArgs) Handles txt1Place.GotFocus, txt2Place.GotFocus, txt3Place.GotFocus, txt4Place.GotFocus
        Me.Focus()
    End Sub

    ''' <summary>
    ''' Prevents the user from interacting with the text boxes that display the number of collected points.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Points_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt1Place.KeyPress, txt2Place.KeyPress, txt3Place.KeyPress, txt4Place.KeyPress
        e.KeyChar = ""
        e.Handled = True
    End Sub


    Protected Overrides Function ProcessCmdKey(ByRef msg As Message, keyData As Keys) As Boolean
        If _DisableKBResp Then Return True

        Select Case CType(msg.WParam.ToInt32, Keys)
            Case Keys.Enter
                'Disables the Enter key from clicking the first button on the form.
                Return True
            Case Else
                Return MyBase.ProcessCmdKey(msg, keyData)
        End Select
    End Function

End Class

