﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmFindley
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.txt3Place = New System.Windows.Forms.TextBox()
        Me.gbDiscStim = New System.Windows.Forms.GroupBox()
        Me.pnlRStim = New System.Windows.Forms.Panel()
        Me.pnlPStim = New System.Windows.Forms.Panel()
        Me.lblPoints = New System.Windows.Forms.Label()
        Me.txt4Place = New System.Windows.Forms.TextBox()
        Me.txt2Place = New System.Windows.Forms.TextBox()
        Me.txt1Place = New System.Windows.Forms.TextBox()
        Me.tStimDur = New System.Windows.Forms.Timer(Me.components)
        Me.lblScores = New System.Windows.Forms.Label()
        Me.lstScores = New System.Windows.Forms.ListBox()
        Me.tSchedDur = New System.Windows.Forms.Timer(Me.components)
        Me.bttnFindley = New PRESSB.cDepressableButton()
        Me.bttnLever = New PRESSB.cDepressableButton()
        Me.SuspendLayout()
        '
        'txt3Place
        '
        Me.txt3Place.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt3Place.Location = New System.Drawing.Point(957, 351)
        Me.txt3Place.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txt3Place.Name = "txt3Place"
        Me.txt3Place.Size = New System.Drawing.Size(58, 57)
        Me.txt3Place.TabIndex = 1
        Me.txt3Place.TabStop = False
        Me.txt3Place.Text = "0"
        Me.txt3Place.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'gbDiscStim
        '
        Me.gbDiscStim.BackColor = System.Drawing.Color.Black
        Me.gbDiscStim.Location = New System.Drawing.Point(15, 19)
        Me.gbDiscStim.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.gbDiscStim.Name = "gbDiscStim"
        Me.gbDiscStim.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.gbDiscStim.Size = New System.Drawing.Size(1995, 200)
        Me.gbDiscStim.TabIndex = 2
        Me.gbDiscStim.TabStop = False
        '
        'pnlRStim
        '
        Me.pnlRStim.BackColor = System.Drawing.Color.DarkGreen
        Me.pnlRStim.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlRStim.ForeColor = System.Drawing.Color.Black
        Me.pnlRStim.Location = New System.Drawing.Point(345, 586)
        Me.pnlRStim.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.pnlRStim.Name = "pnlRStim"
        Me.pnlRStim.Size = New System.Drawing.Size(230, 201)
        Me.pnlRStim.TabIndex = 2
        '
        'pnlPStim
        '
        Me.pnlPStim.BackColor = System.Drawing.Color.DarkRed
        Me.pnlPStim.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlPStim.ForeColor = System.Drawing.Color.Khaki
        Me.pnlPStim.Location = New System.Drawing.Point(1450, 586)
        Me.pnlPStim.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.pnlPStim.Name = "pnlPStim"
        Me.pnlPStim.Size = New System.Drawing.Size(230, 201)
        Me.pnlPStim.TabIndex = 3
        '
        'lblPoints
        '
        Me.lblPoints.AutoSize = True
        Me.lblPoints.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblPoints.Font = New System.Drawing.Font("Microsoft Sans Serif", 30.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPoints.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblPoints.Location = New System.Drawing.Point(919, 272)
        Me.lblPoints.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblPoints.Name = "lblPoints"
        Me.lblPoints.Size = New System.Drawing.Size(197, 69)
        Me.lblPoints.TabIndex = 10
        Me.lblPoints.Text = "Points"
        '
        'txt4Place
        '
        Me.txt4Place.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt4Place.Location = New System.Drawing.Point(901, 351)
        Me.txt4Place.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txt4Place.Name = "txt4Place"
        Me.txt4Place.Size = New System.Drawing.Size(58, 57)
        Me.txt4Place.TabIndex = 11
        Me.txt4Place.TabStop = False
        Me.txt4Place.Text = "0"
        Me.txt4Place.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt2Place
        '
        Me.txt2Place.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt2Place.Location = New System.Drawing.Point(1014, 351)
        Me.txt2Place.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txt2Place.Name = "txt2Place"
        Me.txt2Place.Size = New System.Drawing.Size(58, 57)
        Me.txt2Place.TabIndex = 12
        Me.txt2Place.TabStop = False
        Me.txt2Place.Text = "0"
        Me.txt2Place.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt1Place
        '
        Me.txt1Place.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt1Place.Location = New System.Drawing.Point(1068, 351)
        Me.txt1Place.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txt1Place.Name = "txt1Place"
        Me.txt1Place.Size = New System.Drawing.Size(58, 57)
        Me.txt1Place.TabIndex = 13
        Me.txt1Place.TabStop = False
        Me.txt1Place.Text = "0"
        Me.txt1Place.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tStimDur
        '
        '
        'lblScores
        '
        Me.lblScores.AutoSize = True
        Me.lblScores.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblScores.Location = New System.Drawing.Point(1684, 815)
        Me.lblScores.Name = "lblScores"
        Me.lblScores.Size = New System.Drawing.Size(250, 46)
        Me.lblScores.TabIndex = 18
        Me.lblScores.Text = "High Scores"
        Me.lblScores.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lstScores
        '
        Me.lstScores.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstScores.FormattingEnabled = True
        Me.lstScores.ItemHeight = 37
        Me.lstScores.Location = New System.Drawing.Point(1679, 876)
        Me.lstScores.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.lstScores.Name = "lstScores"
        Me.lstScores.SelectionMode = System.Windows.Forms.SelectionMode.None
        Me.lstScores.Size = New System.Drawing.Size(255, 152)
        Me.lstScores.TabIndex = 19
        Me.lstScores.TabStop = False
        '
        'tSchedDur
        '
        '
        'bttnFindley
        '
        Me.bttnFindley.Font = New System.Drawing.Font("Microsoft Sans Serif", 30.0!, System.Drawing.FontStyle.Bold)
        Me.bttnFindley.Location = New System.Drawing.Point(618, 958)
        Me.bttnFindley.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.bttnFindley.Name = "bttnFindley"
        Me.bttnFindley.PressKey = System.Windows.Forms.Keys.None
        Me.bttnFindley.PreventKeyClicking = False
        Me.bttnFindley.Size = New System.Drawing.Size(788, 162)
        Me.bttnFindley.TabIndex = 16
        Me.bttnFindley.TabStop = False
        Me.bttnFindley.Text = "SWITCH"
        Me.bttnFindley.UseVisualStyleBackColor = True
        '
        'bttnLever
        '
        Me.bttnLever.Font = New System.Drawing.Font("Microsoft Sans Serif", 30.0!, System.Drawing.FontStyle.Bold)
        Me.bttnLever.Location = New System.Drawing.Point(618, 445)
        Me.bttnLever.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.bttnLever.Name = "bttnLever"
        Me.bttnLever.PressKey = System.Windows.Forms.Keys.None
        Me.bttnLever.PreventKeyClicking = False
        Me.bttnLever.Size = New System.Drawing.Size(788, 481)
        Me.bttnLever.TabIndex = 15
        Me.bttnLever.TabStop = False
        Me.bttnLever.Text = "START"
        Me.bttnLever.UseVisualStyleBackColor = True
        '
        'frmFindley
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DimGray
        Me.ClientSize = New System.Drawing.Size(1946, 1106)
        Me.Controls.Add(Me.lstScores)
        Me.Controls.Add(Me.lblScores)
        Me.Controls.Add(Me.bttnFindley)
        Me.Controls.Add(Me.bttnLever)
        Me.Controls.Add(Me.txt1Place)
        Me.Controls.Add(Me.txt2Place)
        Me.Controls.Add(Me.txt4Place)
        Me.Controls.Add(Me.lblPoints)
        Me.Controls.Add(Me.pnlPStim)
        Me.Controls.Add(Me.pnlRStim)
        Me.Controls.Add(Me.gbDiscStim)
        Me.Controls.Add(Me.txt3Place)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.KeyPreview = True
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "frmFindley"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Two Alternative Response Panel"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txt3Place As System.Windows.Forms.TextBox
    Friend WithEvents gbDiscStim As System.Windows.Forms.GroupBox
    Friend WithEvents pnlRStim As System.Windows.Forms.Panel
    Friend WithEvents pnlPStim As System.Windows.Forms.Panel
    Friend WithEvents lblPoints As System.Windows.Forms.Label
    Friend WithEvents txt4Place As System.Windows.Forms.TextBox
    Friend WithEvents txt2Place As System.Windows.Forms.TextBox
    Friend WithEvents txt1Place As System.Windows.Forms.TextBox
    Friend WithEvents tStimDur As System.Windows.Forms.Timer
    Friend WithEvents bttnLever As PRESSB.cDepressableButton
    Friend WithEvents bttnFindley As PRESSB.cDepressableButton
    Friend WithEvents lblScores As System.Windows.Forms.Label
    Friend WithEvents lstScores As ListBox
    Friend WithEvents tSchedDur As Timer
End Class
