﻿Public Class frmPartInfo
    Private ReadOnly _aboutMsg =
        "                        PRESS-B" & Environment.NewLine &
        "                   Version: " & ProductVersion & Environment.NewLine &
        "                  Emory University" & Environment.NewLine & Environment.NewLine &
        "       Author: Olivia L. Calvin, PhD" & Environment.NewLine &
        "     Contact: ocalvin05@gmail.com" & Environment.NewLine & Environment.NewLine &
        "           PI: Jack J McDowell, PhD" & Environment.NewLine &
        "      Contact: psyjjmd@emory.edu"

    Private load_fldr = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\PRESSB\"
    Private exp_hdr As String = "Sched,Type,Dur,Gold_RI,Gold_Mag,Blue_RI,Blue_Mag,CO"


    ''' <summary>
    ''' Verifies that the necessary files exist and creates them if they don`t
    ''' </summary>
    Private Sub checkLoaders()
        ' This is used to check whether the necessary files exist.
        ' If not, this will create them.
        Dim outFile As System.IO.StreamWriter

        With My.Computer.FileSystem
            ' Check that the directory exists.
            If Not .DirectoryExists(load_fldr) Then
                .CreateDirectory(load_fldr)
            End If

            ' Set up the default experiment if it doesn't exist.
            If Not .DirectoryExists(load_fldr & "Experiments\") Then
                .CreateDirectory(load_fldr & "Experiments\")
            End If

            ' Sets up a basic findley file for input.
            If Not .FileExists(load_fldr & "Experiments\findley.txt") Then
                outFile = .OpenTextFileWriter(load_fldr & "Experiments\findley.txt", False)
                outFile.WriteLine(exp_hdr)
                outFile.WriteLine("1,A,60000,700,1,700,1,500")
                outFile.WriteLine("2,T,200000,7000,1,1000,1,500")
                outFile.WriteLine("3,T,200000,6250,1,1750,1,500")
                outFile.WriteLine("4,T,200000,5500,1,2500,1,500")
                outFile.WriteLine("5,T,200000,4750,1,3250,1,500")
                outFile.WriteLine("6,B,5000,0,0,0,0,0")
                outFile.WriteLine("7,T,200000,4000,1,4000,1,500")
                outFile.WriteLine("8,T,200000,3250,1,4750,1,500")
                outFile.WriteLine("9,T,200000,2500,1,5500,1,500")
                outFile.WriteLine("10,T,200000,1750,1,6250,1,500")
                outFile.WriteLine("11,T,200000,1000,1,7000,1,500")
                outFile.WriteLine("12,E,30000,0,0,0,0,500")
                outFile.Close()
            End If
        End With

    End Sub

    Private Sub frmPartInfo_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Check to see if the loading folder exists
        checkLoaders()

        'Sets the default values
        txtParticipant.Text = ""
        mskDate.Text = String.Format("{0:D2}/{1:D2}/{2:D4}", DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Year)
        mskTime.Text = FormatDateTime(DateTime.Now, DateFormat.ShortTime)

        ' Loads the various experiments
        For Each foundFile As String In My.Computer.FileSystem.GetFiles(load_fldr & "Experiments\")
            foundFile = foundFile.Replace(load_fldr & "Experiments\", "")
            lbExperiment.Items.Add(foundFile)
        Next
        lbExperiment.SelectedIndex = 0

    End Sub

    Private Sub bttnBegin_Click(sender As Object, e As EventArgs) Handles bttnBegin.Click
        Dim s_part As String
        Dim s_date As String
        Dim s_time As String
        Dim exp_file As String

        'Collects the participant information.
        s_part = txtParticipant.Text
        s_date = mskDate.Text
        s_time = mskTime.Text
        exp_file = load_fldr & "Experiments\" & lbExperiment.SelectedItem

        frmFindley.SetParticipantInfo(exp_file, s_part, s_date, s_time)
        frmFindley.Show()
    End Sub

    ''' <summary>
    ''' Provides information about this version of the program and the relevant information.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub bttnAbout_Click(sender As Object, e As EventArgs) Handles bttnAbout.Click
        MsgBox(_aboutMsg, vbOKOnly, "About")
    End Sub
End Class