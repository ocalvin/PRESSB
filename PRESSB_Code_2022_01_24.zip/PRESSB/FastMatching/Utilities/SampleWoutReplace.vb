﻿Option Explicit On

Public Class SampleWoutReplace

    'Facilitates sampling integers without replacement from a set of unique integers.  

    'USAGE-----------------------------------------------------------------------------------------
    'Instantiate an instance of this class in the calling program, say m_objSampler.
    'Pass an integer to the function OK.  If the integer is present in m_objSampler (i.e., it has
    'already been sampled and is in m_intList), then the function returns False, otherwise it adds 
    'the integer to m_intList and returns True.
    '
    'Typical syntax in the calling code is something like this, where m_objSampler is an
    'instantiation of this class:
    '            
    '            m_objSampler.Clear()
    '            For i = 1 to nOfSample
    '                Do
    '                    intItem = m_objRandom.RectangularInteger
    '                Loop Until m_objSampler.OK(intItem)
    '                'At this point intItem is sampled without replacement from the range specified
    '                'by the random number generator, and it can be added to a list or array that
    '                'contains the sample.
    '                '.
    '                '.
    '                '.
    '            Next

    'Be sure to call the Clear member of this class, as shown in the example above, before each new 
    'round of sampling.

    'Note:  it would be easy to add other data types by overloading the OK function and creating
    'the appropriate List<T> classes...or actually, by doing the generic thing.

    Private m_intList As New List(Of Integer)

    Public Function OK(ByVal intSampledInteger As Integer) As Boolean

        Dim blnPresentInList As Boolean

        'Check m_intList for presence of intSampledInteger
        For Each intNumber As Integer In m_intList
            If intSampledInteger = intNumber Then
                'The integer is already in m_intList
                blnPresentInList = True
                Exit For
            End If
        Next

        'If intSampledInteger is in m_intList, return False, otherwise add it to m_intList and return True.
        If blnPresentInList Then
            Return False ' Not OK.  This integer has already been sampled.
        Else
            m_intList.Add(intSampledInteger)
            Return True 'OK to use this integer.
        End If

    End Function

    Public Sub Remove(ByVal intToRemoveFromList As Integer)
        m_intList.Remove(intToRemoveFromList)
    End Sub

    Public Sub Clear()

        'Clears all integers from m_intList
        m_intList.Clear()

    End Sub

End Class
