Option Strict On
Public Structure DistributionStorage
    Dim UpperBound As Double    'Upper bound of bin
    Dim f As Integer            'frequency in bin
    Dim p As Single             'probability (relative frequency) in bin
    '...                         other elements may be present for other uses.
End Structure
Public Class cFrequencyDist

    'This class prepares a frequency distribution from an array of data,
    'given an array of bins with defined upper bounds.

    'Note that the FrequencyDistribution property is shared, i.e., it is not necessary
    'to instantiate an instance of the class.

    'Usage:  assign the FrequencyDistribution property to a DistributionStorage
    'structure in the calling program, passing the array of bins and array of data
    'as arguments.

    Shared ReadOnly Property FrequencyDistribution(ByVal binArray() As Double, ByVal dataArray() As Double) As DistributionStorage()
        Get
            Dim distribution() As DistributionStorage
            Dim i, j As Integer
            Dim nOfData, nOfBins, totalFrequency As Integer

            nOfData = UBound(dataArray)
            nOfBins = UBound(binArray)
            ReDim distribution(nOfBins)

            'Load upper bounds of bins
            For i = 1 To nOfBins
                distribution(i).UpperBound = binArray(i)
            Next

            'Sort data into bins
            For i = 1 To nOfData
                For j = 1 To nOfBins
                    If dataArray(i) <= distribution(j).UpperBound Then
                        distribution(j).f += 1
                        Exit For
                    End If
                Next j
            Next i

            'If there are any left over, add them to the last bin
            For i = 1 To nOfBins
                totalFrequency += distribution(i).f
            Next i
            distribution(nOfBins).f += (nOfData - totalFrequency)

            'Assign relative frequencies (probabilities) to the bins
            For i = 1 To nOfBins
                distribution(i).p = CSng(distribution(i).f / nOfData)
            Next i

            Return distribution
        End Get

    End Property

End Class
