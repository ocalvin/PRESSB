﻿Option Explicit On
Option Strict On
Imports System.Math

'This entire section has been reworked to primarily use the CRandomNumber class to make using
'  the random number generator types easier and more modular.  Previously the random generation
'  was tied into the class that ended up being instatiated in multiple places.  Now the code is set
'  up such that random number generation is done by modules with the class to be used to reference
'  them.

Public Enum Algorithm As Integer
    LinearCongruential = 1
    MersenneTwister = 2
    KnuthSubtractive = 3
End Enum

'Documentation

'6/2010  J. J McDowell

'This file contains 4 classes that can be used to generate random numbers using the Mersenne Twister (MT) 19937 algorithm,
'the Knuth Subtractive (KS) algorithm as implemented by .NET's Random class, and the linear congruential (LC) algorithm from
'Numerical Recipes.  The MT 19937 algorithm generates high quality random numbers with a very long period and is therefore
'preferred.  The Knuth Subtractive algorithm is also good, but has a shorter period (on the order of 10^16) and its iterates
'are alleged to have significant bit level correlations, although I'm not sure what that means.

'CRandomNumber is the principal class in this file.  An instance of this class must be created by the calling program; it manages 
'all three algorithms.

'The Mersenne Twister algorithm is implemented by the remaining three classes in the file, principally MTRandom.
'An instance of this class is instantiated in the constructor of the CRandomNumber class when the constructor is called with the 
'argument, Algorithm.MersenneTwister (see public enumeration above), or when it is called with no argument.  Hence, the MT 19937
'agorithm is the default.  MTRandomSaveStateException and MTRandomLoadStateException are exception classes for the MTRandom class.  
'The definition of MTRandom starts at the first bookmark in this file. 

'The Knuth Subtractive algorithm is implmented by .NET's Random class, which is instantiated in the constructor of the 
'CRandomNumber class when called with the argument, Algorithm.KnuthSubtractive (see public enumeration above).

'The linear congruential algorithm is implemented by the RectangularDeviateLC member of CRandomNumber.  The constructor of
'the CRandomNumber class must be called with the argument, Algorithm.LinearCongruential (see public enumeration above), to enable
'this algorithm.

'USAGE-------------------------------------------------------------------------------------------------------------------
'To run the Mersenne Twister algorithm, instantiate the CRandomNumber class using something like the following syntax:
'       Dim objRandomMT As New CRandomNumber(Algorithm.MersenneTwister).
'The argument (see public enumeration above) initializes the object to run the MT algorithm.  Instantiating the class 
'without an argument, as in
'       Dim objRandomMT as New CRandomNumber(),
'also runs the Mersenne Twister algorithm.  Hence it is the default.

'To run the Knuth Subtractive algorithm, instantiate the CRandomNumber class using something like the following syntax:
'       Dim objRandomKS as New CRandomNumber(Algorithm.KnuthSubtractive).
'The argument (see public enumeration above) initializes the object to run the KS algorithm.

'To run the linear congruential algorithm, instantiate the CRandomNumber class using something like the following syntax:
'       Dim objRandomLC As New CRandomNumber(Algorithm.LinearCongruential)
'The argument (see public enumeration above) initializes the object to run the LC algorithm

'The comments at the start of the CRandomNumber class (just below) are from the original implementation of
'CRandom (the name of the previous version of this class, which implemented the linear congruential algorithm only)
'and include descriptions of the principal properties that can be accessed from the CRandomNumber object.
'These descriptions have been updated to be consistent with the current implementation, which differs slightly from the 
'original one.  Random numbers are obtained by accessing one of these properties from the calling program.

'The original notes on the MTRandom class are given before that class is defined (line 394).


'6/8/2011
'Nick Calvin
'I have made some changes to this version which allow the user to set the seeds for the random number generators.
'I have made edits to the following:
'   MTRandom - This now assigns a seed parameter which can be read by CRandomNumber
'   CRandomNumber - This now has a read and writable property which allows the user to set or read the seed.
'                       - For the knuth subtractive the number of original normal

'10/18/2011
'Nick Calvin
'Added the Ziggurat method to the random number generator due to the increased processing speed and better results
'as is indicated in:
'   Thomas, D. B., Luk. W., Leong, P. H. W., and Villasenor, J. D. 2007. Gaussian random number generators.
'   ACM Comput. Surv. 39, 4, Article 11 (October 2007), 38 pages DOI = 10.1145/1287620.1287622
'   http://doi.acm.org/10.1145/1287620.1287622
'
'The implemented code was translated from:
'   MARSAGLIA, G. AND TSANG, W. W. 2000. The ziggurat method for generating random variables. J. Statis.
'   Softw. 5, 8, 1–7.


'11/7/2011
'Nick Calvin
'The Ziggurat method has been fully implemented to generate gaussian variables and it has been tested for accuracy.
'The previous "Class" method underlying random generation now uses a module system in order to centralize random 
'   number generation. The CRandomNumber class can still be implemented to make calling random numbers and
'   translating them into a usable number faster, but the previous class which provided the underlying framework 
'   has been translated into a module to only keep one instantiation at a time.


Public Class cCalvinRandNumber

    'Principal properties of this class module:

    'RectangularDecimal:  returns a uniform random decimal
    'between 0.0 and 1.0 (0 and 1 not included).

    'RectangularInteger:  returns a rectangularly distributed
    'random integer between m_lowestInteger (not equal to zero  
    '[3/2010:  evidently it CAN equal zero]) and m_highestInteger
    'inclusive.  LowestInteger and HighestInteger properties
    'must be set from the calling program.

    'RectangularDouble:  returns a rectangularly distributed
    'random double between m_lowestDouble and m_highestDouble
    'inclusive.  LowestDouble and HighestDouble properties
    'must be set from the calling program.  This does not
    'seem particularly useful and should perhaps be disabled 
    '...er, maybe not, actually I think it can be useful under 
    'certain circumstances so I will leave it as is [6/2010].

    'GaussianZ:  returns a random z score from a Gaussian
    'distribution (zero mean and unit variance).

    'GaussianDouble:  returns a random number (double) from a
    'Gaussian distribution with mean = Mean and s.d. = SD.
    'Mean and SD properties must be set from the calling
    'program.

    'ExponentialDouble:  returns a random number (double) from an
    'exponential distribution with mean and standard deviation = Mean.
    'Mean property must be set from the calling program.

    '------------------------------------------------------------------
    'Program notes:

    'RectangularDeviateLC and GaussianDeviate are two functions
    'from Numerical Recipes that together generate random numbers
    '(z scores) from a gaussian distribution by means of a linear congruential algorithm.

    'RectangularDeviateLC returns a uniform random deviate
    'between 0.0 and 1.0 (0 and 1 not included).  Also, see comments in the RectangularDeviateMT and 
    'RectangularDeviateKS members of this class.

    'GaussianDeviate returns a gaussian deviate with zero mean
    'and unit variance.  GaussianDeviate calls RectangularDeviateMT, RectangularDeviateKS, or RectangularDeviateLC,
    'depending on the algorithm that is in use.

    'Tests of these routines ([for LC algorithm only] as written in VB5) can be found in test.xls, test2.xls,
    'and test3.xls.  The bottom line is that they seem to generate standard normal deviates pretty well.  
    'RectangularDeviateLC definitely seems to work better than VB's Rnd function in this capacity.
    'The VB .NET version of these routines [for the LC algorithm only] was tested in the program "Random" 
    '(C:\Documents and Settings\Compaq Customer\My Documents\Projects\VB .NET\Practice\Random)
    'and, again, seemed to work quite well.  All three algorithms in this class were tested in the 
    'program "CRandomNumber Tester" (C:\Users\Jack\Documents\Visual Studio 2008\Practice and Testing\CRandomNumber Tester), 
    'and appear to function as expected.

    'Old notes regarding the linear congruential generator:
    '       Repeated calls of GaussianDeviate generate a sequence of standard normal deviates
    '       (z scores).  The identical sequence is generated whenever the
    '       functions are initialized, e.g., whenever the program that calls
    '       GaussianDeviate is restarted, unless a different seed is used.

    '       To get a different sequence of standard normal deviates it is
    '       necessary to seed GaussianDeviate with a different number each time it is
    '       first called in an application.
    '       The following code seems to do this pretty well:

    '       Seed the random number generator
    '       seed = Timer
    '       If seed > 54773 Then seed = seed - 31627
    '       x = GaussianDeviate(seed)

    '       The seed is based on the Timer function, provided its value does
    '       not exceed 54773, which is the value
    '       of IC1 in the RectangularDeviateLC function.  If seed exceeds
    '       this value by very much, then GaussianDeviate crashes.

    '       I have used a different seeding method than the one described above
    '       in this VB .NET program because the Timer function does not seem to work.
    '       See the constructor below.
    '------------------------------------------------------------------

    Private m_intSeed, m_lowestInteger, m_highestInteger As Integer
    Private m_lowestDouble, m_highestDouble As Double
    Private m_mean, m_sd As Double
    Private m_intRNG As Integer ' Tells which RNG is being used (refer to the public enumeration above)

    Public Sub New()
        Me.New(Algorithm.MersenneTwister) ' Runs the default Mersenne Twister algorithm
    End Sub

    Public Sub New(ByVal intRNG As Integer)
        'This constructor will run the Mersenne Twister, the Knuth Subtractive, or the LCG algorithm
        m_intRNG = intRNG
        Select Case intRNG
            Case Algorithm.MersenneTwister
                '"Re"-Initialize the MT algorithm
                MTRandom.SeedGenerator()
                m_intSeed = CInt(MTRandom.SeedValue Mod Integer.MaxValue)
            Case Algorithm.KnuthSubtractive
                'Initialize the Knuth algorithm with a tempseed which is set based on the current system time
                KSRandom.SeedGenerator(m_intSeed)
            Case Algorithm.LinearCongruential

                LCRandom.SeedGenerator(m_intSeed)
        End Select

        ZigguratMParams.ZigSet()
    End Sub

    Public ReadOnly Property RandBool As Boolean
        Get
            Select Case m_intRNG
                Case Algorithm.MersenneTwister
                    Return genrand_boolean()
                Case Algorithm.KnuthSubtractive
                    Return CBool(KSRandom.NextVal Mod 2)
                Case Algorithm.LinearCongruential
                    Return CBool(IIf(RectangularDeviateLC() > 0.5, True, False))
                Case Else
                    Return False
            End Select
        End Get
    End Property

    Public ReadOnly Property RectangularDecimal() As Double

        'This is the workhorse of the three algorithms. Actually, it calls the three workhorses.

        'RectangularDeviateMT, RectangularDeviateKS, and RectangularDeviateLC do not return exact zeroes or exact ones 
        '(contrary to the documentation in the case of MT).  
        'However all return deviates <= 0.000001 and deviates >= 0.999999.

        Get
            Select Case m_intRNG
                Case Algorithm.MersenneTwister
                    Return RectangularDeviateMT()
                Case Algorithm.KnuthSubtractive
                    Return RectangularDeviateKS()
                Case Algorithm.LinearCongruential
                    Return RectangularDeviateLC()
                Case Else
                    Return 0
            End Select

        End Get

    End Property

    Public ReadOnly Property RectangularInteger() As Integer
        Get
            Select Case m_intRNG
                Case Algorithm.MersenneTwister
                    'The function used is specific to the MTRandom class.
                    Return CInt(MTRandom.genrand_intRange(CUInt(m_lowestInteger), CUInt(m_highestInteger)))
                Case Algorithm.KnuthSubtractive
                    'VIP:  Note that for the .NET Random class, this syntax EXCLUDES the integer specified in
                    'the second argument (but includes the integer specified in the first argument).  Hence 1 must 
                    'be added in the second argument to the highest integer desired.
                    Return (KSRandom.NextVal() Mod (m_highestInteger - m_lowestInteger + 1) + m_lowestInteger)
                Case Algorithm.LinearCongruential
                    Return CInt(Int(((m_highestInteger - m_lowestInteger + 1) * RectangularDeviateLC() + m_lowestInteger))) ' Int, unlike CInt, truncates, which is necessary here before the type conversion.
                Case Else
                    Return 0
            End Select
        End Get
    End Property

    Public ReadOnly Property RectangularDouble() As Double
        Get
            Select Case m_intRNG
                Case Algorithm.MersenneTwister
                    'Mersenne Twister
                    Return (m_highestDouble - m_lowestDouble) * RectangularDeviateMT() + m_lowestDouble
                Case Algorithm.KnuthSubtractive
                    'Knuth Subtractive (this seems to be correct but should probably be tested).
                    Return (m_highestDouble - m_lowestDouble) * RectangularDeviateKS() + m_lowestDouble
                Case Algorithm.LinearCongruential
                    'LCG
                    Return (m_highestDouble - m_lowestDouble) * RectangularDeviateLC() + m_lowestDouble
                Case Else
                    Return 0
            End Select
        End Get
    End Property

    Public ReadOnly Property GaussianZ() As Double
        'The GaussianDeviate routine distinguishes among the three algorithms.
        Get
            Return GaussianDeviate()
        End Get
    End Property

    Public ReadOnly Property GaussianDouble() As Double
        'The GaussianDeviate routine distinguishes among the three algorithms.
        Get
            Return m_mean + GaussianDeviate() * m_sd
        End Get
    End Property

    Public ReadOnly Property ExponentialDouble() As Double
        Get
            Select Case m_intRNG
                Case Algorithm.MersenneTwister
                    'Mersenne Twister
                    Return -m_mean * Log(1 - RectangularDeviateMT())
                Case Algorithm.KnuthSubtractive
                    'Knuth Subtractive
                    Return -m_mean * Log(1 - RectangularDeviateKS())
                Case Algorithm.LinearCongruential
                    'LCG
                    Return -m_mean * Log(1 - RectangularDeviateLC())
                Case Else
                    Return 0
            End Select
        End Get
    End Property


#Region " Assigned properties"
    Public ReadOnly Property AlgorithmInUse() As Integer
        'This property permits the calling program to determine which algorithm is being used.
        '(Refer to the public enumeration above).
        Get
            Return m_intRNG
        End Get
    End Property
    Public Property LowestInteger() As Integer
        Get
            Return m_lowestInteger
        End Get
        Set(ByVal Value As Integer)
            m_lowestInteger = Value
        End Set
    End Property

    Public Property HighestInteger() As Integer
        Get
            Return m_highestInteger
        End Get
        Set(ByVal Value As Integer)
            m_highestInteger = Value
        End Set
    End Property

    Public Property LowestDouble() As Double
        Get
            Return m_lowestDouble
        End Get
        Set(ByVal Value As Double)
            m_lowestDouble = Value
        End Set
    End Property

    Public Property HighestDouble() As Double
        Get
            Return m_highestDouble
        End Get
        Set(ByVal Value As Double)
            m_highestDouble = Value
        End Set
    End Property

    Public Property Mean() As Double
        Get
            Return m_mean
        End Get
        Set(ByVal Value As Double)
            m_mean = Value
        End Set
    End Property

    Public Property SD() As Double
        Get
            Return m_sd
        End Get
        Set(ByVal Value As Double)
            m_sd = Value
        End Set
    End Property

#End Region

#Region " Properties for testing and verification"

    ''' <summary>
    ''' This property is used to set the seed the random number generator with a specific value.
    ''' </summary>
    ''' <value></value>
    ''' <remarks></remarks>
    Public WriteOnly Property WriteSeed As Integer
        Set(ByVal value As Integer)
            'Sets the value of the generators based what type of algorithm is in use.
            Select Case m_intRNG
                Case Algorithm.KnuthSubtractive
                    KSRandom.SeedGenerator(value)
                    m_intSeed = value
                Case Algorithm.LinearCongruential
                    Randomize(value)
                    LCRandom.SeedGenerator(value)
                    m_intSeed = value
                Case Algorithm.MersenneTwister
                    MTRandom.SeedGenerator(CInt(value))
                    m_intSeed = value
            End Select

            'This call is here to reset the gaussian values so that they do not persist due to the static variable "ISet"
            GaussianDeviate()
        End Set
    End Property

    Public ReadOnly Property PeekAtSeed() As Integer
        'This is just to study the behavior of the LCG
        Get
            Return m_intSeed 'This is the seed for the LCG
        End Get
    End Property

    Public ReadOnly Property Twister() As Boolean
        'For testing and verification
        Get
            If m_intRNG = Algorithm.MersenneTwister Then Return True Else Return False
            'Return m_blnRunTwister
        End Get
    End Property

#End Region

    Private Function RectangularDeviateMT() As Double

        'Mersenne twister uniform random deviate

        'Contrary to the documentation, it appears that this call
        'does not return exact zeroes and ones.  However, like
        'RectangularDeviateLC, it does return values <= 0.000001 and
        'values >= 0.999999.

        Return MTRandom.genrand_real1()

    End Function

    Private Function RectangularDeviateKS() As Double

        'Knuth Subtractive uniform random deviate

        'Exact zeroes and ones are not returned.
        'However, values <= 0.000001 and values >= 0.999999 may be returned.

        Return KSRandom.NextDouble

    End Function

    Private Function GaussianDeviate() As Double
        'This currently uses the Ziggurat method to generate random numbers

        Select Case m_intRNG
            Case Algorithm.MersenneTwister
                'Mersenne Twister
                GaussianDeviate = CDbl(IIf(MTRandom.genrand_boolean, -ZigguratMParams.GaussianDeviateMT, ZigguratMParams.GaussianDeviateMT))
            Case Algorithm.KnuthSubtractive
                'Knuth Subtractive0)
                GaussianDeviate = CDbl(IIf(CBool((KSRandom.NextVal) Mod 2), -ZigguratMParams.GaussianDeviateKS(), ZigguratMParams.GaussianDeviateKS()))
            Case Algorithm.LinearCongruential
                'LCG
                GaussianDeviate = CDbl(IIf(CBool(Int(2 * RectangularDeviateLC())), -ZigguratMParams.GaussianDeviateLC, ZigguratMParams.GaussianDeviateLC))
            Case Else
                Stop
                GaussianDeviate = 0
        End Select

        Return GaussianDeviate
    End Function
End Class

