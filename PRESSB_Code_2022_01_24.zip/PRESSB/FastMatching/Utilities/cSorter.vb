﻿Option Strict On

'This file can be loaded into a project, or the code can simply be copied into
'another file in a project.

Public Structure Coordinates
    Dim x As Double
    Dim y As Double
End Structure

Public Class cSorter
    ' Quicksort. For details and other sorting algorithms that
    ' work under different circumstances, see the book
    ' "Ready-to-Run Visual Basic Algorithms"
    ' (http://www.vb-helper.com/vba.htm).

    Public Shared Sub Quicksort(ByVal list() As Coordinates, ByVal min As Integer, ByVal max As Integer)

        'Sorts on the x member of Coordinates; max is the upperbound of the list array.

        'I don't know why this returns a sorted list inasmuch as the list is passed ByVal
        'not ByRef.  Perhaps it has something to do with the fact that the procedure is in
        'a module rather than a class, or perhaps it has to do with the recursive calls 
        'in the procedure.

        Dim random_number As New Random ' Uses the Knuth subtractive algorithm native to .NET
        Dim med_value As Coordinates
        Dim hi As Integer
        Dim lo As Integer
        Dim i As Integer

        ' If min >= max, the list contains 0 or 1 items so
        ' it is sorted.
        If min >= max Then Exit Sub

        ' Pick the dividing value (a random element in list).
        i = random_number.Next(min, max + 1)
        med_value = list(i)

        ' Swap it to the front.  <---------------------------------SWAP Coordinates
        list(i) = list(min)

        lo = min
        hi = max
        Do
            ' Look down from hi for a value < med_value.
            Do While list(hi).x >= med_value.x '[Compare x member values]
                hi = hi - 1
                If hi <= lo Then Exit Do
            Loop
            If hi <= lo Then
                list(lo) = med_value ' <------------This is a SWAP Coordinates also
                Exit Do
            End If

            ' Swap the lo and hi values.  <------------------------SWAP Coordinates
            list(lo) = list(hi)

            ' Look up from lo for a value >= med_value.
            lo = lo + 1
            Do While list(lo).x < med_value.x '[Compare x member values]
                lo = lo + 1
                If lo >= hi Then Exit Do
            Loop
            If lo >= hi Then
                lo = hi
                list(hi) = med_value ' <------------This is a SWAP Coordinates also
                Exit Do
            End If

            ' Swap the lo and hi values.  <------------------------SWAP Coordinates
            list(hi) = list(lo)
        Loop

        ' Sort the two sublists.
        Quicksort(list, min, lo - 1)
        Quicksort(list, lo + 1, max)
    End Sub
End Class
