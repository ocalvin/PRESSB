﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBuildOrganism
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmBuildOrganism))
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtMutationRate = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtGaussianSD = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtDecayOfTransfer = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.chkGrayCodes = New System.Windows.Forms.CheckBox()
        Me.txtToInteger = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtFromInteger = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtNumBehaviors = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnDifferent = New System.Windows.Forms.Button()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtPercentToReplace = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.cboCrossover = New System.Windows.Forms.ComboBox()
        Me.lstSD = New System.Windows.Forms.ListBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.lstConditions = New System.Windows.Forms.ListBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.btnClearOrganism = New System.Windows.Forms.Button()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.cboMatchMakingMethod = New System.Windows.Forms.ComboBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.cboContinuousFunctionForm = New System.Windows.Forms.ComboBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.cboSelectionMethod = New System.Windows.Forms.ComboBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.cboFitnessLandscape = New System.Windows.Forms.ComboBox()
        Me.cboFitnessMethod = New System.Windows.Forms.ComboBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.cboRecombination = New System.Windows.Forms.ComboBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.cboBoundary = New System.Windows.Forms.ComboBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.cboMutation = New System.Windows.Forms.ComboBox()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.pbxSpeaker = New System.Windows.Forms.PictureBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.pbxSD = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.cboSD = New System.Windows.Forms.ComboBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.txtBeta1 = New System.Windows.Forms.TextBox()
        Me.txtBeta0 = New System.Windows.Forms.TextBox()
        Me.txtAlpha = New System.Windows.Forms.TextBox()
        Me.btnClearPopulation = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.cboViscosity = New System.Windows.Forms.ComboBox()
        Me.chkAddViscosity = New System.Windows.Forms.CheckBox()
        Me.txtViscosityTicks = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.StatusStrip1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        CType(Me.pbxSpeaker, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbxSD, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(84, 116)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(15, 13)
        Me.Label8.TabIndex = 9
        Me.Label8.Text = "%"
        '
        'txtMutationRate
        '
        Me.txtMutationRate.Location = New System.Drawing.Point(45, 113)
        Me.txtMutationRate.Name = "txtMutationRate"
        Me.txtMutationRate.Size = New System.Drawing.Size(37, 20)
        Me.txtMutationRate.TabIndex = 8
        Me.txtMutationRate.Text = "10"
        Me.txtMutationRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(6, 116)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(33, 13)
        Me.Label7.TabIndex = 7
        Me.Label7.Text = "Rate:"
        '
        'txtGaussianSD
        '
        Me.txtGaussianSD.Enabled = False
        Me.txtGaussianSD.Location = New System.Drawing.Point(87, 52)
        Me.txtGaussianSD.Name = "txtGaussianSD"
        Me.txtGaussianSD.Size = New System.Drawing.Size(34, 20)
        Me.txtGaussianSD.TabIndex = 6
        Me.txtGaussianSD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Enabled = False
        Me.Label6.Location = New System.Drawing.Point(29, 56)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(31, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "S.D.:"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 535)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(567, 22)
        Me.StatusStrip1.TabIndex = 15
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(0, 17)
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Symbol", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label33.Location = New System.Drawing.Point(97, 78)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(32, 13)
        Me.Label33.TabIndex = 70
        Me.Label33.Text = "b    ="
        Me.ToolTip1.SetToolTip(Me.Label33, "Salience of reinforcer presence")
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Symbol", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label32.Location = New System.Drawing.Point(97, 55)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(32, 13)
        Me.Label32.TabIndex = 69
        Me.Label32.Text = "b    ="
        Me.ToolTip1.SetToolTip(Me.Label32, "Salience of reinforcer absence")
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Symbol", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label31.Location = New System.Drawing.Point(19, 57)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(29, 13)
        Me.Label31.TabIndex = 68
        Me.Label31.Text = "a   ="
        Me.ToolTip1.SetToolTip(Me.Label31, "Stimulus salience")
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(10, 100)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(88, 13)
        Me.Label4.TabIndex = 71
        Me.Label4.Text = "Decay of transfer"
        Me.ToolTip1.SetToolTip(Me.Label4, "Parameter to calculate transfer from previous SD")
        '
        'txtDecayOfTransfer
        '
        Me.txtDecayOfTransfer.Location = New System.Drawing.Point(132, 107)
        Me.txtDecayOfTransfer.Name = "txtDecayOfTransfer"
        Me.txtDecayOfTransfer.Size = New System.Drawing.Size(34, 20)
        Me.txtDecayOfTransfer.TabIndex = 72
        Me.txtDecayOfTransfer.Text = "0.04"
        Me.txtDecayOfTransfer.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ToolTip1.SetToolTip(Me.txtDecayOfTransfer, "Parameter to calculate transfer from previous SD")
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(63, 113)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(57, 13)
        Me.Label5.TabIndex = 73
        Me.Label5.Text = "parameter:"
        Me.ToolTip1.SetToolTip(Me.Label5, "Parameter to calculate transfer from previous SD")
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.chkGrayCodes)
        Me.GroupBox1.Controls.Add(Me.txtToInteger)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtFromInteger)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.txtNumBehaviors)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(193, 137)
        Me.GroupBox1.TabIndex = 16
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Population Structure"
        '
        'chkGrayCodes
        '
        Me.chkGrayCodes.AutoSize = True
        Me.chkGrayCodes.Location = New System.Drawing.Point(14, 106)
        Me.chkGrayCodes.Name = "chkGrayCodes"
        Me.chkGrayCodes.Size = New System.Drawing.Size(102, 17)
        Me.chkGrayCodes.TabIndex = 16
        Me.chkGrayCodes.Text = "Use Gray codes"
        Me.chkGrayCodes.UseVisualStyleBackColor = True
        '
        'txtToInteger
        '
        Me.txtToInteger.Location = New System.Drawing.Point(134, 70)
        Me.txtToInteger.Name = "txtToInteger"
        Me.txtToInteger.Size = New System.Drawing.Size(42, 20)
        Me.txtToInteger.TabIndex = 11
        Me.txtToInteger.Text = "1023"
        Me.txtToInteger.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(46, 73)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(86, 13)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "High Phenotype:"
        '
        'txtFromInteger
        '
        Me.txtFromInteger.Location = New System.Drawing.Point(133, 44)
        Me.txtFromInteger.Name = "txtFromInteger"
        Me.txtFromInteger.Size = New System.Drawing.Size(42, 20)
        Me.txtFromInteger.TabIndex = 9
        Me.txtFromInteger.Text = "0"
        Me.txtFromInteger.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(47, 47)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(84, 13)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Low Phenotype:"
        '
        'txtNumBehaviors
        '
        Me.txtNumBehaviors.Location = New System.Drawing.Point(133, 20)
        Me.txtNumBehaviors.Name = "txtNumBehaviors"
        Me.txtNumBehaviors.Size = New System.Drawing.Size(42, 20)
        Me.txtNumBehaviors.TabIndex = 7
        Me.txtNumBehaviors.Text = "100"
        Me.txtNumBehaviors.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(11, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(120, 13)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Behaviors in population:"
        '
        'btnDifferent
        '
        Me.btnDifferent.Location = New System.Drawing.Point(11, 464)
        Me.btnDifferent.Name = "btnDifferent"
        Me.btnDifferent.Size = New System.Drawing.Size(156, 56)
        Me.btnDifferent.TabIndex = 18
        Me.btnDifferent.Text = "Create Population"
        Me.btnDifferent.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(6, 118)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(68, 13)
        Me.Label14.TabIndex = 28
        Me.Label14.Text = "of population"
        '
        'txtPercentToReplace
        '
        Me.txtPercentToReplace.Location = New System.Drawing.Point(52, 95)
        Me.txtPercentToReplace.Name = "txtPercentToReplace"
        Me.txtPercentToReplace.Size = New System.Drawing.Size(33, 20)
        Me.txtPercentToReplace.TabIndex = 27
        Me.txtPercentToReplace.Text = "100"
        Me.txtPercentToReplace.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(6, 98)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(47, 13)
        Me.Label13.TabIndex = 26
        Me.Label13.Text = "Replace"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Enabled = False
        Me.Label12.Location = New System.Drawing.Point(60, 56)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(35, 13)
        Me.Label12.TabIndex = 3
        Me.Label12.Text = "points"
        '
        'cboCrossover
        '
        Me.cboCrossover.Enabled = False
        Me.cboCrossover.FormattingEnabled = True
        Me.cboCrossover.Location = New System.Drawing.Point(9, 52)
        Me.cboCrossover.Name = "cboCrossover"
        Me.cboCrossover.Size = New System.Drawing.Size(48, 21)
        Me.cboCrossover.TabIndex = 2
        '
        'lstSD
        '
        Me.lstSD.FormattingEnabled = True
        Me.lstSD.Location = New System.Drawing.Point(38, 31)
        Me.lstSD.Name = "lstSD"
        Me.lstSD.Size = New System.Drawing.Size(69, 69)
        Me.lstSD.TabIndex = 29
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(9, 26)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(14, 13)
        Me.Label17.TabIndex = 30
        Me.Label17.Text = "S"
        '
        'lstConditions
        '
        Me.lstConditions.BackColor = System.Drawing.SystemColors.Control
        Me.lstConditions.FormattingEnabled = True
        Me.lstConditions.Location = New System.Drawing.Point(35, 130)
        Me.lstConditions.Name = "lstConditions"
        Me.lstConditions.Size = New System.Drawing.Size(192, 238)
        Me.lstConditions.TabIndex = 47
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(35, 113)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(174, 13)
        Me.Label11.TabIndex = 50
        Me.Label11.Text = "Population structure and properties:"
        '
        'btnClearOrganism
        '
        Me.btnClearOrganism.Location = New System.Drawing.Point(173, 493)
        Me.btnClearOrganism.Name = "btnClearOrganism"
        Me.btnClearOrganism.Size = New System.Drawing.Size(98, 27)
        Me.btnClearOrganism.TabIndex = 61
        Me.btnClearOrganism.Text = "Clear Organism"
        Me.btnClearOrganism.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.cboMatchMakingMethod)
        Me.GroupBox4.Controls.Add(Me.Label29)
        Me.GroupBox4.Controls.Add(Me.cboContinuousFunctionForm)
        Me.GroupBox4.Controls.Add(Me.Label28)
        Me.GroupBox4.Controls.Add(Me.cboSelectionMethod)
        Me.GroupBox4.Controls.Add(Me.Label27)
        Me.GroupBox4.Controls.Add(Me.cboFitnessLandscape)
        Me.GroupBox4.Controls.Add(Me.cboFitnessMethod)
        Me.GroupBox4.Controls.Add(Me.Label26)
        Me.GroupBox4.Controls.Add(Me.Label25)
        Me.GroupBox4.Location = New System.Drawing.Point(11, 152)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(261, 162)
        Me.GroupBox4.TabIndex = 63
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Selection"
        '
        'cboMatchMakingMethod
        '
        Me.cboMatchMakingMethod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboMatchMakingMethod.FormattingEnabled = True
        Me.cboMatchMakingMethod.Items.AddRange(New Object() {"Search", "Mating Pool"})
        Me.cboMatchMakingMethod.Location = New System.Drawing.Point(159, 121)
        Me.cboMatchMakingMethod.Name = "cboMatchMakingMethod"
        Me.cboMatchMakingMethod.Size = New System.Drawing.Size(80, 21)
        Me.cboMatchMakingMethod.TabIndex = 9
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(36, 124)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(113, 13)
        Me.Label29.TabIndex = 8
        Me.Label29.Text = "Matchmaking Method:"
        '
        'cboContinuousFunctionForm
        '
        Me.cboContinuousFunctionForm.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboContinuousFunctionForm.FormattingEnabled = True
        Me.cboContinuousFunctionForm.Items.AddRange(New Object() {"", "Linear", "Uniform", "Exponential"})
        Me.cboContinuousFunctionForm.Location = New System.Drawing.Point(159, 97)
        Me.cboContinuousFunctionForm.Name = "cboContinuousFunctionForm"
        Me.cboContinuousFunctionForm.Size = New System.Drawing.Size(80, 21)
        Me.cboContinuousFunctionForm.TabIndex = 7
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(15, 101)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(133, 13)
        Me.Label28.TabIndex = 6
        Me.Label28.Text = "Continuous Function Form:"
        '
        'cboSelectionMethod
        '
        Me.cboSelectionMethod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSelectionMethod.FormattingEnabled = True
        Me.cboSelectionMethod.Items.AddRange(New Object() {"Truncation", "Tournament", "Continuous"})
        Me.cboSelectionMethod.Location = New System.Drawing.Point(159, 73)
        Me.cboSelectionMethod.Name = "cboSelectionMethod"
        Me.cboSelectionMethod.Size = New System.Drawing.Size(80, 21)
        Me.cboSelectionMethod.TabIndex = 5
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(55, 77)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(93, 13)
        Me.Label27.TabIndex = 4
        Me.Label27.Text = "Selection Method:"
        '
        'cboFitnessLandscape
        '
        Me.cboFitnessLandscape.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboFitnessLandscape.FormattingEnabled = True
        Me.cboFitnessLandscape.Items.AddRange(New Object() {"Flat", "Circular"})
        Me.cboFitnessLandscape.Location = New System.Drawing.Point(159, 49)
        Me.cboFitnessLandscape.Name = "cboFitnessLandscape"
        Me.cboFitnessLandscape.Size = New System.Drawing.Size(80, 21)
        Me.cboFitnessLandscape.TabIndex = 3
        '
        'cboFitnessMethod
        '
        Me.cboFitnessMethod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboFitnessMethod.FormattingEnabled = True
        Me.cboFitnessMethod.Items.AddRange(New Object() {"Midpoint", "Individual", "Class"})
        Me.cboFitnessMethod.Location = New System.Drawing.Point(159, 25)
        Me.cboFitnessMethod.Name = "cboFitnessMethod"
        Me.cboFitnessMethod.Size = New System.Drawing.Size(80, 21)
        Me.cboFitnessMethod.TabIndex = 2
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(49, 53)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(99, 13)
        Me.Label26.TabIndex = 1
        Me.Label26.Text = "Fitness Landscape:"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(66, 29)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(82, 13)
        Me.Label25.TabIndex = 0
        Me.Label25.Text = "Fitness Method:"
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.Label15)
        Me.GroupBox6.Controls.Add(Me.cboRecombination)
        Me.GroupBox6.Controls.Add(Me.Label14)
        Me.GroupBox6.Controls.Add(Me.cboCrossover)
        Me.GroupBox6.Controls.Add(Me.txtPercentToReplace)
        Me.GroupBox6.Controls.Add(Me.Label12)
        Me.GroupBox6.Controls.Add(Me.Label13)
        Me.GroupBox6.Location = New System.Drawing.Point(11, 315)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(117, 143)
        Me.GroupBox6.TabIndex = 64
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Recombination"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(85, 98)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(15, 13)
        Me.Label15.TabIndex = 29
        Me.Label15.Text = "%"
        '
        'cboRecombination
        '
        Me.cboRecombination.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboRecombination.FormattingEnabled = True
        Me.cboRecombination.Items.AddRange(New Object() {"Bitwise", "Crossover", "Clone"})
        Me.cboRecombination.Location = New System.Drawing.Point(9, 21)
        Me.cboRecombination.Name = "cboRecombination"
        Me.cboRecombination.Size = New System.Drawing.Size(80, 21)
        Me.cboRecombination.TabIndex = 3
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Label8)
        Me.GroupBox5.Controls.Add(Me.cboBoundary)
        Me.GroupBox5.Controls.Add(Me.txtMutationRate)
        Me.GroupBox5.Controls.Add(Me.Label10)
        Me.GroupBox5.Controls.Add(Me.Label7)
        Me.GroupBox5.Controls.Add(Me.cboMutation)
        Me.GroupBox5.Controls.Add(Me.txtGaussianSD)
        Me.GroupBox5.Controls.Add(Me.Label6)
        Me.GroupBox5.Location = New System.Drawing.Point(134, 315)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(138, 143)
        Me.GroupBox5.TabIndex = 65
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Mutation"
        '
        'cboBoundary
        '
        Me.cboBoundary.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboBoundary.Enabled = False
        Me.cboBoundary.FormattingEnabled = True
        Me.cboBoundary.Items.AddRange(New Object() {"", "Discard", " Wrap"})
        Me.cboBoundary.Location = New System.Drawing.Point(61, 77)
        Me.cboBoundary.Name = "cboBoundary"
        Me.cboBoundary.Size = New System.Drawing.Size(61, 21)
        Me.cboBoundary.TabIndex = 10
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Enabled = False
        Me.Label10.Location = New System.Drawing.Point(6, 80)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(55, 13)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "Boundary:"
        '
        'cboMutation
        '
        Me.cboMutation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboMutation.FormattingEnabled = True
        Me.cboMutation.Items.AddRange(New Object() {"Bitflip by individual", "Bitflip by bit", "Random individual", "Gaussian"})
        Me.cboMutation.Location = New System.Drawing.Point(6, 21)
        Me.cboMutation.Name = "cboMutation"
        Me.cboMutation.Size = New System.Drawing.Size(116, 21)
        Me.cboMutation.TabIndex = 4
        '
        'GroupBox7
        '
        Me.GroupBox7.BackColor = System.Drawing.SystemColors.Control
        Me.GroupBox7.Controls.Add(Me.pbxSpeaker)
        Me.GroupBox7.Controls.Add(Me.Label30)
        Me.GroupBox7.Controls.Add(Me.lstSD)
        Me.GroupBox7.Controls.Add(Me.Label17)
        Me.GroupBox7.Controls.Add(Me.lstConditions)
        Me.GroupBox7.Controls.Add(Me.Label11)
        Me.GroupBox7.Controls.Add(Me.pbxSD)
        Me.GroupBox7.Controls.Add(Me.PictureBox5)
        Me.GroupBox7.Location = New System.Drawing.Point(285, 152)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(269, 375)
        Me.GroupBox7.TabIndex = 66
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Built Organism"
        '
        'pbxSpeaker
        '
        Me.pbxSpeaker.Image = My.Resources.Resources.speaker
        Me.pbxSpeaker.Location = New System.Drawing.Point(206, 100)
        Me.pbxSpeaker.Name = "pbxSpeaker"
        Me.pbxSpeaker.Size = New System.Drawing.Size(19, 18)
        Me.pbxSpeaker.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.pbxSpeaker.TabIndex = 64
        Me.pbxSpeaker.TabStop = False
        Me.pbxSpeaker.Visible = False
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(19, 21)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(15, 13)
        Me.Label30.TabIndex = 63
        Me.Label30.Text = "D"
        '
        'pbxSD
        '
        Me.pbxSD.BackColor = System.Drawing.SystemColors.Control
        Me.pbxSD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbxSD.Location = New System.Drawing.Point(19, 115)
        Me.pbxSD.Name = "pbxSD"
        Me.pbxSD.Size = New System.Drawing.Size(10, 10)
        Me.pbxSD.TabIndex = 62
        Me.pbxSD.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        'Me.PictureBox5.Image = My.Resources.Resources.Frankenstein
        Me.PictureBox5.Location = New System.Drawing.Point(155, 29)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(70, 70)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox5.TabIndex = 55
        Me.PictureBox5.TabStop = False
        '
        'cboSD
        '
        Me.cboSD.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSD.FormattingEnabled = True
        Me.cboSD.Items.AddRange(New Object() {"Red", "Orange", "Yellow", "Green", "Blue", "Indigo", "Violet"})
        Me.cboSD.Location = New System.Drawing.Point(11, 24)
        Me.cboSD.Name = "cboSD"
        Me.cboSD.Size = New System.Drawing.Size(80, 21)
        Me.cboSD.TabIndex = 24
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.txtDecayOfTransfer)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.Label34)
        Me.GroupBox2.Controls.Add(Me.Label35)
        Me.GroupBox2.Controls.Add(Me.txtBeta1)
        Me.GroupBox2.Controls.Add(Me.Label33)
        Me.GroupBox2.Controls.Add(Me.txtBeta0)
        Me.GroupBox2.Controls.Add(Me.txtAlpha)
        Me.GroupBox2.Controls.Add(Me.Label32)
        Me.GroupBox2.Controls.Add(Me.cboSD)
        Me.GroupBox2.Controls.Add(Me.Label31)
        Me.GroupBox2.Location = New System.Drawing.Point(211, 11)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(181, 138)
        Me.GroupBox2.TabIndex = 67
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Discriminative Stimulus"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(107, 84)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(10, 12)
        Me.Label34.TabIndex = 68
        Me.Label34.Text = "1"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(107, 61)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(10, 12)
        Me.Label35.TabIndex = 69
        Me.Label35.Text = "0"
        '
        'txtBeta1
        '
        Me.txtBeta1.Location = New System.Drawing.Point(132, 75)
        Me.txtBeta1.Name = "txtBeta1"
        Me.txtBeta1.Size = New System.Drawing.Size(34, 20)
        Me.txtBeta1.TabIndex = 27
        Me.txtBeta1.Text = "1.000"
        Me.txtBeta1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtBeta0
        '
        Me.txtBeta0.Location = New System.Drawing.Point(132, 52)
        Me.txtBeta0.Name = "txtBeta0"
        Me.txtBeta0.Size = New System.Drawing.Size(34, 20)
        Me.txtBeta0.TabIndex = 26
        Me.txtBeta0.Text = "0.006"
        Me.txtBeta0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtAlpha
        '
        Me.txtAlpha.Location = New System.Drawing.Point(52, 54)
        Me.txtAlpha.Name = "txtAlpha"
        Me.txtAlpha.Size = New System.Drawing.Size(34, 20)
        Me.txtAlpha.TabIndex = 25
        Me.txtAlpha.Text = "0.750"
        Me.txtAlpha.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'btnClearPopulation
        '
        Me.btnClearPopulation.Location = New System.Drawing.Point(173, 464)
        Me.btnClearPopulation.Name = "btnClearPopulation"
        Me.btnClearPopulation.Size = New System.Drawing.Size(98, 26)
        Me.btnClearPopulation.TabIndex = 68
        Me.btnClearPopulation.Text = "Clear Population"
        Me.btnClearPopulation.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label18)
        Me.GroupBox3.Controls.Add(Me.Label16)
        Me.GroupBox3.Controls.Add(Me.cboViscosity)
        Me.GroupBox3.Controls.Add(Me.chkAddViscosity)
        Me.GroupBox3.Controls.Add(Me.txtViscosityTicks)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Location = New System.Drawing.Point(398, 11)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(156, 138)
        Me.GroupBox3.TabIndex = 69
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Viscosity"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(42, 118)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(61, 13)
        Me.Label18.TabIndex = 27
        Me.Label18.Text = "populations"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(17, 77)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(110, 13)
        Me.Label16.TabIndex = 26
        Me.Label16.Text = "New generations from"
        '
        'cboViscosity
        '
        Me.cboViscosity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboViscosity.FormattingEnabled = True
        Me.cboViscosity.Items.AddRange(New Object() {"          original", "     amalgamated"})
        Me.cboViscosity.Location = New System.Drawing.Point(20, 94)
        Me.cboViscosity.Name = "cboViscosity"
        Me.cboViscosity.Size = New System.Drawing.Size(104, 21)
        Me.cboViscosity.TabIndex = 25
        '
        'chkAddViscosity
        '
        Me.chkAddViscosity.AutoSize = True
        Me.chkAddViscosity.Location = New System.Drawing.Point(28, 29)
        Me.chkAddViscosity.Name = "chkAddViscosity"
        Me.chkAddViscosity.Size = New System.Drawing.Size(89, 17)
        Me.chkAddViscosity.TabIndex = 2
        Me.chkAddViscosity.Text = "Add Viscosity"
        Me.chkAddViscosity.UseVisualStyleBackColor = True
        '
        'txtViscosityTicks
        '
        Me.txtViscosityTicks.Enabled = False
        Me.txtViscosityTicks.Location = New System.Drawing.Point(67, 51)
        Me.txtViscosityTicks.Name = "txtViscosityTicks"
        Me.txtViscosityTicks.Size = New System.Drawing.Size(45, 20)
        Me.txtViscosityTicks.TabIndex = 1
        Me.txtViscosityTicks.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(24, 53)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(36, 13)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "Ticks:"
        '
        'frmBuildOrganism
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(567, 557)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.btnClearPopulation)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox7)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.btnClearOrganism)
        Me.Controls.Add(Me.btnDifferent)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmBuildOrganism"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Build Organism"
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        CType(Me.pbxSpeaker, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbxSD, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtMutationRate As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtGaussianSD As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtToInteger As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtFromInteger As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtNumBehaviors As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents chkGrayCodes As System.Windows.Forms.CheckBox
    Friend WithEvents btnDifferent As System.Windows.Forms.Button
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents cboCrossover As System.Windows.Forms.ComboBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txtPercentToReplace As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents lstSD As System.Windows.Forms.ListBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents lstConditions As System.Windows.Forms.ListBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents PictureBox5 As System.Windows.Forms.PictureBox
    Friend WithEvents btnClearOrganism As System.Windows.Forms.Button
    Friend WithEvents pbxSD As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents cboFitnessMethod As System.Windows.Forms.ComboBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents cboFitnessLandscape As System.Windows.Forms.ComboBox
    Friend WithEvents cboSelectionMethod As System.Windows.Forms.ComboBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents cboContinuousFunctionForm As System.Windows.Forms.ComboBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents cboMatchMakingMethod As System.Windows.Forms.ComboBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents cboRecombination As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents cboMutation As System.Windows.Forms.ComboBox
    Friend WithEvents cboBoundary As System.Windows.Forms.ComboBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents pbxSpeaker As System.Windows.Forms.PictureBox
    Friend WithEvents cboSD As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents txtBeta1 As System.Windows.Forms.TextBox
    Friend WithEvents txtBeta0 As System.Windows.Forms.TextBox
    Friend WithEvents txtAlpha As System.Windows.Forms.TextBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents btnClearPopulation As System.Windows.Forms.Button
    Friend WithEvents txtDecayOfTransfer As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents txtViscosityTicks As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents chkAddViscosity As System.Windows.Forms.CheckBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents cboViscosity As System.Windows.Forms.ComboBox

End Class
