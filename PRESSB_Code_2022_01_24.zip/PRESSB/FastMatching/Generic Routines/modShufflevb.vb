﻿Public Module modShufflevb
    Public Function ShuffleList(ByVal values As List(Of Integer)) As List(Of Integer)
        Dim TempList As New List(Of Integer)
        Dim TempID As Integer
        Dim Rand As New cCalvinRandNumber

        Rand.HighestInteger = values.Count - 1
        Rand.LowestInteger = 0

        Do
            'Pulls a random integer
            TempID = Rand.RectangularInteger

            'Pulls out of the other list and inserts it into the temp list
            TempList.Add(values(TempID))
            values.RemoveAt(TempID)

            'Resets the highest integer that random can sample
            Rand.HighestInteger = values.Count - 1
        Loop Until values.Count = 0

        ShuffleList = TempList
    End Function
End Module
