﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmPartInfo
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.bttnBegin = New System.Windows.Forms.Button()
        Me.txtParticipant = New System.Windows.Forms.TextBox()
        Me.lbID = New System.Windows.Forms.Label()
        Me.mskDate = New System.Windows.Forms.MaskedTextBox()
        Me.lblDate = New System.Windows.Forms.Label()
        Me.lblTime = New System.Windows.Forms.Label()
        Me.mskTime = New System.Windows.Forms.MaskedTextBox()
        Me.lbExperiment = New System.Windows.Forms.ListBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.bttnAbout = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'bttnBegin
        '
        Me.bttnBegin.Location = New System.Drawing.Point(64, 250)
        Me.bttnBegin.Name = "bttnBegin"
        Me.bttnBegin.Size = New System.Drawing.Size(168, 45)
        Me.bttnBegin.TabIndex = 0
        Me.bttnBegin.Text = "Begin Experiment"
        Me.bttnBegin.UseVisualStyleBackColor = True
        '
        'txtParticipant
        '
        Me.txtParticipant.Location = New System.Drawing.Point(172, 9)
        Me.txtParticipant.Name = "txtParticipant"
        Me.txtParticipant.Size = New System.Drawing.Size(101, 26)
        Me.txtParticipant.TabIndex = 1
        '
        'lbID
        '
        Me.lbID.AutoSize = True
        Me.lbID.Location = New System.Drawing.Point(21, 14)
        Me.lbID.Name = "lbID"
        Me.lbID.Size = New System.Drawing.Size(105, 20)
        Me.lbID.TabIndex = 2
        Me.lbID.Text = "Participant ID"
        '
        'mskDate
        '
        Me.mskDate.Location = New System.Drawing.Point(172, 45)
        Me.mskDate.Mask = "00/00/0000"
        Me.mskDate.Name = "mskDate"
        Me.mskDate.Size = New System.Drawing.Size(101, 26)
        Me.mskDate.TabIndex = 3
        Me.mskDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.mskDate.ValidatingType = GetType(Date)
        '
        'lblDate
        '
        Me.lblDate.AutoSize = True
        Me.lblDate.Location = New System.Drawing.Point(21, 49)
        Me.lblDate.Name = "lblDate"
        Me.lblDate.Size = New System.Drawing.Size(44, 20)
        Me.lblDate.TabIndex = 4
        Me.lblDate.Text = "Date"
        '
        'lblTime
        '
        Me.lblTime.AutoSize = True
        Me.lblTime.Location = New System.Drawing.Point(21, 83)
        Me.lblTime.Name = "lblTime"
        Me.lblTime.Size = New System.Drawing.Size(105, 20)
        Me.lblTime.TabIndex = 6
        Me.lblTime.Text = "Time (Military)"
        '
        'mskTime
        '
        Me.mskTime.Location = New System.Drawing.Point(172, 80)
        Me.mskTime.Mask = "00:00"
        Me.mskTime.Name = "mskTime"
        Me.mskTime.Size = New System.Drawing.Size(101, 26)
        Me.mskTime.TabIndex = 5
        Me.mskTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.mskTime.ValidatingType = GetType(Date)
        '
        'lbExperiment
        '
        Me.lbExperiment.FormattingEnabled = True
        Me.lbExperiment.ItemHeight = 20
        Me.lbExperiment.Location = New System.Drawing.Point(21, 138)
        Me.lbExperiment.Name = "lbExperiment"
        Me.lbExperiment.ScrollAlwaysVisible = True
        Me.lbExperiment.Size = New System.Drawing.Size(252, 104)
        Me.lbExperiment.Sorted = True
        Me.lbExperiment.TabIndex = 11
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(21, 115)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(93, 20)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "Experiment:"
        '
        'bttnAbout
        '
        Me.bttnAbout.Location = New System.Drawing.Point(64, 301)
        Me.bttnAbout.Name = "bttnAbout"
        Me.bttnAbout.Size = New System.Drawing.Size(167, 45)
        Me.bttnAbout.TabIndex = 13
        Me.bttnAbout.Text = "About"
        Me.bttnAbout.UseVisualStyleBackColor = True
        '
        'frmPartInfo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(285, 356)
        Me.Controls.Add(Me.bttnAbout)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.lbExperiment)
        Me.Controls.Add(Me.lblTime)
        Me.Controls.Add(Me.mskTime)
        Me.Controls.Add(Me.lblDate)
        Me.Controls.Add(Me.mskDate)
        Me.Controls.Add(Me.lbID)
        Me.Controls.Add(Me.txtParticipant)
        Me.Controls.Add(Me.bttnBegin)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmPartInfo"
        Me.ShowIcon = False
        Me.Text = "Participant Information"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents bttnBegin As System.Windows.Forms.Button
    Friend WithEvents txtParticipant As System.Windows.Forms.TextBox
    Friend WithEvents lbID As System.Windows.Forms.Label
    Friend WithEvents mskDate As System.Windows.Forms.MaskedTextBox
    Friend WithEvents lblDate As System.Windows.Forms.Label
    Friend WithEvents lblTime As System.Windows.Forms.Label
    Friend WithEvents mskTime As System.Windows.Forms.MaskedTextBox
    Friend WithEvents lbExperiment As ListBox
    Friend WithEvents Label5 As Label
    Friend WithEvents bttnAbout As Button
End Class
